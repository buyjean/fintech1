<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>

<%@ include file="../includes/header.jsp" %>

<style>
   
    .sticky-sidebar { position: sticky !important; top: 100px !important; z-index: 90; }
      
    .qty-input { width: 40px; text-align: center; border: 1px solid #dee2e6; height: 31px; }
    .qty-btn { height: 31px; padding: 0 10px; border: 1px solid #dee2e6; background: #fff; cursor: pointer; }
  
    .btn-delete-corner { position: absolute; top: 15px; right: 15px; color: #adb5bd; font-size: 1.2rem; cursor: pointer; z-index: 10; }
    .btn-delete-corner:hover { color: #dc3545; }
    
    
    .text-decoration-line-through { text-decoration: line-through; }

    
    .swiper { 
        width: 100%;
        height: 290px !important; 
        padding-bottom: 30px !important; 
    }
    .swiper-slide { 
        height: auto;
        display: flex;
        justify-content: center;
    }
    .recommend-card { 
        border: none; 
        width: 100%; 
        height: 100%; 
        display: block;
        background: #fff;
    }
    .recommend-img { 
        height: 160px; 
        width: 100%; 
        object-fit: contain; 
        padding: 15px; 
    }
    .swiper-pagination { bottom: 0px !important; }
</style>

<div class="container-fluid mt-4 mb-5 px-5">
    
    <div class="d-flex justify-content-between align-items-end mb-2">
        <h1 class="font-weight-bold m-0">
            장바구니 <i class="fa-solid fa-basket-shopping fa-xs" style="color: #28a745;"></i>
        </h1>
        <div class="pb-2"> 
            <span class="font-weight-bold text-dark" style="font-size: 1rem;">장바구니</span>
            <span class="text-muted mx-2">&gt;</span>
            <span class="text-muted">주문결제</span>
            <span class="text-muted mx-2">&gt;</span>
            <span class="text-muted">주문완료</span>
        </div>
    </div>
    
    <hr class="mt-0 border-dark"> 

    <div class="row">
        <div class="col-lg-9">
            
            <div class="card shadow-sm mt-3 mb-3 border-0">
                <div class="card-body p-3 d-flex justify-content-between align-items-center">
                    <div class="custom-control custom-checkbox">
                        <input type="checkbox" class="custom-control-input" id="checkAll" checked>
                        <label class="custom-control-label font-weight-bold" for="checkAll">전체선택</label>
                    </div>
                    <button type="button" class="btn btn-outline-dark btn-sm border-0 btn-delete-checked">선택삭제</button>
                </div>
            </div>
            
            <c:forEach items="${cartList}" var="item" varStatus="status">
                <div class="card shadow-sm mb-3 border-0">
                    <div class="card-body" style="height:110px;">
                        
                        <div class="mb-1"> 
                            <i class="fa-solid fa-xmark btn-delete-corner" 
                               data-cart-id="${item.cartId}" title="삭제"></i>
                        </div>

                        <div class="row align-items-center h-100">
                            <div class="col-1">
                                <div class="custom-control custom-checkbox">
                                    <input type="checkbox" class="custom-control-input item-check" 
                                           id="check_${status.index}" 
                                           value="${item.cartId}"
                                           data-price="${item.salePrice}" 
                                           data-cart-id="${item.cartId }" checked>
                                    <label class="custom-control-label" for="check_${status.index}"></label>
                                </div>
                            </div>
                            
                            <div class="col-2">
                                <img src="<c:url value='/resources/images/${item.prodImage}' />" 
                                     class="img-fluid rounded border" 
                                     style="height:80px; width:100%; object-fit: contain;"
                                     alt="${item.prodName}">
                            </div>
                            
                            <div class="col-5">
                                <h6 class="font-weight-bold mb-1">
                                    <c:if test="${item.discountRate > 0}">
                                        <span class="badge badge-danger mr-1">SALE ${item.discountRate}%</span>
                                    </c:if>
                                    ${item.prodName}
                                </h6>
                            </div>
                            
                            <div class="col-2 text-center">
                                <button type="button" class="qty-btn btn-minus" data-cart-id="${item.cartId}">-</button>
                                <input type="text" class="qty-input" id="qty_${item.cartId}" value="${item.quantity}" readonly>
                                <button type="button" class="qty-btn btn-plus" data-cart-id="${item.cartId}">+</button>
                            </div>
                            
                            <div class="col-2 text-right">
                                <h6 class="font-weight-bold mb-0" id="total_price_${item.cartId}">
                                    <c:choose>
                                        <c:when test="${item.discountRate > 0}">
                                            <div class="text-muted small text-decoration-line-through">
                                                <fmt:formatNumber value="${item.prodPrice * item.quantity}" />원
                                            </div>
                                            <span class="text-danger">
                                                <fmt:formatNumber value="${item.salePrice * item.quantity}" />원
                                            </span>
                                        </c:when>
                                        <c:otherwise>
                                            <fmt:formatNumber value="${item.prodPrice * item.quantity}" />원
                                        </c:otherwise>
                                    </c:choose>
                                </h6>
                            </div>
                        </div>
                    </div>
                </div>
            </c:forEach>
    
            <c:if test="${empty cartList}">
                <div class="text-center py-5">
                    <i class="fa-solid fa-cart-arrow-down fa-3x text-muted mb-3"></i>
                    <h5 class="text-muted">장바구니가 비어있습니다.</h5>
                </div>
            </c:if>
            
            <div class="mt-5 mb-5">
                <h3 class="font-weight-bold mb-3">🛒 추천상품</h3>
                
                <c:if test="${not empty recommendList}">
                    <div class="swiper mySwiper">
                        <div class="swiper-wrapper py-2">
                            
                            <c:forEach items="${recommendList}" var="rec">
                                <div class="swiper-slide">
                                    <div class="card recommend-card shadow-sm h-100">
                                        <a href="${pageContext.request.contextPath}/product/detail?prodId=${rec.prodId}" class="text-decoration-none">
                                            <img src="${pageContext.request.contextPath}/resources/img/${rec.image}" 
                                                 class="recommend-img card-img-top"
                                                 onerror="this.src='https://dummyimage.com/300x300/dee2e6/6c757d.jpg&text=No+Image'">
                                        </a>
                                        <div class="card-body p-3 text-center">
                                            <h6 class="font-weight-bold mb-1 text-truncate">
                                                <a href="${pageContext.request.contextPath}/product/detail?prodId=${rec.prodId}" class="text-dark">
                                                    ${rec.name}
                                                </a>
                                            </h6>
                                            <p class="text-danger font-weight-bold mb-0 small">
                                                <fmt:formatNumber value="${rec.price}" pattern="#,###"/>원
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </c:forEach>
                            
                        </div>
                        <div class="swiper-pagination"></div>
                    </div>
                </c:if>
                
                <c:if test="${empty recommendList}">
                    <div class="text-center text-muted py-5">
                        추천 상품 준비중입니다.
                    </div>
                </c:if>
                
            </div>
        </div> <div class="col-lg-3">
            <c:set var="totalRealPrice" value="0" />
            <c:set var="totalOriginalPrice" value="0" />
            <c:forEach items="${cartList}" var="item">
                <c:set var="totalRealPrice" value="${totalRealPrice + (item.salePrice * item.quantity)}" />
                <c:set var="totalOriginalPrice" value="${totalOriginalPrice + (item.prodPrice * item.quantity)}" />
            </c:forEach>

            <c:set var="eventDiscount" value="${totalOriginalPrice - totalRealPrice}" />
            <c:set var="shippingFee" value="${totalRealPrice >= 50000 ? 0 : 3000}" />
            <c:set var="finalTotalPrice" value="${totalRealPrice + shippingFee}" />
            <c:set var="totalPoint" value="${totalRealPrice * (memberRank.pointRate/100)}" />

            <div class="card shadow-sm border-0 sticky-sidebar">
                <div class="card-header bg-white font-weight-bold py-4">
                    <i class="fa-solid fa-receipt mr-2"></i>결제 금액
                </div>
                
                <div class="card-body">
                    <div class="d-flex justify-content-between mb-2 text-muted">
                        <span>상품 금액</span>
                        <span id="prodTotalPrice">
                            <fmt:formatNumber value="${totalOriginalPrice}" />원
                        </span>
                    </div>
                    
                    <c:if test="${eventDiscount > 0}">
                        <div class="d-flex justify-content-between mb-2 text-danger font-weight-bold">
                            <span>이벤트 할인</span> 
                            <span>- <fmt:formatNumber value="${eventDiscount}" />원</span>
                        </div>
                    </c:if>
                    
                    <div class="d-flex justify-content-between mb-2 text-muted">
                        <span>상품 할인</span> <span>- 0원</span>
                    </div>

                    <div class="d-flex justify-content-between mb-2 text-muted">
                        <span>배송비</span>
                        <span id="shippingFeeArea">
                            <c:choose>
                                <c:when test="${shippingFee == 0}">무료</c:when>
                                <c:otherwise>+ <fmt:formatNumber value="${shippingFee}" />원</c:otherwise>
                            </c:choose>
                        </span>
                    </div>
                    <hr>
                    
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <span class="font-weight-bold h5 mb-0">결제 예정 금액</span>
                        <span class="font-weight-bold h4 text-danger mb-0" id="finalTotalPrice">
                            <fmt:formatNumber value="${finalTotalPrice}" />원
                        </span>
                    </div>
                    
                    <div class="bg-light p-2 rounded mb-3 text-center small text-secondary">
                        <span class="badge badge-warning text-white mr-1">G.Point</span> 
                        구매 시 <span id="expectedPoint"><fmt:formatNumber value="${totalPoint}" pattern="#,###"/></span>P 적립
                    </div>
                    
                    <button class="btn btn-success btn-block btn-lg font-weight-bold py-3" onclick="requestPay()">주문하기</button>
                </div>
            </div>
        </div> 
    </div> 
</div> 

<script src="${pageContext.request.contextPath}/resources/js/cart.js?v=<%=System.currentTimeMillis()%>"></script>

</body>
</html>