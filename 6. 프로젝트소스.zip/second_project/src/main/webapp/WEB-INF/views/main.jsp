<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt"%>

<%@ include file="includes/header.jsp"%>

<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
<style>
.text-decoration-line-through {
	text-decoration: line-through;
}

.card-img-top {
	object-fit: cover;
	height: 200px;
}

.card:hover {
	transform: translateY(-5px);
	transition: 0.3s;
}
</style>

<div class="container-fluid px-4" style="max-width: 1600px">
	<div class="row justify-content-between">

		<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
		<script>
			AOS.init({
				duration : 800,
				once : false,
			});
		</script>

		<main class="col-lg-10 order-1 order-lg-1">

			<div class="swiper mySwiper rounded shadow-sm mb-4"
				style="height: 400px;">
				<div class="swiper-wrapper">
					<div class="swiper-slide position-relative"
						style="background-color: #333;">
						<img
							src="https://images.unsplash.com/photo-1542838132-92c53300491e?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80"
							class="w-100 h-100" style="object-fit: cover; opacity: 0.7;">
						<div
							class="position-absolute d-flex flex-column justify-content-center align-items-center w-100 h-100"
							style="top: 0; left: 0;">
							<div class="text-center text-white px-3">
								<h1 class="display-4 font-weight-bold font-italic">Fresh
									Arrival</h1>
								<p class="lead d-none d-md-block">갓 딴 야채와 과일</p>
							</div>
						</div>
					</div>

					<div class="swiper-slide position-relative"
						style="background-color: #333;">
						<img
							src="https://images.unsplash.com/photo-1558030006-450675393462?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80"
							class="w-100 h-100" style="object-fit: cover; opacity: 0.7;">
						<div
							class="position-absolute d-flex flex-column justify-content-center align-items-center w-100 h-100"
							style="top: 0; left: 0;">
							<div class="text-center text-white px-3">
								<h1 class="display-4 font-weight-bold font-italic">Premium
									Meat</h1>
								<p class="lead d-none d-md-block">질 좋은 고기만 엄선했습니다</p>
							</div>
						</div>
					</div>

					<div class="swiper-slide position-relative"
						style="background-color: #333;">
						<img
							src="https://images.unsplash.com/photo-1550989460-0adf9ea622e2?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80"
							class="w-100 h-100" style="object-fit: cover; opacity: 0.7;">
						<div
							class="position-absolute d-flex flex-column justify-content-center align-items-center w-100 h-100"
							style="top: 0; left: 0;">
							<div class="text-center text-white px-3">
								<h1
									class="display-4 font-weight-bold text-danger bg-white px-3 rounded">SALE
									!!</h1>
								<p class="lead mt-3 font-weight-bold">날마다 바뀌는 라인업</p>
							</div>
						</div>
					</div>
				</div>
				<div class="swiper-pagination"></div>
				<div class="swiper-button-next text-white"></div>
				<div class="swiper-button-prev text-white"></div>
			</div>


			<div
				class="d-flex justify-content-between align-items-end mb-3 border-bottom pb-2">
				<h4 class="font-weight-bold mb-0">
					<i class="fa-solid fa-bullhorn fa-beat-fade text-success mr-1"></i>신상품
				</h4>
			</div>

			<div class="row">
				<c:forEach items="${productList_new}" var="product"
					varStatus="status">
					<div class="col-lg-4 col-md-4 col-6 mb-5 p-1" data-aos="fade-up"
						data-aos-delay="${status.index * 100 }">
						<div class="card h-100 border-0 shadow-sm mx-auto"
							style="width: 85%;">

							<a
								href="${pageContext.request.contextPath }/product/detail?prodId=${product.prodId}"
								class="position-relative"> <img class="card-img-top"
								src="${pageContext.request.contextPath }/resources/img/${product.image}"
								alt="${product.name}"
								onerror="this.src='https://dummyimage.com/300x180/dee2e6/6c757d.jpg&text=No+Image';">

								<span class="badge badge-success position-absolute shadow-sm"
								style="top: 10px; left: 10px;">NEW!</span> <c:if
									test="${product.discountRate > 0}">
									<span class="badge badge-danger position-absolute shadow-sm"
										style="top: 10px; right: 10px; font-size: 0.9rem;">
										SALE ${product.discountRate}% </span>
								</c:if>
							</a>

							<div class="card-body p-3">
								<small class="text-muted d-block mb-1">${product.categoryName}</small>

								<h6 class="card-title font-weight-bold text-truncate">
									<a
										href="${pageContext.request.contextPath }/product/detail?prodId=${product.prodId}"
										class="text-dark text-decoration-none"> ${product.name} </a>
								</h6>

								<div
									class="d-flex justify-content-between align-items-center mt-2">
									<span class="h5 mb-0 font-weight-bold"> <c:choose>
											<c:when test="${product.discountRate > 0}">
												<div class="d-flex flex-column align-items-start">
													<small class="text-muted text-decoration-line-through"
														style="font-size: 0.7em;"> <fmt:formatNumber
															value="${product.price}" />
													</small> <span class="text-danger"> <fmt:formatNumber
															value="${product.salePrice}" /> <small class="text-dark">원</small>
													</span>
												</div>
											</c:when>
											<c:otherwise>
												<span class="text-dark"> <fmt:formatNumber
														value="${product.price}" /> <small class="text-dark">원</small>
												</span>
											</c:otherwise>
										</c:choose>
									</span>

									<button
										class="btn btn-sm btn-outline-warning rounded-circle shadow-sm"
										onclick="addToCart('${product.prodId}')">
										<i class="fas fa-shopping-basket"></i>
									</button>
								</div>
							</div>
						</div>
					</div>
				</c:forEach>

				<c:if test="${empty productList_new}">
					<div class="col-12 text-center py-5">
						<p class="text-muted">상품이 없습니다</p>
					</div>
				</c:if>
			</div>

			<div class="mb-5"></div>

			<div
				class="d-flex justify-content-between align-items-end mb-3 border-bottom pb-2">
				<h4 class="font-weight-bold mb-0">
					<i class="fas fa-fire-alt text-danger"></i> 알뜰상품 코너
				</h4>

			</div>

			<div class="row">
				<c:forEach items="${productList_dis}" var="product">
					<div class="col-lg-4 col-md-4 col-6 mb-5 p-1">
						<div class="card h-100 border-0 shadow-sm mx-auto"
							style="width: 85%">

							<a
								href="${pageContext.request.contextPath }/product/detail?prodId=${product.prodId}"
								class="position-relative"> <img class="card-img-top"
								src="${pageContext.request.contextPath }/resources/img/${product.image}"
								alt="${product.name}"
								onerror="this.src='https://dummyimage.com/300x180/dee2e6/6c757d.jpg&text=No+Image';">

								<span class="badge badge-danger position-absolute shadow-sm"
								style="top: 10px; left: 10px;"> <i class="fas fa-tag"></i>
									OUTLET
							</span> <c:if test="${product.discountRate > 0}">
									<span
										class="badge badge-warning text-white position-absolute shadow-sm"
										style="top: 10px; right: 10px; font-size: 0.9rem;">
										-${product.discountRate}% </span>
								</c:if>
							</a>

							<div class="card-body p-3">
								<small class="text-danger font-weight-bold d-block mb-1">
									${product.categoryName} / 알뜰 </small>
								<h6 class="card-title font-weight-bold text-truncate">
									<a
										href="${pageContext.request.contextPath }/product/detail?prodId=${product.prodId}"
										class="text-dark text-decoration-none"> ${product.name} </a>
								</h6>

								<div
									class="d-flex justify-content-between align-items-center mt-2">
									<div>
										<c:choose>
											<c:when test="${product.discountRate > 0}">
												<small class="text-muted text-decoration-line-through">
													<fmt:formatNumber value="${product.price}" />원
												</small>
												<br>
												<span class="h5 mb-0 text-danger font-weight-bold"> <fmt:formatNumber
														value="${product.salePrice}" /> <small class="text-dark">원</small>
												</span>
											</c:when>
											<c:otherwise>
												<span class="h5 mb-0 text-danger font-weight-bold"> <fmt:formatNumber
														value="${product.price}" /> <small class="text-dark">원</small>
												</span>
											</c:otherwise>
										</c:choose>
									</div>

									<button
										class="btn btn-sm btn-outline-danger rounded-circle shadow-sm"
										onclick="addToCart('${product.prodId}')">
										<i class="fas fa-shopping-cart"></i>
									</button>
								</div>
							</div>
						</div>
					</div>
				</c:forEach>
			</div>

		</main>

		<aside class="col-lg-2 ml-auto order-2 order-lg-2 d-none d-lg-block">
			<%@ include file="includes/sidebar.jsp"%>
		</aside>

	</div>
</div>
<div class="mb-5"></div>

<script>
	const swiper = new Swiper(".mySwiper", {
		loop : true, //무한루프
		effect : "fade",
		autoplay : {
			delay : 4000,// 4초마다
			disableOnInteraction : false, // 유저가 건드려도 자동재생 유지
		},
		pagination : {
			el : ".swiper-pagination",
			clickable : true,
		},
		navigation : {
			nextEl : ".swiper-button-next",
			prevEl : ".swiper-button-prev",
		},
	});
</script>

</body>
</html>