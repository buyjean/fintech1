<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<div class="container-fluid mt-3">
  <h3 class="mb-3">추천상품 등록</h3>

  <div id="recoArea" >

    <button type="submit" class="btn btn-success mb-3" id="saveRecommendBtn" style="background:#43a047;">
      상품 등록
    </button>

    <!-- ✅ 추천중인 상품 -->
    <h5 class="mt-2 mb-2">현재 추천중인 상품</h5>
    <table class="table table-bordered align-middle mb-4">
      <thead class="table-light">
        <tr class="text-center">
          <th>선택</th>
          <th>상품ID</th>
          <th>이미지</th>
          <th>상품명</th>
          <th>가격</th>
          <th>재고</th>
        </tr>
      </thead>
      <tbody>
        <c:set var="hasReco" value="false"/>
        <c:forEach var="product" items="${productListAll}">
          <c:if test="${product.isRecommended eq '1' and product.prodStatus eq '1'}">
            <c:set var="hasReco" value="true"/>

            <tr class="text-center">
              <td>
                <input type="hidden" name="allIds" value="${product.prodId}"/>
                <input type="checkbox" class="product-check" name="checkedIds"
                       value="${product.prodId}" >
              </td>
              <td>${product.prodId}</td>
              <td><img src="${pageContext.request.contextPath}/product/image/${product.prodId}" style="width:50px;"></td>
              <td class="text-start">${product.name}</td>
              <td>
              	<fmt:formatNumber value="${product.price}" pattern="#,###"/>원
              </td>
              <td>${product.stockQuantity}</td>
            </tr>
          </c:if>
        </c:forEach>

        <c:if test="${hasReco eq 'false'}">
          <tr><td colspan="6" class="text-center text-muted">현재 추천중인 상품이 없습니다.</td></tr>
        </c:if>
      </tbody>
    </table>

    <!-- ✅ 추천이 아닌 상품 -->
    <h5 class="mt-2 mb-2">추천이 아닌 상품</h5>
    <table class="table table-bordered align-middle mb-4">
      <thead class="table-light">
        <tr class="text-center">
          <th>선택</th>
          <th>상품ID</th>
          <th>이미지</th>
          <th>상품명</th>
          <th>가격</th>
          <th>재고</th>
        </tr>
      </thead>
      <tbody>
        <c:set var="hasNotReco" value="false"/>
        <c:forEach var="product" items="${productListAll}">
          <c:if test="${product.isRecommended ne '1' and product.prodStatus eq '1'}">
            <c:set var="hasNotReco" value="true"/>

            <tr class="text-center">
              <td>
                <input type="hidden" name="allIds" value="${product.prodId}"/>
                <input type="checkbox" class="product-check" name="checkedIds"
                       value="${product.prodId}">
              </td>
              <td>${product.prodId}</td>
              <td><img src="${pageContext.request.contextPath}/product/image/${product.prodId}" style="width:50px;"></td>
              <td class="text-start">${product.name}</td>
              <td>
              <fmt:formatNumber value="${product.price}" pattern="#,###"/>원
              </td>
              <td>${product.stockQuantity}</td>
            </tr>
          </c:if>
        </c:forEach>

        <c:if test="${hasNotReco eq 'false'}">
          <tr><td colspan="6" class="text-center text-muted">모든 상품이 추천중입니다.</td></tr>
        </c:if>
      </tbody>
    </table>

  </div>
</div>

<script>
  $(document).off('click','#saveRecommendBtn').on('click','#saveRecommendBtn',async function(e){
  
	  e.preventDefault();
	  const btn = this;

  
  const checkedIds = [...document.querySelectorAll('input[name="checkedIds"]:checked')].map(el => el.value);

  if (checkedIds.length === 0) {
      alert("변경할 상품을 선택해주세요.");
      return;
  }
  
  try {
    const res = await fetch(window.CTX + "/admin/recommend/save", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({checkedIds: checkedIds })
    });

    if (res.ok) {
      alert("저장 완료!");
      // 추천 탭 화면만 다시 로딩하고 싶으면:
      loadTab(window.CTX + "/admin/tab/recommend");
    } else {
      alert("저장 실패: " + res.status);
    }
  } catch (err) {
    console.error(err);
    alert("서버 요청 실패");
  } finally {
    btn.disabled = false;
  }
});
</script>
