<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt"%>
<div class="container-fluid mt-3">

	<!-- 헤더 -->
	<div class="d-flex justify-content-between align-items-center mb-3">
		<h3 class="mb-3">주문목록조회</h3>

		<div class="d-flex align-items-center gap-2">
			<label class="fw-bold">상태별</label> <select id="statusFilter"
				class="form-select form-select-sm" style="width: 130px;">
				<option value="" ${empty currentStatus ? 'selected' : '' }>전체보기</option>

				<option value="주문완료" ${currentStatus == '주문완료' ? 'selected' : '' }>주문완료</option>
				<option value="상품준비중" ${currentStatus == '상품준비중' ? 'selected' : '' }>상품준비중</option>
				<option value="배송준비" ${currentStatus == '배송준비' ? 'selected' : '' }>배송준비</option>
				<option value="배송중" ${currentStatus == '배송중' ? 'selected' : '' }>배송중</option>
				<option value="배송완료" ${currentStatus == '배송완료' ? 'selected' : ''}>배송완료</option>
			</select>
		</div>
	</div>

	<div class="row fw-bold text-center border-bottom pt-2 pb-2 bg-light">
		<div class="col-2">주문일시</div>
		<div class="col-2">주문번호</div>
		<div class="col-2">결제금액</div>
		<div class="col-4">상태변경</div>
		<div class="col-2">배송</div>
	</div>

	<c:choose>
		<c:when test="${empty orderList }">
			<div class="text-center py-5 text-muted">주문 내역이 없습니다</div>
		</c:when>
		<c:otherwise>
			<c:forEach var="o" items="${orderList}">
				<div
					class="row align-items-center text-center border-bottom rounded py-2 mb-2">

					<div class="col-2">
						<fmt:formatDate value="${o.orderDate}" pattern="yyyy-MM-dd" />
					</div>

					<div class="col-2 fw-semibold text-primary">${o.orderId}</div>

					<div class="col-2">
						<fmt:formatNumber value="${o.totalAmount}" pattern="#,###" />
						원
					</div>

					<div class="col-4 d-flex justify-content-center gap-2">
						<select class="form-select form-select-sm status-select"
							style="width: 120px;">
							<option value="주문완료" ${o.orderStatus == '주문완료' ? 'selected' : ''}>주문완료</option>
							<option value="상품준비중" ${o.orderStatus == '상품준비중' ? 'selected' : ''}>상품준비중</option>
							<option value="배송준비" ${o.orderStatus == '배송준비' ? 'selected' : ''}>배송준비</option>
							<option value="배송중" ${o.orderStatus == '배송중'   ? 'selected' : ''}>배송중</option>
							<option value="배송완료" ${o.orderStatus == '배송완료' ? 'selected' : ''}>배송완료</option>
						</select>
						<button class="btn btn-sm btn-outline-primary btn-update-status"
							data-id="${o.orderId}">변경</button>
					</div>

					<div class="col-2">
						<button type="button" class="btn btn-sm btn-outline-secondary btn-tracking"
						data-status=${o.orderStatus }>배송조회</button>
					</div>

				</div>
			</c:forEach>
		</c:otherwise>
	</c:choose>
	
	<div class="modal fade" id="shippingModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title font-weight-bold">배송 현황</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" id="shippingModalContent">
                <div class="text-center py-5">
                    <div class="spinner-border text-primary" role="status">
                        <span class="sr-only">Loading...</span>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">닫기</button>
            </div>
        </div>
    </div>
</div>


	
	<c:if test="${not empty orderList}">
  <nav aria-label="Page navigation" class="mt-4">
    <ul class="pagination justify-content-center">
      
      <c:if test="${pageInfo.hasPrev}">
        <li class="page-item">
          <a class="page-link" href="#" onclick="goPage(${pageInfo.startPage - 1}); return false;">&laquo;</a>
        </li>
      </c:if>

      <c:forEach begin="${pageInfo.startPage}" end="${pageInfo.endPage}" var="p">
        <li class="page-item ${p == pageInfo.currentPage ? 'active' : ''}">
          <a class="page-link" href="#" onclick="goPage(${p}); return false;">${p}</a>
        </li>
      </c:forEach>

      <c:if test="${pageInfo.hasNext}">
        <li class="page-item">
          <a class="page-link" href="#" onclick="goPage(${pageInfo.endPage + 1}); return false;">&raquo;</a>
        </li>
      </c:if>
      
    </ul>
  </nav>
</c:if>

</div>

<script>

	var globalCurrentPage = "${pageInfo.currentPage}" || 1;

	function goPage(page) {
		var status = $("#statusFilter").val();

		var url = window.CTX + "/admin/tab/order?status="
				+ encodeURIComponent(status) + "&page=" + page + "&_t="
				+ new Date().getTime();

		if (typeof loadTab === 'function') {
			loadTab(url);
		} else {
			location.href = url;
		}
	}

	$(document).off('change', '#statusFilter').on('change', '#statusFilter',
			function() {
				goPage(1);
			});

	$(document).off('click', '.btn-update-status').on(
			'click',
			'.btn-update-status',
			function() {
				var orderId = $(this).data('id');
				var status = $(this).siblings('.status-select').val();

				if (!confirm("주문번호 [" + orderId + "] 상태를 [" + status
						+ "] 로 변경하시겠습니까?"))
					return;

				$.ajax({
					url : window.CTX + "/admin/tab/order/updateStatus",
					method : "POST",
					data : {
						orderId : orderId,
						status : status
					},
					success : function(res) {
						if (res === "OK") {
							alert("변경되었습니다.");
							goPage(globalCurrentPage);
						} else {
							alert("변경 실패했습니다.");
						}
					},
					error : function(err) {
						console.error(err);
						alert("서버 통신 오류");
					}
				});
			});
</script>


<script>
$(document).ready(function() {
    
    $(document).on('click', '.btn-tracking', function() {
        var status = $(this).data('status'); 
        var modalContent = $('#shippingModalContent');
        
        $('#shippingModal').modal('show');
        
        
        var loadUrl = window.CTX + "/admin/modal/shipping";
        

        
        modalContent.load(loadUrl, function(response, statusText, xhr) {
            if (statusText == "error") {
                modalContent.html("<p class='text-center text-danger'>정보를 불러오는데 실패했습니다.</p>");
                return;
            }
            

            updateShippingProgress(status);
        });
    });

   
    function updateShippingProgress(currentStatus) {
        
        var steps = ['PAYMENT_DONE', 'PREPARING', 'DELIVERY_READY', 'SHIPPING', 'DELIVERY'];
        
 
        var statusIndex = -1;
        if (currentStatus === '주문완료' || currentStatus === '결제완료') statusIndex = 0;
        else if (currentStatus === '상품준비중') statusIndex = 1;
        else if (currentStatus === '배송준비') statusIndex = 2;
        else if (currentStatus === '배송중') statusIndex = 3;
        else if (currentStatus === '배송완료') statusIndex = 4;

        
        var imgPath = window.CTX + '/resources/img/';

       
        $('#shippingModalContent .step-img').each(function(index) {
            var stepName = steps[index];
            var isPassed = index <= statusIndex;
            
          
            var suffix = isPassed ? '_on.png' : '_off.png';
            
            $(this).attr('src', imgPath + stepName + suffix);
            
            
            if(isPassed) {
                $(this).next('span').addClass('font-weight-bold text-success').removeClass('text-muted');
            } else {
                $(this).next('span').removeClass('font-weight-bold text-success').addClass('text-muted');
            }
        });
    }
});
</script>