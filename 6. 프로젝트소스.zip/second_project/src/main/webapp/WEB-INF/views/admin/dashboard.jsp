<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>관리자페이지</title>
<!-- Bootstrap (부모에 1번만) -->
<link rel="stylesheet" href="<c:url value='/resources/css/admin_orderlist.css'/>">
<link rel="stylesheet" href="<c:url value='/resources/css/admin_dashboard.css'/>">
<link rel="stylesheet" href="<c:url value='/resources/css/admin_product.css'/>">

<%@ include file="/WEB-INF/views/includes/config.jsp" %>
</head>

<body>
<%@ include file="/WEB-INF/views/includes/admin_header.jsp" %>
	
<div class="mypage-wrap">

  <!-- 메뉴 -->
  <div class="mypage-menu">
    <ul>
      <li><a href="#" data-tab="chart" data-url="${pageContext.request.contextPath}/admin/tab/chart">매출정보</a></li>
	  <li><a href="#" data-tab="product" data-url="${pageContext.request.contextPath}/admin/tab/product">상품관리</a></li>
	  <li><a href="#" data-tab="orderlist" data-url="${pageContext.request.contextPath}/admin/tab/order">주문목록조회</a></li>
	  <li><a href="#" data-tab="recommend" data-url="${pageContext.request.contextPath}/admin/tab/recommend">추천상품등록</a></li>
  	  <li><a href="#" data-tab="discount" data-url="${pageContext.request.contextPath}/admin/tab/event">이벤트/할인</a></li>
	  <li><a href="#" data-tab="expire" data-url="${pageContext.request.contextPath}/admin/tab/expire">마감임박</a></li>
    </ul>
  </div>

  
  <div class="mypage-content" id="mypageContent"></div>
</div>


<div class="modal fade" id="productRegisterModal" tabindex="-1">
  <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
    <div class="modal-content">

      <div class="modal-header">
        <h5 class="modal-title">상품 등록</h5>
        <!-- 닫기 버튼 (정상 동작) -->
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body">
        <!-- 폼은 분리해서 include -->
        <jsp:include page="/WEB-INF/views/admin/tab/register.jsp"/>

      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">취소</button>
       <button type="button" class="btn btn-success" id="btnProductInsert">저장</button>
      </div>

    </div>
  </div>
</div>


<script>
  window.CTX = "${pageContext.request.contextPath}";
</script>


<script>
function getCtx() {
	  // /controller/admin/dashboard 같은 경로에서 /controller만 뽑기
	  const p = location.pathname; 
	  const first = p.split("/")[1]; 
	  // 프로젝트가 /controller 고정이면 그냥 return "/controller";
	  return "/" + first;
	}
	const CTX = window.CTX || getCtx();
</script>
<script>
function setActive(tab){
  // 메뉴 a들 active 정리
  document.querySelectorAll(".mypage-menu a[data-tab]").forEach(el => {
    el.classList.remove("active");
  });

  // 현재 탭만 active
  const cur = document.querySelector(`.mypage-menu a[data-tab="${tab}"]`);
  if (cur) cur.classList.add("active");
}
</script>

<script>
  const content = document.getElementById("mypageContent");

  function loadTab(url) {
	  // CTX 자동 보정
	  const fullUrl = url.startsWith(CTX)
	    ? url
	    : (url.startsWith("/") ? CTX + url : CTX + "/" + url);

	  console.log("[loadTab]", url, "=>", fullUrl);

	  fetch(fullUrl, { headers: { "X-Requested-With": "XMLHttpRequest" } })
	    .then(res => {
	      if (!res.ok) throw new Error("HTTP " + res.status);
	      return res.text();
	    })
	    .then(html => {
	      $(content).html(html);
	      cleanupModalBackdrops(); // ✅ 여기서만
	    })
	    .catch(err => {
	      console.error("[loadTab] 실패:", err);
	      $(content).html( "<p>탭을 불러오지 못했습니다.</p>");
	      cleanupModalBackdrops(); // ✅ 실패해도 여기서
	    });
	}
  function cleanupModalBackdrops() {
	  document.querySelectorAll(".modal-backdrop").forEach(b => b.remove());
	  document.body.classList.remove("modal-open");
	  document.body.style.removeProperty("padding-right");
	}


  //상단헤더/사이드메뉴 모두 커버 (a[data-url]이면 다 잡힘)
  document.addEventListener("click", (e) => {
    const a = e.target.closest("a[data-url]");
    if (!a) 
    	return;

    e.preventDefault();
    if (!content) 
    	return;
	
    const tab = a.dataset.tab; // ✅ 추가
    if (tab) setActive(tab); 
    
    // (선택) 사이드 메뉴 active 처리(헤더는 제외하고 싶으면 조건 걸기)
    const li = a.closest(".mypage-menu li");
    if (li) {
      document.querySelectorAll(".mypage-menu li").forEach(x => x.classList.remove("active"));
      li.classList.add("active");
    }

    loadTab(a.dataset.url);
  });

  // 첫 탭 자동 로드(사이드 메뉴 우선)
  const first = document.querySelector(".mypage-menu a[data-url]") || document.querySelector("a[data-url]");
  if (first && content) loadTab(first.dataset.url);
</script>

<script>
  function openStockModal(prodId, name, stock) {
    document.getElementById("stockProdId").value = prodId;
    document.getElementById("stockProdName").value = name;
    document.getElementById("stockQuantity").value = stock;

    const modal = new bootstrap.Modal(
      document.getElementById("stockUpdateModal")
    );
    modal.show();
  }

  function loadProductTab() {
	  fetch(window.CTX + "/admin/tab/product")   // ⚠️ 너 프로젝트의 상품탭 URL로 맞춰야 함
	    .then(res => res.text())
	    .then(html => {
	      document.getElementById("mypageContent").innerHTML = html; // 탭 컨테이너 id에 맞게
	    });
	}
  

</body>
</html>
