<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<jsp:useBean id="today" class="java.util.Date" />
<c:set var="oneDay" value="${1000 * 60 * 60 * 24}" />

<fmt:formatDate var="todayStr" value="${today}" pattern="yyyy-MM-dd" />
<fmt:parseDate var="nowDate" value="${todayStr}" pattern="yyyy-MM-dd" />

<div class="container-fluid mt-3">
  <h3 class="mb-4">마감임박 및 재고 관리</h3>

  <div id="expireArea">
    
    <div class="d-flex justify-content-between align-items-end mb-2">
      <h5 class="mb-0 text-primary">
        <i class="bi bi-clock-history"></i> 마감임박 상품 (D-7 이내)
        <small class="text-muted fs-6 ms-2">- '알뜰상품(Outlet)'으로 이동 대상</small>
      </h5>
      <button type="button" id="btnMigrate" class="btn btn-primary btn-sm px-3">
        <i class="bi bi-arrow-repeat"></i> 알뜰상품으로 이동 (일괄 적용)
      </button>
    </div>

    <table class="table table-bordered align-middle mb-5 table-hover shadow-sm">
      <thead class="table-light">
        <tr class="text-center">
          <th>상품ID</th>
          <th>이미지</th>
          <th>상품명</th>
          <th>정상가</th>
          <th>D-day</th>
          <th>유통기한</th>
          <th>현재재고</th>
        </tr>
      </thead>
      <tbody>
        <c:set var="hasNearExpire" value="false" />
        
        <c:forEach var="p" items="${productList}">
          <c:if test="${not empty p.expDate and p.prodStatus eq '1'}">
             
             <fmt:formatDate var="expStr" value="${p.expDate}" pattern="yyyy-MM-dd" />
             <fmt:parseDate var="expDateZero" value="${expStr}" pattern="yyyy-MM-dd" />

             <c:set var="diffTime" value="${expDateZero.time - nowDate.time}" />
             <fmt:parseNumber var="daysLeft" value="${diffTime / oneDay}" integerOnly="true" />

             <c:if test="${daysLeft >= 0 and daysLeft <= 7 and p.isOutlet eq '0' and p.stockQuantity > 0}">
                <c:set var="hasNearExpire" value="true" />
                
                <tr class="text-center">
                  <td>${p.prodId}</td>
                  <td>
                    <img src="${pageContext.request.contextPath}/product/image/${p.prodId}" style="width:50px; height:50px; object-fit:cover;" class="rounded">
                  </td>
                  <td class="text-start fw-bold text-primary">${p.name}</td>
                  <td><fmt:formatNumber value="${p.price}" pattern="#,###"/>원</td>
                  <td><span class="badge bg-warning text-dark">D-${daysLeft}</span></td>
                  <td><fmt:formatDate value="${p.expDate}" pattern="yyyy-MM-dd"/></td>
                  <td>${p.stockQuantity}개</td>
                </tr>
             </c:if>
          </c:if>
        </c:forEach>

        <c:if test="${not hasNearExpire}">
          <tr><td colspan="7" class="text-center text-muted py-3">마감임박 상품이 없습니다.</td></tr>
        </c:if>
      </tbody>
    </table>


    <div class="d-flex justify-content-between align-items-end mb-2 border-top pt-4">
      <h5 class="mb-0 text-danger">
        <i class="bi bi-exclamation-triangle-fill"></i> 만료된 상품
        <small class="text-muted fs-6 ms-2">- 판매 중지 대상</small>
      </h5>
      <button type="button" id="btnStop" class="btn btn-danger btn-sm px-3">
        <i class="bi bi-x-circle"></i> 판매 중지 (일괄 적용)
      </button>
    </div>

    <table class="table table-bordered align-middle mb-4 table-hover shadow-sm" style="background-color: #fff5f5;">
      <thead class="table-danger">
        <tr class="text-center">
          <th>상품ID</th>
          <th>이미지</th>
          <th>상품명</th>
          <th>상태</th>
          <th>D-day</th>
          <th>유통기한</th>
          <th>남은재고</th>
        </tr>
      </thead>
      <tbody>
        <c:set var="hasExpired" value="false" />
        
        <c:forEach var="p" items="${productList}">
          <c:if test="${not empty p.expDate and p.prodStatus eq '1'}">
             
             <fmt:formatDate var="expStr" value="${p.expDate}" pattern="yyyy-MM-dd" />
             <fmt:parseDate var="expDateZero" value="${expStr}" pattern="yyyy-MM-dd" />

             <c:set var="diffTime" value="${expDateZero.time - nowDate.time}" />
             <fmt:parseNumber var="daysLeft" value="${diffTime / oneDay}" integerOnly="true" />

             <c:if test="${daysLeft < 0}">
                <c:set var="hasExpired" value="true" />

                <tr class="text-center text-danger">
                  <td>${p.prodId}</td>
                  <td>
                    <img src="${pageContext.request.contextPath}/product/image/${p.prodId}" style="width:50px; height:50px; object-fit:cover;" class="rounded opacity-50">
                  </td>
                  <td class="text-start text-decoration-line-through">${p.name}</td>
                  <td><span class="badge bg-danger">EXPIRED</span></td>
                  <td class="fw-bold">만료 (D${daysLeft})</td>
                  <td><fmt:formatDate value="${p.expDate}" pattern="yyyy-MM-dd"/></td>
                  <td>${p.stockQuantity}개</td>
                </tr>
             </c:if>
          </c:if>
        </c:forEach>

        <c:if test="${not hasExpired}">
          <tr><td colspan="7" class="text-center text-muted py-3">만료된 상품이 없습니다.</td></tr>
        </c:if>
      </tbody>
    </table>

  </div>
</div>

<script>
// ■ 機能1: 訳あり品へ移行 (Migrate)
$(document).off('click', '#btnMigrate').on('click', '#btnMigrate', function() {
    if(!confirm("【마감임박 상품 관리】\n\n목록에 있는 상품들을 '알뜰상품(Outlet)'으로 이동하시겠습니까?\n(기존 정품 재고는 0이 되며, 새로운 할인 상품이 등록됩니다.)")) return;

    const btn = this; 
    const originalText = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> 처리중...';

    $.ajax({
        url: window.CTX + "/admin/tab/expire/migrate",
        method: "POST",
        success: function(res) {
            if(res.startsWith("OK")) {
                let count = res.split(":")[1];
                alert("처리 완료! " + count + "건 이동됨");
                loadTab(window.CTX + "/admin/tab/expire");
            } else {
                alert("처리 실패");
            }
        },
        error: function(){ alert("통신 오류"); },
        complete: function(){ 
            btn.disabled = false; 
            btn.innerHTML = originalText;
        }
    });
});

// ■ 機能2: 期限切れ停止 (Stop)
$(document).off('click', '#btnStop').on('click', '#btnStop', function() {
    if(!confirm("【만료 상품 관리】\n\n유통기한이 지난 상품들의 판매 상태를 '중지'로 변경하시겠습니까?")) return;

    const btn = this; 
    const originalText = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> 처리중...';

    $.ajax({
        url: window.CTX + "/admin/tab/expire/stop",
        method: "POST",
        success: function(res) {
            if(res.startsWith("OK")) {
                let count = res.split(":")[1];
                alert("처리 완료! " + count + "건 정지됨");
                loadTab(window.CTX + "/admin/tab/expire");
            } else {
                alert("처리 실패");
            }
        },
        error: function(){ alert("통신 오류"); },
        complete: function(){ 
            btn.disabled = false;
            btn.innerHTML = originalText;
        }
    });
});
</script>