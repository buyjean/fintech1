<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<style>

  .table-input { border: 1px solid #dee2e6; border-radius: 4px; padding: 4px 8px; width: 100%; font-size: 0.9rem; }
  .table-select { border: 1px solid #dee2e6; border-radius: 4px; padding: 4px 24px 4px 8px; width: 100%; font-size: 0.9rem; }
  .date-input { background-color: #fff !important; cursor: pointer; text-align: center; font-size: 0.9rem; }
  

  .badge-status { font-size: 0.8rem; padding: 5px 8px; border-radius: 4px; white-space: nowrap; font-weight: 500; }
  .bg-active { background-color: #d1e7dd; color: #0f5132; }
  .bg-future { background-color: #cfe2ff; color: #084298; }
  .bg-end { background-color: #f8d7da; color: #842029; }


  .action-btn { width: 36px; height: 36px; padding: 0; display: inline-flex; align-items: center; justify-content: center; border-radius: 4px; }
</style>

<div class="container-fluid mt-3">

  <div class="d-flex justify-content-between align-items-center mb-3">
    <h3>이벤트/할인 관리 (Event Management)</h3>
    <button type="button" class="btn btn-primary shadow-sm" id="btnOpenEventModal">
      <i class="fas fa-calendar-plus mr-2"></i> 새 이벤트 등록
    </button>
  </div>

  <div class="table-responsive">
    <table class="table table-hover shadow-sm border align-middle bg-white">
      <thead class="table-light text-center">
        <tr>
          <th width="5%">ID</th>
          <th width="8%">상태</th>
          <th width="20%">이벤트명 (Title)</th>
          <th width="15%">대상 카테고리</th>
          <th width="10%">할인율(%)</th>
          <th width="25%">기간 (Period)</th>
          <th width="17%">관리 (Action)</th>
        </tr>
      </thead>
      <tbody>
        <jsp:useBean id="now" class="java.util.Date" />
        <c:forEach var="e" items="${eventList}">
          <tr>
            <td class="text-center text-muted">${e.eventId}</td>
            
            <td class="text-center">
              <c:choose>
                <c:when test="${e.endDate < now}">
                  <span class="badge-status bg-end">종료</span>
                </c:when>
                <c:when test="${e.startDate > now}">
                  <span class="badge-status bg-future">예정</span>
                </c:when>
                <c:otherwise>
                  <span class="badge-status bg-active">진행중</span>
                </c:otherwise>
              </c:choose>
            </td>

            <td>
              <input type="text" class="table-input" id="title-${e.eventId}" value="${e.title}">
            </td>
            
            <td>
              <select class="table-select" id="cat-${e.eventId}">
                <c:forEach var="cat" items="${categoryList}">
                  <option value="${cat.categoryId}" ${cat.categoryId == e.targetCat ? 'selected' : ''}>
                    ${cat.categoryName}
                  </option>
                </c:forEach>
              </select>
            </td>
            
            <td>
              <input type="number" class="table-input text-end" id="rate-${e.eventId}" value="${e.discountRate}" min="1" max="99">
            </td>
            
            <td>
              <div class="input-group input-group-sm">
                <input type="text" class="form-control date-input flatpickr-row" 
                       id="date-${e.eventId}" 
                       data-start="<fmt:formatDate value='${e.startDate}' pattern='yyyy-MM-dd'/>"
                       data-end="<fmt:formatDate value='${e.endDate}' pattern='yyyy-MM-dd'/>"
                       placeholder="YYYY-MM-DD">
              </div>
            </td>
            
            <td class="text-center">
              <button type="button" class="btn btn-success action-btn btn-update-event mr-1" data-id="${e.eventId}" title="저장 (Save)">
                <i class="fas fa-save"></i>
              </button>
              <button type="button" class="btn btn-outline-danger action-btn btn-delete-event" data-id="${e.eventId}" title="삭제 (Delete)">
                <i class="fas fa-trash-alt"></i>
              </button>
            </td>
          </tr>
        </c:forEach>
        
        <c:if test="${empty eventList}">
          <tr><td colspan="7" class="text-center py-5 text-muted">등록된 이벤트가 없습니다.</td></tr>
        </c:if>
      </tbody>
    </table>
  </div>

</div>

<div class="modal fade" id="eventModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header bg-primary text-white">
        <h5 class="modal-title"><i class="fas fa-tags mr-2"></i> 새 할인 이벤트</h5>
        <button type="button" class="close text-white" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
        <form id="eventForm">
          <div class="form-group mb-3">
            <label class="form-label fw-bold">이벤트명</label>
            <input type="text" class="form-control" name="title" placeholder="예: 주말 한정 세일" required>
          </div>
          <div class="row mb-3">
            <div class="col-6">
              <label class="form-label fw-bold">대상 카테고리</label>
              <select class="form-control" name="targetCat">
                <c:forEach var="cat" items="${categoryList}">
                  <option value="${cat.categoryId}">${cat.categoryName}</option>
                </c:forEach>
              </select>
            </div>
            <div class="col-6">
              <label class="form-label fw-bold">할인율 (%)</label>
              <input type="number" class="form-control text-end" name="discountRate" value="10" min="1" max="90" required>
            </div>
          </div>
          <div class="form-group mb-3">
            <label class="form-label fw-bold">기간 설정</label>
            <div class="input-group">
              <div class="input-group-prepend">
                <span class="input-group-text"><i class="fas fa-calendar-alt"></i></span>
              </div>
              <input type="text" class="form-control bg-white" id="modalDateRange" placeholder="Start Date ~ End Date" readonly>
            </div>
            <input type="hidden" name="startDate" id="newStart">
            <input type="hidden" name="endDate" id="newEnd">
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">취소</button>
        <button type="button" class="btn btn-primary" id="btnSaveEvent">
          <i class="fas fa-save mr-1"></i> 등록하기
        </button>
      </div>
    </div>
  </div>
</div>

<script>
$(document).ready(function() {
    

    $(".flatpickr-row").each(function() {
        const start = $(this).data("start");
        const end = $(this).data("end");
        
        $(this).flatpickr({
            mode: "range",
            locale: "ko",
            dateFormat: "Y-m-d",
            defaultDate: [start, end]
        });
    });


    $(document).off('click', '.btn-update-event').on('click', '.btn-update-event', function() {
        const id = $(this).data("id");
        const title = $("#title-" + id).val();
        const cat = $("#cat-" + id).val();
        const rate = $("#rate-" + id).val();
        
        // 日付取得
        const fp = document.querySelector("#date-" + id)._flatpickr;
        const selectedDates = fp.selectedDates;

        if (selectedDates.length < 2) {
            alert("기간을 정확히 설정해주세요 (시작일 ~ 종료일)"); return;
        }
        const startDate = fp.formatDate(selectedDates[0], "Y-m-d");
        const endDate = fp.formatDate(selectedDates[1], "Y-m-d");

        if(!confirm("이벤트를 수정하시겠습니까?")) return;

        $.ajax({
            url: window.CTX + "/admin/event/update",
            method: "POST",
            data: {
                eventId: id,
                title: title,
                targetCat: cat,
                discountRate: rate,
                startDate: startDate,
                endDate: endDate
            },
            success: function(res) {
                if(res.trim() === "OK") {
                    alert("수정되었습니다.");
                    loadTab(window.CTX + "/admin/tab/event");
                } else { alert("수정 실패: " + res); }
            }
        });
    });


    $(document).off('click', '.btn-delete-event').on('click', '.btn-delete-event', function() {
        if(!confirm("정말로 삭제하시겠습니까?")) return;
        $.ajax({
            url: window.CTX + "/admin/event/delete",
            method: "POST",
            data: { eventId: $(this).data("id") },
            success: function(res) {
                if(res.trim() === "OK") loadTab(window.CTX + "/admin/tab/event");
                else alert("삭제 실패");
            }
        });
    });


    $("#btnOpenEventModal").click(function() { $("#eventModal").modal('show'); });
    
    $("#modalDateRange").flatpickr({
        mode: "range",
        locale: "ko",
        dateFormat: "Y-m-d",
        minDate: "today",
        onClose: function(dates, str, inst) {
            if (dates.length === 2) {
                $("#newStart").val(inst.formatDate(dates[0], "Y-m-d"));
                $("#newEnd").val(inst.formatDate(dates[1], "Y-m-d"));
            }
        }
    });

    $("#btnSaveEvent").click(function() {
        if(!$("#newStart").val() || !$("#newEnd").val()) { alert("기간을 입력해주세요."); return; }
        if(!confirm("등록하시겠습니까?")) return;
        
        $.ajax({
            url: window.CTX + "/admin/event/insert",
            method: "POST",
            data: $("#eventForm").serialize(),
            success: function(res) {
                if(res.trim() === "OK") {
                    alert("등록되었습니다.");
                    $("#eventModal").modal('hide');
                    $('.modal-backdrop').remove();
                    loadTab(window.CTX + "/admin/tab/event");
                } else alert("실패");
            }
        });
    });
});
</script>