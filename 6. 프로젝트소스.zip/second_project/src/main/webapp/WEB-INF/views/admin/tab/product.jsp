<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<style>
  .table-input { border: 1px solid #dee2e6; border-radius: 4px; padding: 6px 8px; width: 100%; font-size: 0.95rem; background-color: #fff; transition: border-color 0.15s ease-in-out; }
  .table-input:focus { border-color: #86b7fe; outline: 0; box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25); }
  .price-input-wrapper { max-width: 140px; margin: 0 auto; flex-wrap: nowrap !important; }
  .price-input-wrapper .input-group-text { background-color: #f8f9fa; color: #666; font-size: 0.9rem; }
  .stock-input-wrapper { display: flex; align-items: center; justify-content: center; gap: 5px; }
  .stock-input { width: 70px; text-align: center; }
  .action-btn-area { display: flex; justify-content: center; gap: 8px; }
  .action-btn { width: 38px; height: 34px; display: flex; align-items: center; justify-content: center; border-radius: 6px; padding: 0; }
  .action-btn i { font-size: 1.1rem; }
  .product-img-sm { width: 50px; height: 50px; object-fit: cover; border-radius: 4px; border: 1px solid #eee; }
  .nav-tabs .nav-link { color: #495057; font-weight: 500; cursor: pointer; }
  .nav-tabs .nav-link.active { color: #0d6efd; font-weight: bold; border-top: 3px solid #0d6efd; }
  .table > tbody > tr > td { vertical-align: middle; }
</style>

<div class="container-fluid mt-3">
  
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h3>상품 관리 (Product Management)</h3>
    <button type="button" class="btn btn-primary" id="btnOpenRegisterModal">
      <i class="bi bi-plus-lg"></i> 신규 상품 등록
    </button>
  </div>

  <ul class="nav nav-tabs mb-3" id="productTabs" role="tablist">
    <li class="nav-item">
      <a class="nav-link active" id="selling-tab" data-toggle="tab" href="#selling-pane" role="tab" aria-controls="selling-pane" aria-selected="true">
        <i class="bi bi-shop"></i> 판매중 (Selling)
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" id="stopped-tab" data-toggle="tab" href="#stopped-pane" role="tab" aria-controls="stopped-pane" aria-selected="false">
        <i class="bi bi-pause-circle"></i> 판매중지 (Stopped)
      </a>
    </li>
  </ul>

  <div class="tab-content" id="productTabContent">
    
    <div class="tab-pane fade show active" id="selling-pane" role="tabpanel">
      <div class="table-responsive">
        <table class="table table-hover shadow-sm border">
          <thead class="table-light text-center">
            <tr>
              <th width="5%">ID</th>
              <th width="8%">이미지</th>
              <th width="10%">카테고리</th>
              <th width="22%">상품명</th>
              <th width="15%">가격</th>
              <th width="15%">재고 / 초기화</th>
              <th width="25%">관리</th>
            </tr>
          </thead>
          <tbody>
            <c:set var="hasActive" value="false" />
            <c:forEach var="p" items="${productList}">
              <c:if test="${p.prodStatus eq '1'}">
                <c:set var="hasActive" value="true" />
                <tr>
                  <td class="text-center text-muted">${p.prodId}</td>
                  <td class="text-center">
                    <img src="${pageContext.request.contextPath}/resources/images/${not empty p.image ? p.image : 'no-image.png'}" class="product-img-sm">
                  </td>
                  <td class="text-center">
                    <span class="badge bg-white text-dark border">${p.categoryName}</span>
                  </td>
                  <td><input type="text" class="table-input" id="name-${p.prodId}" value="${p.name}"></td>
                  <td>
                    <div class="input-group input-group-sm price-input-wrapper">
                      <input type="number" class="table-input text-end" id="price-${p.prodId}" value="${p.price}">
                      <span class="input-group-text">₩</span>
                    </div>
                  </td>
                  <td>
                    <div class="stock-input-wrapper">
                      <input type="number" class="table-input stock-input" id="stock-${p.prodId}" value="${p.stockQuantity}">
                      <c:if test="${p.stockQuantity > 0}">
                        <button type="button" class="btn btn-warning btn-sm action-btn shadow-sm btn-migrate-one" 
                                data-id="${p.prodId}" title="Outlet으로">
                          <i class="bi bi-arrow-repeat"></i>
                        </button>
                      </c:if>
                    </div>
                  </td>
                  <td class="text-center">
                    <div class="action-btn-area">
                      <button type="button" class="btn btn-success action-btn btn-update-row" data-id="${p.prodId}" title="Save">
                        <i class="bi bi-check-lg"></i>
                      </button>
                      <button type="button" class="btn btn-secondary action-btn btn-product-toggle" data-id="${p.prodId}" data-action="stop" title="Stop">
                        <i class="bi bi-pause-fill"></i>
                      </button>
                      <button type="button" class="btn btn-danger action-btn btn-product-delete" data-id="${p.prodId}" title="Delete">
                        <i class="bi bi-trash"></i>
                      </button>
                    </div>
                  </td>
                </tr>
              </c:if>
            </c:forEach>
            <c:if test="${not hasActive}">
              <tr><td colspan="7" class="text-center p-5 text-muted">판매중인 상품이 없습니다.</td></tr>
            </c:if>
          </tbody>
        </table>
      </div>
    </div>

    <div class="tab-pane fade" id="stopped-pane" role="tabpanel">
      <div class="table-responsive">
        <table class="table table-hover shadow-sm border bg-light">
          <thead class="table-secondary text-center">
            <tr>
              <th width="5%">ID</th>
              <th width="8%">이미지</th>
              <th width="10%">카테고리</th>
              <th width="22%">상픔명</th>
              <th width="15%">가격</th>
              <th width="15%">재고</th>
              <th width="25%">관리</th>
            </tr>
          </thead>
          <tbody>
            <c:set var="hasStopped" value="false" />
            <c:forEach var="p" items="${productList}">
              <c:if test="${p.prodStatus eq '0'}">
                <c:set var="hasStopped" value="true" />
                <tr class="text-muted">
                  <td class="text-center">${p.prodId}</td>
                  <td class="text-center">
                    <img src="${pageContext.request.contextPath}/resources/images/${not empty p.image ? p.image : 'no-image.png'}" class="product-img-sm opacity-50">
                  </td>
                  <td class="text-center">${p.categoryName}</td>
                  <td>${p.name}</td>
                  <td class="text-center"><fmt:formatNumber value="${p.price}" pattern="#,###"/> ₩</td>
                  <td class="text-center">${p.stockQuantity}</td>
                  <td class="text-center">
                    <div class="action-btn-area">
                      <button type="button" class="btn btn-outline-primary action-btn btn-product-toggle" style="width:auto; padding:0 15px;" data-id="${p.prodId}" data-action="start">
                        <i class="bi bi-play-fill me-1"></i> 판매 재개
                      </button>
                      <button type="button" class="btn btn-outline-danger action-btn btn-product-delete" data-id="${p.prodId}">
                        <i class="bi bi-trash"></i>
                      </button>
                    </div>
                  </td>
                </tr>
              </c:if>
            </c:forEach>
            <c:if test="${not hasStopped}">
              <tr><td colspan="7" class="text-center p-5 text-muted">판매중지된 상품이 없습니다.</td></tr>
            </c:if>
          </tbody>
        </table>
      </div>
    </div>

  </div>
</div>

<div class="modal fade" id="registerModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><i class="bi bi-box-seam"></i> 신규 상품 등록</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="registerModalBody">
        <div class="text-center py-5">
            <div class="spinner-border text-primary" role="status"></div>
            <p>Loading form...</p>
        </div>
      </div>
    </div>
  </div>
</div>


<script>

$(function() {
    $('#productTabs a').on('click', function (e) {
        e.preventDefault();
        $(this).tab('show');
    });
});

$(document).off('click', '#btnOpenRegisterModal').on('click', '#btnOpenRegisterModal', function() {
    $('#registerModal').modal('show');

    $('#registerModalBody').load(window.CTX + "/admin/tab/product/register", function(response, status, xhr) {
        if (status == "error") {
            $('#registerModalBody').html("<div class='alert alert-danger'>폼을 불러오는데 실패했습니다.<br>" + xhr.status + " " + xhr.statusText + "</div>");
        }
    });
});

$(document).off('click', '.btn-update-row').on('click', '.btn-update-row', function() {
    const id = $(this).data('id');
    const name = $("#name-" + id).val();
    const price = $("#price-" + id).val();
    const stock = $("#stock-" + id).val();

    if(!name || price === "" || stock === "") {
        alert("값을 모두 입력해주세요."); return;
    }

    $.ajax({
        url: window.CTX + "/admin/product/update",
        method: "POST",
        data: { prodId: id, name: name, price: price, stockQuantity: stock },
        success: function(res) {
            if(res.trim() === "OK") {
                alert("수정되었습니다.");
                loadTab(window.CTX + "/admin/tab/product");
            } else { alert("수정 실패"); }
        }
    });
});

$(document).off('click', '.btn-migrate-one').on('click', '.btn-migrate-one', function() {
    const id = $(this).data('id');
    if(!confirm("【재고 초기화】\n\n현재 재고를 '알뜰상품(Outlet)'으로 복사하고,\n이 상품의 재고를 0으로 만드시겠습니까?")) return;

    $.ajax({
        url: window.CTX + "/admin/product/migrateOne",
        method: "POST",
        data: { prodId: id },
        success: function(res) {
            if(res.trim() === "OK") {
                alert("처리 완료 (Outlet 등록됨, 재고 0)");
                loadTab(window.CTX + "/admin/tab/product");
            } else { alert("처리 실패"); }
        }
    });
});


$(document).off('click', '.btn-product-toggle').on('click', '.btn-product-toggle', function() {
    const id = $(this).data('id');
    const action = $(this).data('action');
    const msg = (action === 'stop') ? "판매를 중지하시겠습니까?" : "판매를 다시 시작하시겠습니까?";

    if(!confirm(msg)) return;

    $.ajax({
        url: window.CTX + "/admin/product/toggle",
        method: "POST",
        data: { prodId: id },
        success: function(res) {
            if(res.trim() === "OK") loadTab(window.CTX + "/admin/tab/product");
            else alert("상태 변경 실패");
        }
    });
});


$(document).off('click', '.btn-product-delete').on('click', '.btn-product-delete', function() {
    if(!confirm("정말로 영구 삭제하시겠습니까?")) return;
    const id = $(this).data('id');
    
    $.ajax({
        url: window.CTX + "/admin/product/delete",
        method: "POST",
        data: { productId: id },
        success: function(res) {
            if(res.trim() === "OK") loadTab(window.CTX + "/admin/tab/product");
            else alert("삭제 실패");
        }
    });
});
</script>