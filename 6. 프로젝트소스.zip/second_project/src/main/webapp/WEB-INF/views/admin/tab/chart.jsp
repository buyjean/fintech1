<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt"%>

<style>
.dashboard { padding: 10px; }
.dashboard-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
.dashboard-main { display: flex; gap: 20px; flex-wrap: wrap; }

/* 期間指定エリア */
.date-filter { 
    background: #fff; padding: 10px 15px; border-radius: 5px; 
    border: 1px solid #e3e6f0; box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
    display: flex; align-items: center; gap: 10px; 
}
.date-input-group { position: relative; display: flex; align-items: center; }
.date-icon { position: absolute; right: 10px; color: #aaa; pointer-events: none; }

/* flatpickr カスタム (入力欄を少しリッチに) */
.flatpickr-input { 
    background-color: #fff !important; 
    cursor: pointer; 
    border: 1px solid #d1d3e2;
    padding-left: 10px;
}

/* チャート & ランキング */
.chart-column { flex: 2; min-width: 300px; }
.summary-column { flex: 1; min-width: 200px; display: flex; flex-direction: column; gap: 20px; }

.chart-area, .ranking-area { 
    background: #fff; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); 
    padding: 20px; margin-bottom: 20px; 
}
.section-title { font-weight: bold; color: #5a5c69; margin-bottom: 15px; border-bottom: 1px solid #eee; padding-bottom: 10px; }

.summary-box { 
    background: #fff; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); 
    padding: 30px 20px; text-align: center; border-left: 5px solid #4e73df;
}
.summary-box:nth-child(2) { border-left-color: #1cc88a; }
.summary-value { font-size: 2em; font-weight: bold; color: #333; margin: 0; }

/* ランキングテーブル */
.table-ranking th { background-color: #f8f9fa; font-size: 0.9em; }
.rank-badge { background: #4e73df; color: #fff; padding: 2px 8px; border-radius: 10px; font-size: 0.8em; }
</style>
<div class="dashboard"></div>
<h2>대시보드</h2>

<div class="dashboard">

	<div class="daashboard-header">
		<h4 class="text-gray-800 m-0">매출 대시보드</h4>

		<div class="d-flex gap-2">
			<div class="date-filter">
				<input type="date" id="startDate"
					class="form-control form-control-sm" style="width: 130px;">
				<span>~</span> <input type="date" id="endDate"
					class="form-control form-control-sm" style="width: 130px;">
				<button class="btn btn-sm btn-primary" onclick="loadChartData()">
					<i class="fas fa-search"></i>조회
				</button>
			</div>

			<button class="btn btn-sm btn-success" onclick="downloadCSV()">
				<i class="fas fa-download"></i> CSV
			</button>
		</div>
	</div>

	<div class="dashboard-main">

		<!-- 왼쪽: 차트 영역 -->
		<div class="chart-column">

			<div class="chart-area">
				<p class="chart-title">매출 추이</p>
				<div style="height: 300px; positon: relative;">
					<canvas id="dailySalesChart"></canvas>
				</div>
			</div>

			<div class="ranking-area">
				<p class="section-title">
					<i class="fas fa-trophy mr-2"></i>상품별 매출 TOP 5
				</p>
				<table class="table table-sm table-hover table-ranking">
					<thead>
						<tr>
							<th style="width: 10%;">랭킹</th>
							<th>상품명</th>
							<th style="width: 30%" class="text-right">매출액</th>
						</tr>
					</thead>
					<tbody id="rankingBody">

					</tbody>
				</table>
			</div>

			<div class="summary-column">
				<div class="summary-box">
					<p class="text-uppercase text-muted font-weight-bold">오늘자매출</p>
					<p class="summary-value" id="todaySales"></p>
				</div>

				<div class="summary-box">
					<p class="text-uppercase text-muted font-weight-bold">오늘자주문</p>
					<p class="summary-value" id="todayOrderCount"></p>
				</div>
			</div>

			<div class="chart-area">
				<p class="chart-title"><i class="fas fa-chart-pie mr-2"></i> 판매별 매출 비중</p>
				<div style="height: 250px; position: relative;">
					<canvas id="productSalesChart"></canvas>
				</div>
			</div>

		</div>


	</div>
</div>


<script>
// チャートインスタンス保持用
var chartDaily = null;
var chartPie = null;

$(document).ready(function(){
    // --- 日付フォーマット関数 (YYYY-MM-DD形式の文字列を作る) ---
    function formatDate(date) {
        var d = new Date(date),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();

        if (month.length < 2) month = '0' + month;
        if (day.length < 2) day = '0' + day;

        return [year, month, day].join('-');
    }

    // 今日の日付 (時間情報を捨てるために文字列化)
    var todayObj = new Date();
    var lastWeekObj = new Date();
    lastWeekObj.setDate(todayObj.getDate() - 7);

    // 文字列にする ("2026-01-23" のような形)
    var strToday = formatDate(todayObj);
    var strLastWeek = formatDate(lastWeekObj);

    var fpConfig = { 
        locale: "ko", 
        dateFormat: "Y-m-d", 
        allowInput: true 
    };

    $("#startDate").flatpickr(Object.assign({}, fpConfig, { 
        defaultDate: strLastWeek, 
        maxDate: "today" 
    }));

    $("#endDate").flatpickr(Object.assign({}, fpConfig, { 
        defaultDate: strToday,   
        maxDate: "today" 
    }));

    // 初回ロード
    if(typeof window.loadChartData === 'function') {
        window.loadChartData();
    }
});

window.loadChartData = function() {
    var start = $("#startDate").val();
    var end = $("#endDate").val();

   
    if(!start || !end) {        
        return; 
    }

    if(start > end) {
        if(typeof Swal !== 'undefined') Swal.fire({ icon: 'warning', text: '종료일은 시작일보다 이후여야 합니다.' });
        else alert('종료일은 시작일보다 이후여야 합니다.');
        return;
    }

    var $btn = $(".date-filter button");
    var originalText = "";
    if($btn.length) {
        originalText = $btn.html();
        $btn.prop("disabled", true).html('<i class="fas fa-spinner fa-spin"></i>');
    }

    $.ajax({
        url: window.CTX + "/admin/tab/chart/data",
        method: "GET",
        data: { startDate: start, endDate: end },
        dataType: "json",
        success: function(data) {
            window.renderCharts(data);
            window.renderRanking(data.rankingList);
        },
        error: function(err) {
            console.error("Error:", err);
            $("#todaySales").text("Error");
        },
        complete: function() {
            if($btn.length) $btn.prop("disabled", false).html(originalText);
        }
    });
};

// ▼ グラフ描画関数
window.renderCharts = function(data) {
    // テキスト更新
    $("#todaySales").text(Number(data.todaySales).toLocaleString() + " 원");
    $("#todayOrderCount").text(data.todayOrderCount + " 건");

    // 棒グラフ (Canvasが存在する場合のみ描画)
    var canvasDaily = document.getElementById('dailySalesChart');
    if(canvasDaily) {
        if (chartDaily) chartDaily.destroy();
        chartDaily = new Chart(canvasDaily, {
            type: 'bar',
            data: {
                labels: data.dailyLabels,
                datasets: [{
                    label: '매출',
                    data: data.dailyValues,
                    backgroundColor: '#4e73df',
                    hoverBackgroundColor: '#2e59d9',
                    borderRadius: 4, barPercentage: 0.6
                }]
            },
            options: {
                maintainAspectRatio: false,
                scales: { 
                    y: { beginAtZero: true, ticks: { callback: function(val){ return val.toLocaleString(); } } },
                    x: { grid: { display: false } }
                },
                plugins: { legend: { display: false } }
            }
        });
    }

    // 円グラフ
    var canvasPie = document.getElementById('productSalesChart');
    if(canvasPie) {
        if (chartPie) chartPie.destroy();
        chartPie = new Chart(canvasPie, {
            type: 'doughnut',
            data: {
                labels: data.pieLabels,
                datasets: [{
                    data: data.pieValues,
                    backgroundColor: ['#4e73df', '#1cc88a', '#36b9cc', '#f6c23e', '#858796'],
                    hoverOffset: 4
                }]
            },
            options: {
                maintainAspectRatio: false,
                plugins: { legend: { position: 'bottom' } },
                cutout: '70%'
            }
        });
    }
};

// ▼ ランキング描画 (ここをjQuery生成方式に変更して構文エラーを回避)
window.renderRanking = function(list) {
    var $tbody = $("#rankingBody");
    $tbody.empty(); // クリア

    if(!list || list.length === 0) {
        // データなしの場合
        var $tr = $("<tr>").append(
            $("<td>").attr("colspan", 3).addClass("text-center py-3").text("데이터 없음")
        );
        $tbody.append($tr);
    } else {
        // jQueryで要素を一つずつ作って追加 (バッククォートを使わないので安全)
        $.each(list, function(index, item) {
            var badgeClass = "badge-secondary";
            if(item.rank === 1) badgeClass = "badge-danger";
            else if(item.rank === 2) badgeClass = "badge-warning";
            else if(item.rank === 3) badgeClass = "badge-success";

            var $tr = $("<tr>");
            
            // 順位カラム
            var $tdRank = $("<td>").addClass("text-center align-middle");
            var $badge = $("<span>")
                .addClass("badge rounded-circle p-2 " + badgeClass)
                .css({width: "25px", height: "25px", display: "inline-flex", alignItems: "center", justifyContent: "center"})
                .text(item.rank);
            $tdRank.append($badge);

            // 商品名カラム
            var $tdName = $("<td>").addClass("align-middle font-weight-bold").text(item.name);

            // 金額カラム
            var $tdTotal = $("<td>").addClass("text-right align-middle")
                .text(Number(item.total).toLocaleString() + " 원");

            $tr.append($tdRank, $tdName, $tdTotal);
            $tbody.append($tr);
        });
    }
};

// ▼ CSVダウンロード (Toast通知付き)
window.downloadCSV = function() {
    var start = $("#startDate").val();
    var end = $("#endDate").val();
    
    if(typeof Swal !== 'undefined') {
        Swal.fire({
            toast: true, position: 'top-end', icon: 'info',
            title: 'CSV 다운로드를 시작합니다.',
            showConfirmButton: false, timer: 3000, timerProgressBar: true
        });
    }
    window.location.href = window.CTX + "/admin/download/csv?startDate=" + start + "&endDate=" + end;
};
</script>