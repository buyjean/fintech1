<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>

<style>
  .img-preview {
    width: 100px; height: 100px;
    object-fit: cover;
    border: 1px solid #ddd;
    border-radius: 4px;
    margin-top: 5px;
    display: none;
  }
</style>

<div class="container mt-3">
  <h4>상품 등록 (Product Registration)</h4>

  <form id="productRegisterForm" enctype="multipart/form-data" method="post" action="${pageContext.request.contextPath}/admin/product/insert">
  
    <div class="form-group mb-3">
      <label class="form-label">상품명</label>
      <input type="text" class="form-control" name="name" required />
    </div>

    <div class="row mb-3">
      <div class="col-md-6">
        <label class="form-label">카테고리</label>
        <select class="form-control" name="categoryId">
          <c:forEach var="cat" items="${categoryList}">
            <option value="${cat.categoryId}">${cat.categoryName}</option>
          </c:forEach>
        </select>
      </div>
      
      <div class="col-md-6">
        <label class="form-label">정가 (Original Price)</label>
        <input type="number" class="form-control" name="originalPrice" required 
               placeholder="판매가는 정가와 동일하게 저장됩니다."/>
      </div>
    </div>

    <div class="form-group mb-3">
      <label class="form-label">재고 수량</label>
      <input type="number" class="form-control" name="stockQuantity" value="100" required />
    </div>

    <div class="form-group mb-3">
      <label class="form-label">상품 이미지 (Thumbnail)</label>
      <input type="file" class="form-control" name="uploadFile" id="imgInput" accept="image/*">
      <img id="imgPreview" class="img-preview" src="" alt="Preivew">
    </div>

    <div class="form-group mb-3">
      <label class="form-label">설명</label>
      <textarea class="form-control" name="description" rows="3"></textarea>
    </div>

    <div class="row mb-3">
      <div class="col-md-6">
        <label class="form-label">유통기한</label>
        <input type="text" class="form-control bg-white" name="expDate" id="expDateInput" placeholder="날짜 선택" readonly />
      </div>
      <div class="col-md-6">
        <label class="form-label">중량(g)</label>
        <input type="number" class="form-control" name="weight" value="0" />
      </div>
    </div>
    
    <div class="row mb-3">
      <div class="col-md-3"><label>kcal</label><input type="number" class="form-control" name="kcal" value="0" /></div>
      <div class="col-md-3"><label>단백질</label><input type="number" class="form-control" name="protein" value="0" /></div>
      <div class="col-md-3"><label>지방</label><input type="number" class="form-control" name="fat" value="0" /></div>
      <div class="col-md-3"><label>탄수화물</label><input type="number" class="form-control" name="carb" value="0" /></div>
    </div>

    <div class="text-end">
        <button type="submit" class="btn btn-primary">등록하기</button>
    </div>
  </form>
</div>

<script>
// ■ 1. Flatpickr 初期化
$("#expDateInput").flatpickr({
    locale: "ko", 
    dateFormat: "Y-m-d",
    minDate: "today"
});

// ■ 2. 画像プレビュー
$("#imgInput").change(function(){
    const file = this.files[0];
    if(file){
        let reader = new FileReader();
        reader.onload = function(e){ $("#imgPreview").attr("src", e.target.result).show(); }
        reader.readAsDataURL(file);
    } else {
        $("#imgPreview").hide();
    }
});

// ■ 3. 登録処理 (FormData)
$(document).off('submit', '#productRegisterForm').on('submit', '#productRegisterForm', function(e) {
    e.preventDefault();
    if(!confirm("상품을 등록하시겠습니까?")) return;

    let formData = new FormData(this); // 画像含む全データ

    const btn = $(this).find("button[type='submit']");
    btn.prop('disabled', true);

    $.ajax({
        url: window.CTX + "/admin/product/insert",
        method: "POST",
        data: formData,
        processData: false, // 必須
        contentType: false, // 必須
        success: function(res) {
            if(res.trim() === "OK") {
                alert("등록되었습니다.");
                // 親画面リロード & モーダル閉じる
                loadTab(window.CTX + "/admin/tab/product");
                $('.modal.show').modal('hide'); 
            } else {
                alert("등록 실패: " + res);
                btn.prop('disabled', false);
            }
        },
        error: function() { alert("통신 오류"); btn.prop('disabled', false); }
    });
});
</script>