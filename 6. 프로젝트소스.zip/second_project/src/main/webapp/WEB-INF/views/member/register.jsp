<%@ page contentType="text/html; charset=UTF-8" %>

<!DOCTYPE html>
<html>
<link rel="stylesheet" href="${pageContext.request.contextPath}/resources/css/register.css">
<head>
  <meta charset="UTF-8">
  <title>회원가입</title>
 	<script>
 	 const CTX = "${pageContext.request.contextPath}";
	</script>
  <script src="https://t1.daumcdn.net/mapjsapi/bundle/postcode/prod/postcode.v2.js"></script>
  <script src="${pageContext.request.contextPath}/resources/js/address.js"></script>
  <script src="${pageContext.request.contextPath}/resources/js/registercheck.js"></script>
  <%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>
</head>

<body>
<%@ include file="/WEB-INF/views/includes/header.jsp" %>
<div class="signup-container">
  <h2>회원가입</h2>

  <form action="${pageContext.request.contextPath}/member/register"
        method="post"
        onsubmit="return validateForm()">

    <!-- 아이디 -->
    <div class="form-row">
      <label for="userId">아이디</label>
      <input type="text" id="userId" name="userId" required oninput="resetIdCheck()">
      <button type="button" class="btn-sub" onclick="checkIdDuplicate();">중복확인</button>
      <span id="idMessage"></span>
    </div>
    <!-- 비밀번호 -->
    <div class="form-row">
      <label for="password">비밀번호</label>
      <input type="password" id="password" name="password"
             onkeyup="checkPasswordMatch();" required>
      <span id="pwdMatchMessage"></span>
    </div>

    <!-- 비밀번호 확인 -->
    <div class="form-row">
      <label for="confirmUserPw">비밀번호 확인</label>
      <input type="password" id="confirmUserPw"
             onkeyup="checkPasswordMatch();" required>
      <span id="pwdMatchMessage"></span>
    </div>

    <!-- 이름 -->
    <div class="form-row">
      <label for="name">이름</label>
      <input type="text" id="name" name="name" required>
    </div>

    <!-- 이메일 -->
    <div class="form-row">
      <label for="email">이메일</label>
      <input type="email" id="email" name="email" required>
    </div>

    <!-- 전화번호 -->
    <div class="form-row">
      <label for="phone">전화번호</label>
      <input type="text" id="phone" name="phone">
    </div>

	<!-- 생년월일 -->
	<div class="form-row">
	  <label for="birthDate">생년월일</label>
	  <input type="date" id="birthDate" name="birthDate" required>
	</div>
    <!-- 주소 -->
    <div class="form-row">
      <label for="zipcode">주소</label>
      <input type="text" id="zipcode" name="zipcode" readonly placeholder="우편번호">
      <button type="button" class="btn-sub" onclick="execDaumPostcode()">검색</button>
    </div>

    <div class="form-row">
      <label></label>
      <input type="text" id="addrMain" name="addrMain" readonly placeholder="기본주소">
    </div>

    <!-- 상세주소 -->
    <div class="form-row">
      <label for="addrDetail">상세주소</label>
      <input type="text" id="addrDetail" name="addrDetail">
    </div>

    <div class="form-actions">
      <button type="reset" class="btn-cancel">취소</button>
      <button type="submit" class="btn-edit">회원가입</button>
    </div>

  </form>
</div>
</body>
</html>
