<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>마이페이지</title>

<%@ include file="/WEB-INF/views/includes/config.jsp" %>

<link rel="stylesheet" href="${pageContext.request.contextPath}/resources/css/member_mypage.css">
<link rel="stylesheet" href="${pageContext.request.contextPath}/resources/css/member_point.css">
<link rel="stylesheet" href="${pageContext.request.contextPath}/resources/css/member_profile.css">
<link rel="stylesheet" href="${pageContext.request.contextPath}/resources/css/member_receipt.css">
<link rel="stylesheet" href="${pageContext.request.contextPath}/resources/css/member_orders.css">
<link rel="stylesheet" href="${pageContext.request.contextPath}/resources/css/member_orderdetail.css">

<script src="https://t1.daumcdn.net/mapjsapi/bundle/postcode/prod/postcode.v2.js"></script>

<script>
  window.CTX = "${pageContext.request.contextPath}";
</script>

<script defer src="<c:url value='/resources/js/address.js'/>"></script>
<script defer src="<c:url value='/resources/js/registercheck.js'/>"></script>
<script defer src="<c:url value='/resources/js/update.js'/>"></script>
<script defer src="<c:url value='/resources/js/orders.js'/>" > </script>


</head>
<body>
<%@ include file="/WEB-INF/views/includes/navbar.jsp" %>
<script>
  // 전역 함수(비동기 탭에서도 호출)
  window.execDaumPostcode = function () {

    if (!window.daum || !daum.Postcode) {
      alert("주소 검색 스크립트가 아직 로딩되지 않았습니다.\n새로고침 후 다시 시도해주세요.");
      return;
    }

    new daum.Postcode({
      oncomplete: function(data) {

        const zipcode = document.getElementById("zipcode");
        const addrMain = document.getElementById("addrMain");
        const addrDetail = document.getElementById("addrDetail");

        // 비동기 탭이므로 null 체크 필수
        if (zipcode) zipcode.value = data.zonecode;
        if (addrMain) addrMain.value = data.roadAddress;
        if (addrDetail) addrDetail.focus();
      }
    }).open();
  };
</script>

<body>
<div class="mypage-wrap">

  <!-- 메뉴 -->
  <div class="mypage-menu">
    <ul>
     <li>
  		<a href="#" data-url="${pageContext.request.contextPath}/member/tab/point">회원등급</a>
	</li>

	<li>
  		<a href="#" data-url="${pageContext.request.contextPath}/member/tab/orders">주문내역</a>
	</li>

    <li>
        <a href="#" data-url="${pageContext.request.contextPath}/member/tab/profile">회원정보 변경</a>
    </li>

    </ul>
  </div>

 
  <div class="mypage-content" id="mypageContent">
 
  </div>

</div>

<script>
  const content = document.getElementById("mypageContent");
  const links = document.querySelectorAll(".mypage-menu a[data-url]");

  function setActive(link) {
    document.querySelectorAll(".mypage-menu li").forEach(li => li.classList.remove("active"));
    link.closest("li").classList.add("active");
  }

  function loadTab(url) {
    fetch(url, { headers: { "X-Requested-With": "XMLHttpRequest" } })
      .then(res => res.text())
      .then(html => { content.innerHTML = html; })
      .catch(() => { content.innerHTML = "<p>탭을 불러오지 못했습니다.</p>"; });
  }

  links.forEach(a => {
    a.addEventListener("click", (e) => {
      e.preventDefault();
      setActive(a);
      loadTab(a.dataset.url);
    });
  });

 
  const first = document.querySelector(".mypage-menu a[data-url]");
  if (first) {
    setActive(first);
    loadTab(first.dataset.url);
  }
</script>
</body>
</html>
