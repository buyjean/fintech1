<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt"%>

<div class="order-history-container">
	<h3 class="font-weight-bold mb-3">주문 내역</h3>

	<div class="alert alert-light border mb-4" role="alert">
		<i class="fa-solid fa-circle-info text-secondary mr-2"></i> <small
			class="text-muted"> 주문하신 상품의 배송상태를 확인하실 수 있습니다. 주문번호를 클릭 시 주문
			상세내역으로 이동합니다. </small>
	</div>

	<div class="table-responsive">
		<table class="table table-hover table-fixed">
			<colgroup>
				<col style="width: 12%;">
				<col style="width: 28%;">
				<col style="width: 15%;">
				<col style="width: 15%;">
				<col style="width: 15%;">
				<col style="width: 15%;">
			</colgroup>
			<thead>
				<tr>
					<th>주문번호</th>
					<th>상품정보</th>
					<th>주문일자</th>
					<th>배송상태</th>
					<th style="text-align: right;">결제금액</th>
					<th>관리</th>
				</tr>
			</thead>
			<tbody>
				<c:forEach var="order" items="${orderList}">
					<tr>
						<td><a href="#" class="order-link"
							data-order-id="${order.orderId}">${order.orderId} </a></td>

						<td><a
							href="${pageContext.request.contextPath }/member/tab/details"
							class="order-link" data-order-id="${order.orderId}">
								<div class="prod-thumb-container">
									<img alt="상품 이미지"
										src="<c:url value='/resources/img/${order.repImage}'/>"
										class="prod-thumb"
										onerror="this.onerror=null; this.parentNode.innerHTML='<i class=\'
										fa-regular fa-imagetext-secondaryfa-xl\'></i>';">
								</div>
						</a></td>

						<td><span class="text-secondary"> <fmt:formatDate
									value="${order.orderDate}" pattern="yyyy.MM.dd" />
						</span></td>
						<td class="btn-shipping-modal" data-status="${order.orderStatus }" style="cursor:pointer;" ><c:choose>
								<c:when test="${order.orderStatus eq '주문완료' }">
									<span class="badge badge-success status-badge">${order.orderStatus }</span>
								</c:when>
								<c:when test="${order.orderStatus ne '배송완료' }">
									<span class="badge badge-warning status-badge"></span>
								</c:when>
								<c:otherwise>
									<span class="badge badge-secondary status-badge">${order.orderStatus }</span>
								</c:otherwise>
							</c:choose></td>

						<td class="amount-col text-dark"><fmt:formatNumber
								value="${order.totalAmount }" pattern="#,###" />원</td>

						<td>
							<button type="button"
								class="btn btn-sm btn-outline-secondary btn-bill"
								data-order-id="${order.orderId}" title="영수증 보기">
								<i class="fa-solid fa-receipt"></i> 영수증
							</button>
						</td>
					</tr>
				</c:forEach>

				<c:if test="${empty orderList}">
					<tr>
						<td colspan="6" class="text-center py-5">
							<div class="text-muted">
								<i class="fa-regular fa-folder-open fa-2x mb-3"></i><br> 주문
								내역이 존재하지 않습니다.
							</div>
						</td>
					</tr>
				</c:if>
			</tbody>
		</table>

	</div>

</div>
<div id="receiptModal" class="modal fade" tabindex="-1" role="dialog">
	<div class="modal-dialog modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-body" id="receiptContent" style="padding: 0;">
			</div>
			<div class="text-center pb-3">
				<button type="button" class="btn btn-secondary btn-sm modal-close"
					style="width: 80px;">닫기</button>
			</div>
		</div>
	</div>
</div>

<div id="shippingModal" class="modal fade" tabindex="-1" role="dialog">
	<div class="modal-dialog modal-lg modal-dialog-centered"
		role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title font-weight-bold">배송 현황</h5>
				<button type="button" class="close modal-close" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<ul
					class="delivery-steps list-unstyled d-flex justify-content-between">

					<li class="step-item text-center flex-fill" id="step-PAYMENT_DONE">
						<img
						src="${pageContext.request.contextPath}/resources/img/PAYMENT_DONE_off.png"
						class="step-img" id="img-PAYMENT_DONE"> <span>주문완료</span>
					</li>

					<li class="step-item text-center flex-fill" id="step-PREPARING">
						<img
						src="${pageContext.request.contextPath}/resources/img/PREPARING_off.png"
						class="step-img" id="img-PREPARING"> <span>상품준비중</span>
					</li>

					<li class="step-item text-center flex-fill"
						id="step-DELIVERY_READY"><img
						src="${pageContext.request.contextPath}/resources/img/DELIVERY_READY_off.png"
						class="step-img" id="img-DELIVERY_READY"> <span>배송시작</span>
					</li>

					<li class="step-item text-center flex-fill" id="step-SHIPPING">
						<img
						src="${pageContext.request.contextPath}/resources/img/SHIPPING_off.png"
						class="step-img" id="img-SHIPPING"> <span>배송중</span>
					</li>

					<li class="step-item text-center flex-fill" id="step-DELIVERY">
						<img
						src="${pageContext.request.contextPath}/resources/img/DELIVERY_off.png"
						class="step-img" id="img-DELIVERY"> <span>배송완료</span>
					</li>

				</ul>
			</div>
			<div class="modal-footer justify-content-center">
				<button type="button" class="btn btn-secondary btn-sm modal-close"
					style="width: 100px;">닫기</button>
			</div>
		</div>
	</div>
</div>




