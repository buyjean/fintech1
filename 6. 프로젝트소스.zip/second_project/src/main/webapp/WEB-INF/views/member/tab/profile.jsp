<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>


<div class="signup-container">
  <h2>회원정보 변경</h2>

  <form id = "profileForm" action="${pageContext.request.contextPath}/member/edit" method="post">

   <div class="form-row">
  <label>아이디</label>
  <input type="text" name="userId" value="${member.userId}" readonly>
</div>
<div class="form-row">
  <label for="currentPassword">현재 비밀번호</label>
  <input type="password" id="currentPassword" name="currentPassword"
         		onkeyup="nowSamePassword();">
  <span id="nowpwdSameMessage"></span>
</div>
    <div class="form-row">
      <label for="password">새 비밀번호</label>
      <input type="password" id="password" name="password"
         		onkeyup="checkSamePassword();">
  		<span id="pwdSameMessage"></span>
    </div>

    <div class="form-row">
  		<label for="confirmUserPw">비밀번호 확인</label>
    	<input type="password" id="confirmUserPw" name="confirmUserPw"
           onkeyup="checkPasswordMatch();">
    	<span id="pwdMatchMessage" class="form-msg"></span>
	</div>


    <div class="form-row">
  <label>이름</label>
  <input type="text" name="name" value="${member.name}" readonly>
</div>

    <div class="form-row">
  <label>이메일</label>
  <input type="email" name="email" value="${member.email}">
</div>

    <div class="form-row">
      <label for="phone">휴대폰</label>
      <input type="text" id="phone" name="phone" value="${member.phone}">
    </div>
    <div class="form-row">
      <label for="birthdate">생년월일</label>
      <fmt:formatDate value="${member.birthDate}" pattern="yyyy-MM-dd" var="birthStr"/>
      <input type="text" id="birthDate" name="birthDate" value="${birthStr}" readonly>
    </div>

    <div class="form-row">
      <label for="zipcode">주소</label>
      <input type="text" id="zipcode" name="zipcode" value="${member.zipcode}" readonly>
      <button type="button" class="btn-sub" onclick="execDaumPostcode()">검색</button>
    </div>

    <div class="form-row">
      <label></label>
      <input type="text" id="addrMain" name="addrMain" value="${member.addrMain}" readonly>
    </div>

    <div class="form-row">
      <label for="addrDetail">상세주소</label>
      <input type="text" id="addrDetail" name="addrDetail" value="${member.addrDetail}">
    </div>

    <div class="form-actions">
      <button type="submit" class="btnUpdate">수정완료</button>
    </div>

  </form>
</div>

