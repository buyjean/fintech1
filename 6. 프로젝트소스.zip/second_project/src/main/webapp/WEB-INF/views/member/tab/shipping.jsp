<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>

<style>
    
    .delivery-steps {
        padding: 0;
        margin: 20px 0;
        width: 100%;
    }
    
    .delivery-steps li {
        position: relative;
        padding: 0 5px; 
    }
    
    .step-img {
        width: 50px;      
        height: 50px;    
        object-fit: contain; 
        margin-bottom: 8px; 
        display: block;     
        margin-left: auto;
        margin-right: auto;
    }


    .delivery-steps span {
        font-size: 13px;       
        white-space: nowrap;   
        display: block;       
        color: #6c757d;        
    }
    
    .delivery-steps span.font-weight-bold {
        color: #28a745 !important; 
        font-weight: bold;
    }
</style>

<h3 class="mb-3">배송 정보</h3>

<ul class="delivery-steps d-flex justify-content-between align-items-center list-unstyled">

  <li class="text-center flex-fill">
    <img src="${pageContext.request.contextPath}/resources/img/PAYMENT_DONE_on.png"
         class="step-img">
    <span>주문완료</span>
  </li>

  <li class="text-center flex-fill">
    <img src="${pageContext.request.contextPath}/resources/img/PREPARING_off.png"
         class="step-img">
    <span>상품준비중</span>
  </li>

  <li class="text-center flex-fill">
    <img src="${pageContext.request.contextPath}/resources/img/DELIVERY_READY_off.png"
         class="step-img">
    <span>배송시작</span>
  </li>

  <li class="text-center flex-fill">
    <img src="${pageContext.request.contextPath}/resources/img/SHIPPING_off.png"
         class="step-img">
    <span>배송중</span>
  </li>

  <li class="text-center flex-fill">
    <img src="${pageContext.request.contextPath}/resources/img/DELIVERY_off.png"
         class="step-img">
    <span>배송완료</span>
  </li>

</ul>
