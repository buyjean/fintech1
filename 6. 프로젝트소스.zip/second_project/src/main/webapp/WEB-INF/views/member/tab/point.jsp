<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>

<div class="mypage-point">
  <div class="row">
    <div class="col-md-4">
      <h2>${member.userId}님은</h2>
      <h3>${memberRank.rankName} 입니다</h3>
      <div class="pclass">
      <p>한끼Java.com에서</p>
      <p>즐거운 쇼핑을 경험하세요</p>
      </div>
    </div>
  </div>

  <div class="row">
    <div class="col-md-4">
      <h2>한끼 Point :
  		<fmt:formatNumber value="${member.point}" pattern="#,###" />P
	  </h2>
      <p>현금처럼 사용 가능</p>
    </div>
  </div>

  <div class="row">
    <div class="col-md-4">
      <h2>환경보호 기여도</h2>
      <h3>총 ${member.totalPurchase + member.savedWeight}</h3>
      <p>회원등급에 따라 최대 10% 적립</p>
    </div>
  </div>
</div>
