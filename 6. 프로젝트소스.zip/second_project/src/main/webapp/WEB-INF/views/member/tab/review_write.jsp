<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>

<%@ include file="../../includes/header.jsp"%>

<link rel="stylesheet"
	href="${pageContext.request.contextPath}/resources/css/review.css">

<div class="container my-5" style="max-width: 900px;">

	<h4 class="review-page-title">상품 리뷰 작성</h4>
	
	<div class="review-page-divider"></div>

	<form action="${pageContext.request.contextPath}/member/review_register"
		method="post" enctype="multipart/form-data">
		
		<input type="hidden" name="prodId" value="${product.prodId}">
    	<input type="hidden" name="orderId" value="${orderId}">
		<!-- ================= Sticky 리뷰 진행 상태 ================= -->
	<div id="reviewProgressWrapper"
	     class="position-sticky bg-white border-bottom"
	     style="top: 70px; z-index: 1020;">
	
	  <div class="container py-2" style="max-width: 900px;">
	    <div class="d-flex justify-content-between align-items-center mb-1">
	      <small class="font-weight-bold">리뷰 작성 진행도</small>
	      <small id="progressText">0%</small>
	    </div>
	
	    <div class="progress" style="height: 10px;">
	      <div
	        id="reviewProgress"
	        class="progress-bar bg-danger"
	        role="progressbar"
	        style="width: 0%">
	      </div>
	    </div>
	  </div>
	</div>
		


		
		<!-- ================= 상품 정보 ================= -->
		<div class="review-section">
			<div class="card">
			    <div class="card-body d-flex align-items-center">
			
			      <img src="https://dummyimage.com/80x80/ced4da/495057&text=PRODUCT"
			           class="rounded mr-3"
			           style="width:80px;height:80px;object-fit:cover;">
			
			      <div>
			        <div class="font-weight-bold">${product.name }</div>
			        <div class="text-muted small">구매 옵션 정보</div>
			      </div>
			
			    </div>
			  </div>
		</div>

		<!-- ================= 별점 ================= -->
		<div class="review-section">
			  <div class="review-section-title">
			    상품은 만족하셨나요?
			  </div>
			
			  <div class="rating-stars mb-2" id="ratingStars">
				  <label>
				    <input type="radio" name="rating" value="1">
				    <span>★</span>
				  </label>
				  <label>
				    <input type="radio" name="rating" value="2">
				    <span>★</span>
				  </label>
				  <label>
				    <input type="radio" name="rating" value="3">
				    <span>★</span>
				  </label>
				  <label>
				    <input type="radio" name="rating" value="4">
				    <span>★</span>
				  </label>
				  <label>
				    <input type="radio" name="rating" value="5">
				    <span>★</span>
				  </label>
				</div>

			
			  <small id="ratingText" class="text-muted">
			    별점을 선택해주세요
			  </small>
		</div>


		<!-- ================= 리뷰 내용 ================= -->
		<div class="review-section">
			  <div class="review-section-title">
			    리뷰 내용
			  </div>
			
			  <textarea
			    name="content"
			    id="reviewContent"
			    class="form-control"
			    rows="6"
			    placeholder="상품의 품질, 배송, 사용 후기를 자유롭게 작성해주세요"
			    maxlength="1000"></textarea>
			
			  <small id="contentCounter" class="text-muted d-block mt-1">
			    0 / 1000자
			  </small>
			  <small id="reviewHint" class="review-hint d-block mt-1"></small>
			  
		</div>


		<!-- ================= 이미지 업로드 ================= -->
		<div class="review-section">
			  <div class="review-section-title">
			    사진 첨부 (선택)
			  </div>
			
			  <input type="file"
			         id="reviewImage"
			         name="uploadFile"
			         class="form-control-file mb-2"
			         accept="image/*"
			         multiple>
			
			  <div id="imagePreview" class="d-flex flex-wrap mt-2"></div>
			
			  <small class="text-muted">
			    최대 1장까지 업로드 가능합니다.
			  </small>
		</div>


		<!-- ================= 안내 문구 ================= -->
		<div class="bg-light p-3 mb-4 small text-muted">
			· 상품과 무관한 내용, 욕설, 개인정보 포함 시 삭제될 수 있습니다.<br> · 작성된 리뷰는 수정이 제한될 수
			있습니다.
		</div>




		<!-- ================= 버튼 ================= -->
		<div class="text-right">
			<a href="javascript:history.back()" class="btn btn-outline-secondary">
				취소 </a>
			<!-- <button type="button" id="previewBtn" class="btn btn-outline-dark ml-2">
				미리보기</button> -->
			<button type="submit" class="btn btn-danger ml-2">리뷰 등록</button>


		</div>

	</form>

<div id="reviewPreview" class="card mt-5">
  <div class="card-body">

    <div class="d-flex align-items-center mb-3">
      <div class="rating-preview text-warning mr-2"></div>
      <small class="text-muted">미리보기</small>
    </div>

    <div class="preview-content mb-3"></div>

    <div class="preview-image d-flex flex-wrap"></div>

  </div>
</div>


	<script>
document.addEventListener("DOMContentLoaded", function () {
	console.log("review js loaded");
	/* ================= 별점 ================= */
	  const ratingTexts = {
	    1: "별로였어요 😡",
	    2: "아쉬워요 😕",
	    3: "보통이에요 😐",
	    4: "만족했어요 🙂",
	    5: "매우 만족했어요 😍"
	  };
	
	  const reviewHints = {
			  1: "어떤 점이 불만족스러웠는지 구체적으로 적어주세요.",
			  2: "아쉬웠던 부분이 무엇인지 알려주세요.",
			  3: "좋았던 점과 아쉬운 점을 함께 작성해 주세요.",
			  4: "만족스러웠던 이유를 자세히 적어주세요.",
			  5: "어떤 점이 특히 좋았는지 경험을 공유해 주세요!"
			};


	  const ratingTextEl = document.getElementById("ratingText");
	  const stars = document.querySelectorAll(".rating-stars input");	  
	  const starLabels = document.querySelectorAll(".rating-stars label");

	  /* ✅ 클릭 처리 */
	  starLabels.forEach((label, index) => {
	    const input = label.querySelector("input");
	    const span = label.querySelector("span");

	    label.addEventListener("click", () => {
	      // 모든 별 초기화
	      starLabels.forEach(l => {
	        l.querySelector("span").classList.remove("active");
	        l.classList.remove("shake");
	      });

	      // 선택한 별 + 왼쪽 별들 활성화
	      for (let i = 0; i <= index; i++) {
	        starLabels[i].querySelector("span").classList.add("active");
	      }

	      // shake 효과
	      label.classList.add("shake");
	      setTimeout(() => label.classList.remove("shake"), 300);
	      
	      textarea.scrollIntoView({
	          behavior: "smooth",
	          block: "center"
	        });

	        textarea.classList.add("focus-highlight");
	        setTimeout(() => {
	          textarea.classList.remove("focus-highlight");
	        }, 1000);
	     // ✅ 별점별 리뷰 힌트 표시
	        const ratingValue = input.value;
	        reviewHint.textContent = reviewHints[ratingValue];
	        reviewHint.classList.add("active");

	    });
	  });

	  /* ✅ 별점 hover 시 왼쪽 별까지 채우기 */
	  starLabels.forEach((label, index) => {

	    label.addEventListener("mouseenter", () => {
	      starLabels.forEach(l =>
	        l.querySelector("span").classList.remove("hover")
	      );

	      for (let i = 0; i <= index; i++) {
	        starLabels[i].querySelector("span").classList.add("hover");
	      }
	    });

	    label.addEventListener("mouseleave", () => {
	      starLabels.forEach(l =>
	        l.querySelector("span").classList.remove("hover")
	      );
	    });

	  });


	  stars.forEach(star => {
	    star.addEventListener("mouseenter", () => {
	      ratingTextEl.textContent = ratingTexts[star.value];
	    });

	    star.addEventListener("change", () => {
	      ratingTextEl.textContent = ratingTexts[star.value];
	      ratingTextEl.classList.remove("text-muted");
	      ratingTextEl.classList.add("font-weight-bold", "text-danger");
	    });
	  });

	  document.getElementById("ratingStars").addEventListener("mouseleave", () => {
	    const checked = document.querySelector(".rating-stars input:checked");
	    ratingTextEl.textContent = checked
	      ? ratingTexts[checked.value]
	      : "별점을 선택해주세요";
	  });	
	/* ================= 이미지 업로드 ================= */
  const input = document.getElementById("reviewImage");
  const preview = document.getElementById("imagePreview");

  let selectedFiles = [];

  const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB
  const MAX_WIDTH = 1200;
  const MAX_HEIGHT = 1200;

  input.addEventListener("change", async function () {
    const files = Array.from(this.files);

    if (selectedFiles.length + files.length > 1) {
      alert("이미지는 최대 1장까지 업로드할 수 있습니다.");
      input.value = "";
      return;
    }

    for (const file of files) {

      if (!file.type.startsWith("image/")) continue;

      if (file.size > MAX_FILE_SIZE) {
        alert(`"${file.name}" 파일은 5MB를 초과했습니다.`);
        continue;
      }

      const resizedFile = await resizeImage(file);

      selectedFiles.push(resizedFile);
      createPreview(resizedFile);
      syncInputFiles();
      updateProgress();
      renderPreview();
    }

    
  });

  /* ================= 이미지 리사이즈 ================= */
  function resizeImage(file) {
    return new Promise(resolve => {

      const reader = new FileReader();
      reader.onload = function (e) {

        const img = new Image();
        img.onload = function () {

          let { width, height } = img;

          if (width > MAX_WIDTH || height > MAX_HEIGHT) {
            const ratio = Math.min(
              MAX_WIDTH / width,
              MAX_HEIGHT / height
            );
            width *= ratio;
            height *= ratio;
          }

          const canvas = document.createElement("canvas");
          canvas.width = width;
          canvas.height = height;

          const ctx = canvas.getContext("2d");
          ctx.drawImage(img, 0, 0, width, height);

          canvas.toBlob(blob => {
            const resizedFile = new File([blob], file.name, {
              type: file.type,
              lastModified: Date.now()
            });
            resolve(resizedFile);
          }, file.type, 0.9);
        };

        img.src = e.target.result;
      };

      reader.readAsDataURL(file);
    });
  }

  /* ================= 미리보기 ================= */
  function createPreview(file) {

    const reader = new FileReader();
    reader.onload = function (e) {

      const div = document.createElement("div");
      div.className = "preview-box";

      const img = document.createElement("img");
      img.src = e.target.result;

      const btn = document.createElement("button");
      btn.type = "button";
      btn.innerHTML = "&times;";

      btn.onclick = () => {
        const idx = [...preview.children].indexOf(div);
        selectedFiles.splice(idx, 1);
        div.remove();
        syncInputFiles();
        updateProgress();
        renderPreview();
      };

      div.appendChild(img);
      div.appendChild(btn);
      preview.appendChild(div);
    };

    reader.readAsDataURL(file);
  }

  /* ================= input 동기화 ================= */
  function syncInputFiles() {
    const dt = new DataTransfer();
    selectedFiles.forEach(f => dt.items.add(f));
    input.files = dt.files;
  }
  
  /* ================= 리뷰 글자수 카운트 ================= */
  const textarea = document.getElementById("reviewContent");
  const counter = document.getElementById("contentCounter");
  const MAX_LENGTH = 1000;
  const MIN_LENGTH = 20;

  textarea.addEventListener("input", () => {
	  updateProgress();
	  renderPreview();
    const length = textarea.value.length;

    counter.textContent = length + " / " + MAX_LENGTH + "자";

    if (length < MIN_LENGTH) {
      counter.classList.remove("text-success");
      counter.classList.add("text-danger");
    } else {
      counter.classList.remove("text-danger");
      counter.classList.add("text-success");
    }

    // 최소 글자 수 안내
    if (length < MIN_LENGTH) {
      counter.classList.remove("text-success");
      counter.classList.add("text-danger");
    } else {
      counter.classList.remove("text-danger");
      counter.classList.add("text-success");
    }
  });
  
  /* ================= submit 시 리뷰 최소 글자수 체크 ================= */
  const form = textarea.closest("form");

  form.addEventListener("submit", function (e) {
	 
	  /* ================= 별점 필수 체크 ================= */
	  const checkedRating = document.querySelector("input[name=rating]:checked");

	  if (!checkedRating) {
	    alert("별점을 선택해주세요.");
	    document.getElementById("ratingStars").scrollIntoView({ behavior: "smooth" });
	    e.preventDefault();
	    return;
	  }  
	  
    const length = textarea.value.trim().length;

    if (length < MIN_LENGTH) {
      alert("리뷰는 최소 " + MIN_LENGTH + "자 이상 작성해주세요.");
      textarea.focus();
      e.preventDefault();
      return;
    }
  });
  
  /* ================= 리뷰 미리보기 ================= */
  const previewBox = document.getElementById("reviewPreview");
  const previewContent = document.querySelector(".preview-content");
  const previewImage = document.querySelector(".preview-image");
  const ratingPreview = document.querySelector(".rating-preview");

  
  
  /* ================= 이미지 클릭 확대 (라이트박스) ================= */
  const lightbox = document.getElementById("imageLightbox");
  const lightboxImg = document.getElementById("lightboxImg");
  const lightboxClose = document.querySelector(".lightbox-close");

  // 이미지 클릭 (업로드 미리보기 + 리뷰 미리보기 공통)
  document.addEventListener("click", function (e) {

    if (e.target.tagName === "IMG" &&
        (e.target.closest("#imagePreview") || e.target.closest(".preview-image"))) {

      lightboxImg.src = e.target.src;
      lightbox.classList.remove("d-none");
    }
  });

  // 닫기 버튼
  lightboxClose.addEventListener("click", closeLightbox);

  // 배경 클릭 닫기
  lightbox.addEventListener("click", function (e) {
    if (e.target === lightbox) {
      closeLightbox();
    }
  });

  // ESC 키 닫기
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") {
      closeLightbox();
    }
  });

  function closeLightbox() {
    lightbox.classList.add("d-none");
    lightboxImg.src = "";
  }

  
  /* ================= 리뷰 진행 상태 ================= */
  const progressBar = document.getElementById("reviewProgress");
  const progressText = document.getElementById("progressText");

  function updateProgress() {
    let progress = 0;

    // 1. 별점 선택 (40%)
    if (document.querySelector(".rating-stars input:checked")) {
      progress += 40;
    }

    // 2. 리뷰 내용 20자 이상 (40%)
    if (textarea.value.trim().length >= MIN_LENGTH) {
      progress += 40;
    }

    // 3. 이미지 1장 이상 (20%) - 선택 요소
    if (selectedFiles.length > 0) {
      progress += 20;
    }

    progressBar.style.width = progress + "%";
    progressText.textContent = progress + "%";

    // 색상 변화
    progressBar.classList.remove("bg-danger", "bg-warning", "bg-success");

    if (progress < 40) {
      progressBar.classList.add("bg-danger");
    } else if (progress < 80) {
      progressBar.classList.add("bg-warning");
    } else {
      progressBar.classList.add("bg-success");
    }
  }
  stars.forEach(star => {
	  star.addEventListener("change", () => {
	    updateProgress();
	    renderPreview();
	  });
	});

  

  function renderPreview() {
	  /* 1️⃣ 리뷰 내용 */
	  const content = textarea.value.trim();
	  previewContent.textContent = content || "리뷰 내용이 없습니다.";

	  /* 2️⃣ 별점 */
	  const checked = document.querySelector("input[name=rating]:checked");
	  const rating = checked ? parseInt(checked.value) : 0;
	  ratingPreview.innerHTML =
	    "★".repeat(rating) + "☆".repeat(5 - rating);

	  /* 3️⃣ 이미지 */
	  previewImage.innerHTML = "";

	  selectedFiles.forEach(file => {
	    const reader = new FileReader();
	    reader.onload = e => {
	      const img = document.createElement("img");
	      img.src = e.target.result;
	      previewImage.appendChild(img);
	    };
	    reader.readAsDataURL(file);
	  });
	}
	
  updateProgress();
  renderPreview();

  
});
</script>


<!-- 이미지 라이트박스 -->
<div id="imageLightbox" class="lightbox d-none">
  <span class="lightbox-close">&times;</span>
  <img id="lightboxImg" src="">
</div>



</div>


