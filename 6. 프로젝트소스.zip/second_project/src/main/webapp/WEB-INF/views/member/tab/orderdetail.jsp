<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>



<div class="detail-container">
    
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="font-weight-bold m-0">주문 상세 내역</h4>
        <span class="badge badge-success px-3 py-2" style="font-size:0.9rem;">
            ${order.orderStatus}
        </span>
    </div>

    <div class="row">
        <div class="col-md-7">
            <div class="info-card h-100">
                <div class="info-title"><i class="far fa-file-alt mr-2"></i>주문 정보</div>
                <div class="summary-row">
                    <span class="summary-label">주문번호</span>
                    <span class="summary-value">${order.orderId}</span>
                </div>
                <div class="summary-row">
                    <span class="summary-label">주문일자</span>
                    <span class="summary-value">
                        <fmt:formatDate value="${order.orderDate}" pattern="yyyy-MM-dd HH:mm:ss"/>
                    </span>
                </div>
                <hr>
                <div class="info-title"><i class="fas fa-truck mr-2"></i>배송지 정보</div>
                 <div class="summary-row">
                    <span class="summary-label">받는 분</span>
                    <span class="summary-value">${order.addrName} (${order.tel})</span>
                </div>
                <div class="mt-2">
                    <span class="badge badge-light border mr-1">${order.zipcode}</span>
                    <span class="text-dark">${order.addrMain} ${order.addrDetail}</span>
                </div>
            </div>
        </div>

        <div class="col-md-5">
            <div class="info-card h-100" style="background-color: #fcfcfc;">
                <div class="info-title"><i class="fas fa-receipt mr-2"></i>결제 금액</div>
                
                <div class="summary-row">
                    <span class="summary-label">총 상품금액</span>
                    <span class="summary-value">
                        <fmt:formatNumber value="${order.totalAmount - 3000 + order.usedPoint}" pattern="#,###"/>원
                    </span>
                </div>
                <div class="summary-row">
                    <span class="summary-label">배송비</span>
                    <span class="summary-value">
                         <c:choose>
                            <c:when test="${order.totalAmount >= 50000}">0원</c:when>
                            <c:otherwise>3,000원</c:otherwise>
                        </c:choose>
                    </span>
                </div>
                <div class="summary-row text-danger">
                    <span class="summary-label">포인트 사용</span>
                    <span class="summary-value">
                        - <fmt:formatNumber value="${order.usedPoint}" pattern="#,###"/> P
                    </span>
                </div>
                <div class="summary-row text-primary">
                    <span class="summary-label">적립 예정</span>
                    <span class="summary-value">
                        + <fmt:formatNumber value="${order.earnedPoint}" pattern="#,###"/> P
                    </span>
                </div>
                
                <div class="summary-row total-price">
                    <span>최종 결제금액</span>
                    <span><fmt:formatNumber value="${order.totalAmount}" pattern="#,###"/>원</span>
                </div>
            </div>
        </div>
    </div>

    <div class="mt-4">
        <h5 class="font-weight-bold mb-3">주문 상품 (${detailList.size()}건)</h5>
        
        <table class="prod-table">
            <colgroup>
                <col width="10%"> <col width="45%"> <col width="15%"> <col width="15%"> <col width="15%"> </colgroup>
            <thead>
                <tr>
                    <th colspan="2">상품정보</th>
                    <th>판매가</th>
                    <th>수량</th>
                    <th>리뷰 작성</th>
                </tr>
            </thead>
            <tbody>
                <c:forEach var="detail" items="${detailList}">
                    <tr>
                        <td>
                            <div class="detail-img-box">
                                <img src="<c:url value='/resources/img/${detail.prodImage}'/>" 
                                     class="detail-img" 
                                     alt="상품"
                                     onerror="this.onerror=null; this.src='<c:url value='/resources/images/no_image.png'/>'">
                            </div>
                        </td>
                        
                        <td>
                            <div class="font-weight-bold text-dark mb-1" style="font-size: 1.05rem;">
                                ${detail.prodName}
                            </div>
                            <div class="text-muted small">
                                상품ID : ${detail.prodId}
                            </div>
                        </td>

                        <td class="text-center font-weight-bold">
                            <fmt:formatNumber value="${detail.price}" pattern="#,###"/>원
                        </td>

                        <td class="text-center">
                            ${detail.quantity}개
                        </td>

                        <td class="text-center">
                            <a href="<c:url value='/member/review_write?orderId=${order.orderId}&prodId=${detail.prodId}'/>" 
                               class="btn btn-outline-success btn-review">
                               <i class="fas fa-pen"></i> 리뷰 쓰기
                            </a>
                        </td>
                    </tr>
                </c:forEach>
            </tbody>
        </table>
    </div>

    <div class="text-center mt-5 mb-3">
        <button type="button" class="btn btn-secondary px-5 py-2" id="btnBackToHistory">
            <i class="fas fa-list mr-2"></i> 목록으로 돌아가기
        </button>
    </div>

</div>

<script>
    $("#btnBackToHistory").on("click", function(){
        
        $(".mypage-sidebar a[data-url*='orders']").trigger("click");
    });
</script>