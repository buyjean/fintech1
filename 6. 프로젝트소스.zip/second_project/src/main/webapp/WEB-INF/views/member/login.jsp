<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ include file="../includes/header.jsp" %>

<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>    
<link rel="stylesheet" href="${pageContext.request.contextPath}/resources/css/login.css">


<div class="login-container">
  <h2>로그인</h2>

  <!--  실패 메시지 출력 -->
  <c:if test="${not empty msg}">
    <div class="login-msg">${msg}</div>
  </c:if>

  <form action="${pageContext.request.contextPath}/member/login" method="post">

    <div class="form-row">
      <label for="userId">아이디</label>
      <input class="id1" type="text" id="userId" name="userId"
             required placeholder="아이디를 입력해주세요" autocomplete="username">
    </div>
	
    <div class="form-row">
      <label for="userPw">비밀번호</label>
    
      <input class="pw1" type="password" id="password" name="password"
             required placeholder="비밀번호를 입력해주세요" autocomplete="current-password">
    </div>	



    <div class="form-actions">
      <button type="button" class="btn-edit"
              onclick="location.href='${pageContext.request.contextPath}/member/register'">
              회원가입
      </button>

      <button type="submit" class="btn btn-primary">
        	  로그인
      </button>
    </div>

  </form>
</div>

</body>
</html>
