<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<div class="receipt-wrap">
  <!-- 영수증 제목/주문 기본정보 -->
  <div class="receipt-box">
    <h2>영수증</h2>

    <h4>주문자 정보</h4>
    <p>주문번호 : <c:out value="${order.orderId}"/></p>
    <p>주문자 : <c:out value="${member.name}"/></p>

    <p>
      주문일시 :
      <c:choose>
        <c:when test="${not empty order.orderDate}">
          <fmt:formatDate value="${order.orderDate}" pattern="yyyy-MM-dd HH:mm"/>
        </c:when>
        <c:otherwise>-</c:otherwise>
      </c:choose>
    </p>
  </div>

  <!-- 결제 상세 -->
  <div class="receipt-box">
    <h4>결제 상세 내역</h4>

    <table>
      <thead>
        <tr>
          <th>상품명</th>
          <th>상품가격</th>
          <th>수량</th>
          <th>금액</th>
        </tr>
      </thead>

      <tbody>
    <c:choose>
      <c:when test="${empty detailList}">
        <tr>
          <td colspan="3" style="text-align:center;">영수증 내역이 없습니다.</td>
        </tr>
      </c:when>

      <c:otherwise>
        <c:forEach var="d" items="${detailList}">
          <tr>
            <td><c:out value="${d.prodName}"/></td>
            <td><c:out value="${d.price}"/></td>
            <td><c:out value="${d.quantity}"/></td>
            <td>
              <fmt:formatNumber value="${d.price * d.quantity}" pattern="#,###"/>원
            </td>
          </tr>
        </c:forEach>
      </c:otherwise>
    </c:choose>
  </tbody>
    </table>
    <c:if test="${not empty order.usedPoint || not empty order.earnedPoint}">
      <p>사용 포인트 : <fmt:formatNumber value="${order.usedPoint}" pattern="#,###"/>P</p>
      <p>적립 포인트 : <fmt:formatNumber value="${order.earnedPoint}" pattern="#,###"/>P</p>
    </c:if>

    <!-- ✅ 총액은 회원 누적(totalPurchase) 말고 주문 1건(order.totalAmount) -->
    <h4>
      총 상품금액 :
      <fmt:formatNumber value="${order.totalAmount}" pattern="#,###"/>원
    </h4>

    <!-- (선택) 포인트 정보도 같이 보여주고 싶으면 -->
    
  </div>

  <!-- 사업자 정보 -->
  <div class="receipt-box">
    <h4>사업자 정보</h4>
    <p>(주)최고1까 컴퍼니</p>
    <p>대표이사 : 홍길동</p>
    <p>Tel : 070-459-8888</p>
    <p>사업자주소지 : 서울특별시 종로3가</p>
  </div>
</div>
