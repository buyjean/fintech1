<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ include file="../includes/header.jsp"%>

<style>
/* 数量調整ボタン等のスタイル */
.qty-input { width: 40px; text-align: center; border: 1px solid #dee2e6; height: 31px; }
.qty-btn { height: 31px; padding: 0 10px; border: 1px solid #dee2e6; background: #fff; cursor: pointer; }
.btn-delete-corner {
    position: absolute; top: 15px; right: 15px;
    color: #adb5bd; font-size: 1.2rem; cursor: pointer; z-index: 10;
}
.btn-delete-corner:hover { color: #dc3545; }
.sticky-sidebar { position: sticky !important; top: 100px !important; z-index: 90; }
#Point { width: 85%; }
#flatpickr, #deliveryDate, #deliveryTime { text-align: right; }
</style>

<div class="container-fluid mt-5 mb-5 px-5">
    
    <div class="d-flex justify-content-between align-items-end mb-2" style="margin-left: 20px;">
        <h1 class="font-weight-bold m-0">
            주문결제 <i class="fa-solid fa-money-bill" style="color: #28a745;"></i>
        </h1>
        <div class="pb-2">
            <span class="text-muted mx-2">장바구니</span> <span class="text-muted mx-2">&gt;</span> 
            <span class="font-weight-bold text-dark">주문결제</span> <span class="text-muted mx-2">&gt;</span> 
            <span class="text-muted">주문완료</span>
        </div>
    </div>
    <hr class="mt-3 border-dark" style="margin-left: 15px;">

    <div class="row">
        
        <div class="col-lg-9">
            
            <div class="card shadow-sm border-0 mt-3">
                <div class="card-body p-5">
                    <h3 class="mt-3">주문 상품</h3>
                    <hr>
                    <div class="card mb-2 border bg-light">
                        <c:forEach items="${cartList}" var="item" varStatus="status">
                            <div class="card mb-3 border position-relative">
                                <div class="card-body" style="height: 110px;">
                                    
                                    <i class="fa-solid fa-xmark btn-delete-corner"
                                       data-cart-id="${item.cartId}" title="삭제"></i>

                                    <div class="row align-items-center h-100">
                                        
                                        <div class="col-2">
                                            <img src="<c:url value='/resources/images/${item.prodImage}' />"
                                                 class="img-fluid rounded border"
                                                 style="height: 80px; width: 100%; object-fit: contain;">
                                        </div>

                                        <div class="col-5">
                                            <h6 class="font-weight-bold mb-1">
                                                <c:if test="${item.discountRate > 0}">
                                                    <span class="badge badge-danger mr-1">
                                                        <i class="fas fa-tag"></i>${item.discountRate}%
                                                    </span>
                                                </c:if>
                                                ${item.prodName}
                                            </h6>
                                            
                                        </div>
                                        
                                        <div class="col-3 text-center">
                                            <button type="button" class="qty-btn btn-minus" data-cart-id="${item.cartId}">-</button>
                                            <input type="text" class="qty-input bg-white" id="qty_${item.cartId}"
                                                   value="${item.quantity}" readonly>
                                            <button type="button" class="qty-btn btn-plus" data-cart-id="${item.cartId}">+</button>
                                        </div>
                                        
                                        <div class="col-2 text-right">
                                            <h6 class="font-weight-bold mb-0" id="total_price_${item.cartId}">
                                                <c:choose>
                                                    <c:when test="${item.discountRate > 0}">
                                                        <small class="text-muted" style="text-decoration: line-through; font-size: 0.8rem;">
                                                            <fmt:formatNumber value="${item.prodPrice * item.quantity}" />
                                                        </small><br>
                                                        <span class="text-danger">
                                                            <fmt:formatNumber value="${item.salePrice * item.quantity}" />원
                                                        </span>
                                                    </c:when>
                                                    <c:otherwise>
                                                        <fmt:formatNumber value="${item.prodPrice * item.quantity}" />원
                                                    </c:otherwise>
                                                </c:choose>
                                            </h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </c:forEach>
                    </div>
                </div>
            </div>

            <div class="card shadow-sm border-0 mt-4">
                <div class="card-body p-5">
                    <h3 class="mt-3">배송</h3>
                    <hr class="mb-0">
                    <div class="d-flex justify-content-between align-items-center mt-4">
                        <div class="d-flex">
                            <i class="fa-solid fa-location-dot fa-2xl mt-3 text-success ml-3"></i>
                            <div class="ml-4">
                                <h5 class="font-weight-bold text-success">배송지 정보</h5>
                                <div class="mt-2 font-weight-bold">
                                    <span id="displayReceiverName">${memberInfo.name}</span> / 
                                    <span id="displayReceiverPhone">${memberInfo.phone}</span>
                                </div>
                                <div>
                                    <small id="displayAddr">
                                        [${memberInfo.zipcode}] ${memberInfo.addrMain} ${memberInfo.addrDetail} 
                                    </small>
                                </div>
                            </div>
                        </div>
                        <button type="button" class="btn btn-sm btn-outline-secondary bg-info text-white"
                                data-toggle="modal" data-target="#addressModal">변경</button>
                    </div>
                </div>
            </div>

            <div class="row mt-4">
                <div class="col-6">
                    <div class="card shadow-sm border-0 h-100 p-4">
                        <h3>배송희망일</h3>
                        <hr class="m-0">
                        <div class="mt-4 mb-3" id="flatpickr">
                            <label class="small font-weight-bold mb-1 mr-2">배송 희망일</label>
                            <div class="input-group input-group-sm">
                                <input type="text" id="deliveryDate" class="form-control bg-white" placeholder="날짜 선택" readonly>
                                <div class="input-group-append">
                                    <button class="btn btn-outline-success" type="button" id="calendar-picker-btn">
                                        <i class="fa-regular fa-calendar-days"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-6">
                    <div class="card shadow-sm border-0 h-100 p-4">
                        <h3>배송 시간 지정</h3>
                        <hr class="m-0">
                        <div class="mt-4 mb-3">
                            <label class="small font-weight-bold mb-1 mr-2">배송 희망 시간</label>
                            <div class="input-group input-group-sm">
                                <input type="text" id="deliveryTime" class="form-control bg-white" placeholder="시간 선택" readonly>
                                <div class="input-group-append">
                                    <button class="btn btn-outline-success" type="button" id="watch-picker-btn">
                                        <i class="fa-regular fa-clock"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card shadow-sm border-0 mt-4">
                <div class="card-body p-5">
                    <h3>결제 수단</h3>
                    <hr>
                    <div class="custom-control custom-radio mb-2">
                        <input type="radio" id="pay_method_card" name="pg_mode" class="custom-control-input" value="card" checked> 
                        <label class="custom-control-label" for="pay_method_card">신용카드 <i class="fa-solid fa-credit-card text-success"></i></label>
                    </div>
                    <div class="custom-control custom-radio mb-2">
                        <input type="radio" id="pay_method_trans" name="pg_mode" class="custom-control-input" value="trans"> 
                        <label class="custom-control-label" for="pay_method_trans">실시간 계좌이체 <i class="fa-solid fa-hand-holding-dollar text-success"></i></label>
                    </div>
                </div>
            </div>

            <div class="card shadow-sm border-0 mt-4 mb-5">
                <div class="card-body p-5">
                    <h3>포인트</h3>
                    <hr>
                    <div class="font-weight-bold text-right mr-5 mb-3">
                        현재 포인트 <fmt:formatNumber value="${memberInfo.point}" pattern="#,###" /> P
                    </div>
                    <div class="d-flex justify-content-center align-items-center position-relative" style="height: 50px;">
                        <input type="number" class="form-control" id="Point" placeholder="사용할 포인트 입력" data-max="${memberInfo.point}">
                        <button type="button" id="btn-point" class="btn btn-dark btn-sm position-absolute" style="width: 60px; right: 0;">사용</button>
                    </div>
                </div>
            </div>
            
        </div> <div class="col-lg-3">
            
            <c:set var="totalRealPrice" value="0" />      
            <c:set var="totalOriginalPrice" value="0" />  
            <c:forEach items="${cartList}" var="item">
                <c:set var="totalRealPrice" value="${totalRealPrice + (item.salePrice * item.quantity)}" />
                <c:set var="totalOriginalPrice" value="${totalOriginalPrice + (item.prodPrice * item.quantity)}" />
            </c:forEach>

            <c:set var="eventDiscount" value="${totalOriginalPrice - totalRealPrice}" />
            <c:set var="shippingFee" value="${totalRealPrice >= 50000 ? 0 : 3000}" />
            <c:set var="finalTotalPrice" value="${totalRealPrice + shippingFee}" />
            <c:set var="totalPoint" value="${totalRealPrice * (memberRank.pointRate/100)}" />
            
            <div class="card shadow-sm border-0 sticky-sidebar mt-3">
                <div class="card-header bg-white font-weight-bold py-4">
                    <i class="fa-solid fa-receipt mr-2"></i>결제 금액
                </div>
                <div class="card-body">
                    
                    <div class="d-flex justify-content-between mb-2 text-muted">
                        <span>상품 금액</span> 
                        <span><fmt:formatNumber value="${totalOriginalPrice}" />원</span>
                    </div>

                    <c:if test="${eventDiscount > 0}">
                        <div class="d-flex justify-content-between mb-2 text-danger font-weight-bold">
                            <span>이벤트 할인</span> 
                            <span>- <fmt:formatNumber value="${eventDiscount}" />원</span>
                        </div>
                    </c:if>
                    
                    <div class="d-flex justify-content-between mb-2 text-success font-weight-bold">
                        <span>포인트 할인</span> <span id="pointDiscountArea">- 0원</span>
                    </div>
                    
                    <div class="d-flex justify-content-between mb-2 text-muted">
                        <span>배송비</span> 
                        <span id="shippingFeeArea"> 
                            <c:choose>
                                <c:when test="${shippingFee == 0}">무료</c:when>
                                <c:otherwise>+ <fmt:formatNumber value="${shippingFee}" />원</c:otherwise>
                            </c:choose>
                        </span>
                    </div>
                    
                    <hr>
                    
                    <div class="text-right mr-3 mb-2 small">
                        배송 예정일: <span id="sideDeliveryDate" class="text-success font-weight-bold">선택해주세요</span>
                    </div>
                    <div class="text-right mr-3 mb-2 small">
                        배송 예정시간: <span id="sideDeliveryTime" class="text-success font-weight-bold">선택해주세요</span>
                    </div>
                    
                    <hr>
                    
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <span class="font-weight-bold h5 mb-0">총 결제금액:</span> 
                        <span class="font-weight-bold h4 text-danger mb-0" id="finalTotalPrice"> 
                            <fmt:formatNumber value="${finalTotalPrice}" />원
                        </span>
                    </div>

                    <div class="bg-light p-2 rounded mb-3 text-center small text-secondary">
                        <span class="badge badge-warning text-white mr-1">G.Point</span> 구매 시 
                        <span id="expectedPoint"><fmt:formatNumber value="${totalPoint}" pattern="#,###" /></span>P 적립
                    </div>
                    
                    <button type="button" id="pay-button" class="btn btn-success btn-block btn-lg font-weight-bold py-3">
                        주문하기
                    </button>
                </div>
            </div>
        </div>

    </div> </div> <input type="hidden" id="usedPointHidden" value="0">
<input type="hidden" id="orderReceiverName" value="${memberInfo.name}">
<input type="hidden" id="orderReceiverPhone" value="${memberInfo.phone}">
<input type="hidden" id="orderZipcode" value="${memberInfo.zipcode}">
<input type="hidden" id="orderAddrMain" value="${memberInfo.addrMain}">
<input type="hidden" id="orderAddrDetail" value="${memberInfo.addrDetail}">

<input type="hidden" id="hiddenBuyerEmail" value="${memberInfo.email}">
<input type="hidden" id="hiddenBuyerName" value="${memberInfo.name}">
<input type="hidden" id="hiddenBuyerTel" value="${memberInfo.phone}">
<input type="hidden" id="hiddenBuyerZip" value="${memberInfo.zipcode}">
<input type="hidden" id="hiddenBuyerAddr" value="${memberInfo.addrMain} ${memberInfo.addrDetail}">
<c:set var="orderTitle" value="${cartList[0].prodName} 외 ${cartList.size() - 1}건" />
<input type="hidden" id="hiddenOrderTitle" value="${orderTitle}">

<div class="modal fade" id="addressModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title font-weight-bold">배송지 변경</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label class="small text-muted">받는 분</label> 
                    <input type="text" id="newReceiverName" class="form-control" value="${memberInfo.name}">
                </div>
                <div class="form-group">
                    <label class="small text-muted">연락처</label> 
                    <input type="text" id="newReceiverPhone" class="form-control" value="${memberInfo.phone}">
                </div>
                <div class="form-group">
                    <label class="small text-muted">주소</label>
                    <div class="input-group mb-2">
                        <input type="text" id="newZipcode" class="form-control" placeholder="우편번호" readonly>
                        <div class="input-group-append">
                            <button type="button" class="btn btn-success" onclick="execDaumPostcode()">검색</button>
                        </div>
                    </div>
                    <input type="text" id="newAddrMain" class="form-control mb-2" placeholder="기본 주소" readonly> 
                    <input type="text" id="newAddrDetail" class="form-control" placeholder="상세 주소를 입력하세요">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">취소</button>
                <button type="button" class="btn btn-primary" onclick="applyNewAddress()">적용하기</button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.iamport.kr/v1/iamport.js"></script>
<script src="${pageContext.request.contextPath}/resources/js/checkout.js"></script>