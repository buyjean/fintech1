<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<style>

    .center-wrapper {
        display: flex;
        flex-direction: column;  /* 위에서 아래로 쌓기 */
        justify-content: center; /* 세로 중앙 */
        align-items: center;     /* 가로 중앙 */
        height: 70vh;            /* 높이를 적당히 조절 */
        text-align: center;
    }

    /* 2. 제목 스타일 */
    .success-title {
        font-size: 70px;
        font-weight: bold;
        margin-bottom: 10px;
    }

    /* 3. 주문번호 스타일 */
    .order-number {
        color: #666;
        margin-top: 0;
        margin-bottom: 50px; /
    }

    
    .button-group {
        display: flex;
        justify-content: center;
        gap: 15px; /* 버튼 사이 간격 */
    }

    .btn-lg-custom {
        width: 180px; /* 버튼 너비를 조금 더 여유 있게 */
        height: 55px;
        font-weight: bold;
        display: flex;
        align-items: center;
        justify-content: center;
    }
</style>

<div class="container-fluid mt-5 mb-3 px-5">
    <div class="d-flex justify-content-between align-items-end mb-2" style="margin-left: 20px;">
        <h1 class="font-weight-bold m-0">
            주문완료 <i class="fa-solid fa-check" style="color: #28a745;"></i>
        </h1>
        <div class="pb-2"> 
            <span class="text-muted mx-2" style="font-size: 1rem;">장바구니</span>
            <span class="text-muted mx-2">&gt;</span>
            <span class="text-muted mx-2">주문결제</span>
            <span class="text-muted mx-2">&gt;</span>
            <span class="font-weight-bold text-dark">주문완료</span>
        </div>
    </div>
    <hr>
</div>


<!-- 화면에 결제확인 표시 -->
<div class="center-wrapper">
    <h1 class="success-title">결제가 완료되었습니다</h1>
    <h4 class="order-number">주문번호: ${orderId}<!--예시: QA12342342 --></h4>



	<!-- 마이페이지 이동 -->
    <div class="button-group">
        <button type="button" onclick="location.href='${pageContext.request.contextPath}/'" class="btn btn-success btn-lg-custom">홈으로</button>
    </div>
</div>