<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8" isErrorPage="true"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>500 Error</title>
</head>
<body>
    <h1>시스템 에러발생</h1>
    <hr>
    <h3>상세:</h3>
    <pre style="background-color: #f0f0f0; padding: 10px; color: red;">
        <% 
           if(exception != null) {
               exception.printStackTrace(new java.io.PrintWriter(out));
           } else {
               out.print("에러정보를 불러올 수 없었습니다");
           }
        %>
    </pre>
</body>
</html>