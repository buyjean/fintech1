<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions"%>

<c:set var="currentUrl" value="${pageContext.request.requestURI }" />

<nav
	class="navbar navbar-expand-lg navbar-dark bg-success sticky-top shadow-sm">
	<div class="container">
		<a class="navbar-brand" href="${pageContext.request.contextPath}/"><i
			class="fas fa-carrot"></i> 한끼를.Java</a>

		<button class="navbar-toggler" type="button" data-toggle="collapse"
			data-target="#navbarNav">
			<span class="navbar-toggler-icon"></span>
		</button>

		<div class="collapse navbar-collapse" id="navbarNav">
			<ul class="navbar-nav ml-auto">

				<form class="form-inline my-2 my-lg-0"
					action="${pageContext.request.contextPath }/product/search"
					method="get">
					<div class="input-group input-group-sm">
						<input style="width: 600px"
							class="form-control mx-2 mx-lg-1 px-2 px-lg-1" type="search"
							placeholder="상품을 검색" name="keyword">
						<div class="input-group-append">
							<button class="btn btn-light" type="submit">
								<i class="fas fa-search text-success"></i>
							</button>
						</div>
					</div>
				</form>

				<c:if test="${member == null}">
					<li class="nav-item"><a class="nav-link"
						href="${pageContext.request.contextPath}/member/login"><i
							class="fas fa-sign-in-alt"></i> 로그인</a></li>
					<li class="nav-item"><a class="nav-link"
						href="${pageContext.request.contextPath}/member/register"><i
							class="fas fa-user-plus"></i> 회원가입</a></li>
				</c:if>

				<c:if test="${member != null}">
					<li class="nav-item"><span
						class="nav-link text-white font-weight-bold"> <i
							class="fas fa-user"></i> ${member.name} 님
					</span></li>

					<c:choose>

						<c:when test="${member.role == 1 }">
							<li class="nav-item"><a
								class="nav-link text-warning font-weight-bold"
								href="${pageContext.request.contextPath }/admin/dashboard">
									<i class="fas fa-user-cog">관리 페이지</i>
							</a></li>
						</c:when>

						<c:otherwise>
							<li class="nav-item"><a class="nav-link"
								href="${pageContext.request.contextPath}/member/mypage"> <i
									class="fas fa-user-circle"></i> 마이페이지
							</a></li>
						</c:otherwise>
					</c:choose>
					<li class="nav-item"><a class="nav-link"
						href="${pageContext.request.contextPath}/member/logout"> <i
							class="fas fa-sign-out-alt"></i> 로그아웃
					</a></li>
				</c:if>

			</ul>
		</div>
	</div>
</nav>

<c:if test="${not fn:contains(currentUrl, '/order') }">
	<div class="bg-white border-bottom shadow-sm">
		<div class="container">
			<nav class="navbar navbar-expand-lg navbar-light bg-white p-0">
				<button class="navbar-toggler" type="button" data-toggle="collapse"
					data-target="#shopNav">
					<span class="navbar-toggler-icon"></span>
				</button>

				<div class="collapse navbar-collapse" id="shopNav">
					<ul class="navbar-nav mr-auto">

						<li class="nav-item dropdown mr-4"><a
							class="nav-link dropdown-toggle font-weight-bold text-dark"
							href="#" id="categoryDropdown" role="button"
							data-toggle="dropdown"> <i class="fas fa-bars mr-1"></i> 카테고리
						</a>
							<div class="dropdown-menu">
								<c:forEach items="${categoryList}" var="cat">
									<a class="dropdown-item"
										href="${pageContext.request.contextPath}/product/search?categoryId=${cat.categoryId}">
										${cat.categoryName} </a>
								</c:forEach>

								<c:if test="${empty categoryList}">
									<a class="dropdown-item"
										href="${pageContext.request.contextPath}/product/search?categoryId=20">🥩
										정육</a>
									<a class="dropdown-item"
										href="${pageContext.request.contextPath}/product/search?categoryId=10">🥦
										청과</a>
									<a class="dropdown-item"
										href="${pageContext.request.contextPath}/product/search?categoryId=30">🐟
										수산</a>
								</c:if>

								<div class="dropdown-divider"></div>
								<a class="dropdown-item font-weight-bold"
									href="${pageContext.request.contextPath}/product/search">모두보기</a>
							</div></li>

						<li class="nav-item mr-4"><a
							class="nav-link font-weight-bold text-secondary"
							href="${pageContext.request.contextPath}/product/search?sort=outlet">
								<i class="fas fa-fire-alt text-danger"></i> 임박/알뜰상품
						</a></li>
						<li class="nav-item mr-4"><a
							class="nav-link font-weight-bold text-secondary"
							href="${pageContext.request.contextPath}/product/search?sort=sale">
								<i class="fas fa-tag text-warning"></i> 할인상품
						</a></li>
						<li class="nav-item mr-4"><a
							class="nav-link font-weight-bold text-secondary"
							href="${pageContext.request.contextPath}/product/search?sort=new">
								<i class="fas fa-bullhorn text-success"></i> 신규상품
						</a></li>

					</ul>
				</div>
			</nav>
		</div>
	</div>
</c:if>