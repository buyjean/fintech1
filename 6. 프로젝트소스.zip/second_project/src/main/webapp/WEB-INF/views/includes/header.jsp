<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/functions" prefix="fn" %>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Grocery Store</title>

	<%@ include file="../includes/config.jsp" %>
	
	
	<script>
        window.CTX = '${pageContext.request.contextPath}';
        const ctx = '${pageContext.request.contextPath}';
    </script>

</head>
<body class="bg-light">
	
	<%@ include file="../includes/navbar.jsp" %>

