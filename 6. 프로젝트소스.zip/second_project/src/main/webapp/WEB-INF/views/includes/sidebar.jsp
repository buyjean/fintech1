<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/functions" prefix="fn" %>

<c:set var="cartTotal" value="0" />
<c:set var="reqUrl" value="${pageContext.request.requestURI }"/>

<div class="sticky-top mt-5" style="top: 100px; z-index: 10; max-height: calc(100vh - 120px); overflow-y: auto;">
    
    <c:if test="${fn:contains(reqUrl, '/product/detail')}">
    	<div class="card shadow-sm border-0 mb-4">
            <div class="card-body">

                <div class="d-flex justify-content-between align-items-center mb-2">

                    <c:choose>
                        <c:when test="${not empty relateRecipe}">
                            <a href="#" class="btn btn-lg recipe-btn" data-toggle="modal"
                               data-target="#recipeModal" data-recipe-id="${relateRecipe.recipeId}"> 
                               <i class="bi bi-book"></i> 추천 레시피
                            </a>
                        </c:when>
                        <c:otherwise>
                            <button class="btn btn-lg btn-secondary" disabled>
                               <i class="bi bi-book"></i> 레시피 없음
                            </button>
                        </c:otherwise>
                    </c:choose>
                </div>

                <div class="text-muted small">
                    개당 가격: <span id="unitPrice">${product.price }</span>원
                </div>

                <div class="text-danger h4 mb-3">
                    총 가격: <span id="totalPrice">19,900</span>원
                </div>

                <div class="form-group mt-3">
                    <label class="font-weight-bold">수량</label> 
                    <input type="number" id="quantity" class="form-control" value="1" min="1" max="${product.stockQuantity }" style="width: 120px">
                </div>

                <button id="addCartBtn" class="btn btn-warning btn-block font-weight-bold"
                    onclick="addToCart('${product.prodId}',document.getElementById('quantity').value)">장바구니</button>

                <button class="btn btn-danger btn-block mt-2 font-weight-bold">바로구매</button>
                
                <div class="mt-3 pt-3 border-top small text-muted">
                    <div class="d-flex align-items-center mb-1">
                        <i class="bi bi-truck mr-2"></i> <span class="font-weight-bold text-dark">5만원이상 주문시 무료배송</span>
                    </div>
                </div>
            </div>
        </div>
        </c:if>
    
    <div class="card border-0 shadow-sm">
        <div class="card-header bg-white border-bottom-0 font-weight-bold text-success d-flex justify-content-between align-items-center">
            <span><i class="fas fa-shopping-basket"></i> 장바구니</span>
            <c:if test="${cartList != null && cartList.size() > 0}">
                <span class="badge badge-success badge-pill">${cartList.size()}</span>
            </c:if>
        </div>
       
        <div class="card-body p-0" style="max-height: 50vh; overflow-y: auto;">
            <ul class="list-group list-group-flush cart-list-container">
                <c:if test="${cartList != null && not empty cartList}">
                    <c:forEach items="${cartList}" var="cartItem">
                    	<c:set var="cartTotal" value="${cartTotal + (cartItem.prodPrice * cartItem.quantity)}" />
                        <li id="cart-item-${cartItem.cartId }" class="list-group-item px-3 py-3 border-0 border-bottom">
                            <div class="d-flex align-items-start mb-2">
                                <img src="${pageContext.request.contextPath }/resources/img/${cartItem.prodImage}" 
                                     class="rounded mr-3" width="50" height="50" style="object-fit: cover;"
                                     onerror="this.src='https://dummyimage.com/50x50/dee2e6/6c757d.jpg';">
                                
                                 <div class="w-100 overflow-hidden">
                                    <a href="${pageContext.request.contextPath }/product/detail?prodId=${cartItem.prodId}" class="d-block text-dark font-weight-bold text-truncate" style="font-size: 0.95rem;">
                                        ${cartItem.prodName}
                                    </a>
                                    <span class="text-muted small">
                                         <fmt:formatNumber value="${cartItem.prodPrice}" pattern="#,###" />원
                                    </span>
                                </div>
                            </div>
                            
                            <div class="d-flex justify-content-between align-items-center mt-2">
                                <div class="d-flex align-items-center bg-light rounded p-1">
                                    <button class="btn btn-sm btn-link text-secondary p-0 px-2" type="button"
                                         onclick="updateQty('${cartItem.cartId}','minus',${cartItem.stockQuantity })">
                                        <i class="fas fa-minus small"></i>      
                                    </button>
                                    <input type="text" id="qty_sidebar_${cartItem.cartId }"
                                           class="form-control border-0 p-0 text-center bg-transparent font-weight-bold"
                                           value="${cartItem.quantity }" readonly style="width: 30px; height: 24px; font-size: 0.9rem;">
                                    <button class="btn btn-sm btn-link text-secondary p-0 px-2" type="button"
                                           onclick="updateQty('${cartItem.cartId}','plus',${cartItem.stockQuantity})">
                                        <i class="fas fa-plus small"></i>       
                                    </button>
                                </div>
                                <button type="button" class="btn btn-sm text-danger "
                                		onclick="deleteCartItem('${cartItem.cartId}')"
                                        data-cart-id="${cartItem.cartId }" title="削除">
                                    <span class="small mr-1"></span> <i class="fas fa-trash-alt"></i>
                                </button>
                            </div> 
                        </li>
                    </c:forEach>
                </c:if>

                <c:if test="${cartList == null || empty cartList}">
                    <li class="list-group-item text-center py-5 border-0">
                        <i class="fas fa-shopping-cart fa-3x text-muted mb-3 opacity-50"></i>
                        <p class="text-muted small mb-0">장바구니는 비어있습니다</p>
                    </li>
                </c:if>
            </ul>
        </div>

        <div class="card-footer bg-white border-top-0 p-3">
            <c:if test="${cartList != null && not empty cartList}">
                <div class="d-flex justify-content-between align-items-center mb-3 font-weight-bold">
                    <span>합계:</span>
                    <span class="text-danger h5 mb-0">
                        <fmt:formatNumber value="${cartTotal}" pattern="#,###" /> 원
                    </span>
                </div>
           </c:if>

            <c:if test="${member != null}">
                <a href="${pageContext.request.contextPath }/cart/view" class="btn btn-warning btn-block text-white font-weight-bold shadow-sm">
                    장바구니 보기
                </a>
            </c:if>
           <c:if test="${member == null}">
                <a href="${pageContext.request.contextPath }/member/login" class="btn btn-secondary btn-block shadow-sm">
                    로그인
                </a>
            </c:if>
        </div>
    </div>
</div>
 
<c:if test="${fn:contains(reqUrl, '/product/detail')}">
<div class="modal fade" id="recipeModal" tabindex="-1" role="dialog" aria-hidden="true" style="z-index: 1050;">
    <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable" role="document">
        <div class="modal-content">

            <div class="modal-header border-bottom-0 pb-0">
                <h3 class="modal-title font-weight-bold" id="modalRecipeTitle">
                     <i class="fas fa-spinner fa-spin"></i> 로딩중...
                </h3>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
             </div>

            <div class="modal-body">
                <div class="text-center mb-4">
                    <img id="modalRecipeImage" src="" class="img-fluid rounded shadow-sm" 
                         style="max-height: 350px; width: 100%; object-fit: cover; display: none;">
                </div>

                <div class="mb-5 px-2">
                    <h5 class="font-weight-bold border-bottom pb-2 mb-3">
                        <i class="fas fa-utensils mr-2 text-warning"></i>조리 방법
                    </h5>
                    <div id="modalRecipeContent" class="text-secondary" style="white-space: pre-line; line-height: 1.8; font-size: 1.05rem;">
                        </div>
                </div>

                <div class="bg-light p-3 rounded">
                    <h5 class="font-weight-bold mb-3">
                        <i class="fas fa-carrot mr-2 text-success"></i>관련 재료 담기
                    </h5>
                    <div id="modalIngredientList" class="row"></div>
                </div>
            </div>

            <div class="modal-footer">
            	<button type="button" class="btn btn-success font-weight-bold" onclick="addAllIngredients()">
                    <i class="fas fa-cart-plus"></i> 재료 전체 담기
                </button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">닫기</button>
            </div>
        </div>
    </div>
</div>
</c:if>


<c:if test="${fn:contains(reqUrl, '/product/detail' )}">
	<script>
	document.addEventListener('DOMContentLoaded',function() {
        const unitPrice = parseInt(document.getElementById('unitPrice').innerText);
        const qtyInput = document.getElementById('quantity');
        const totalPriceEl = document.getElementById('totalPrice');

        function updateTotalPrice() {
            const qty = parseInt(qtyInput.value) || 1;
            const total = unitPrice * qty;
            totalPriceEl.innerText = total.toLocaleString();
        }

        qtyInput.addEventListener('input', updateTotalPrice);
        updateTotalPrice(); 
    });
    </script>
</c:if>

<script>
	let currentRecipeIngredients = [];
	
    function loadRecipeDetail(recipeId) {
        $('#modalRecipeTitle').html('<i class="fas fa-spinner fa-spin"></i> 로딩중...');
        $('#modalRecipeImage').hide();
        $('#modalRecipeContent').text('');
        $('#modalIngredientList').html('');
        
        $.ajax({
            url: '${pageContext.request.contextPath}/recipe/api/' + recipeId,
            type: 'GET',
            dataType: 'json',
            success: function(recipe) {
                $('#modalRecipeTitle').text(recipe.title);
                
                if(recipe.image) {
                    let imgPath = '${pageContext.request.contextPath}/resources/img/' + recipe.image;
                    $('#modalRecipeImage').attr('src', imgPath).show();
                } else {
                     $('#modalRecipeImage').attr('src', 'https://dummyimage.com/600x400/dee2e6/6c757d.jpg&text=No+Image').show();
                }
                
                if (recipe.linkedProducts && recipe.linkedProducts.length > 0) {
                    currentRecipeIngredients = recipe.linkedProducts; // 保存！
                } else {
                    currentRecipeIngredients = [];
                }
                
                $('#modalRecipeContent').text(recipe.content);

                let listHtml = '';
                if (recipe.linkedProducts && recipe.linkedProducts.length > 0) {
                     recipe.linkedProducts.forEach(function(prod) {
                        let price = new Intl.NumberFormat('ko-KR').format(prod.price);
                        let img = '${pageContext.request.contextPath}/resources/img/' + prod.image;
                        
                        listHtml += `
                            <div class="col-md-6 mb-3">
                                <div class="card h-100 border shadow-sm">
                                     <div class="card-body p-2 d-flex align-items-center">
                                        <a href="/product/detail?prodId=\${prod.prodId}" target="_blank">
                                            <img src="\${img}" class="rounded mr-3" style="width: 60px; height: 60px; object-fit: cover;"
                                             onerror="this.src='https://dummyimage.com/60x60/dee2e6/6c757d.jpg'">
                                        </a>
                                        <div class="flex-grow-1" style="min-width: 0;">
                                            <h6 class="mb-1 text-truncate font-weight-bold" style="font-size: 0.9rem;">
                                                <a href="/product/detail?prodId=\${prod.prodId}" class="text-dark text-decoration-none">\${prod.name}</a>
                                            </h6>
                                            <div class="text-danger font-weight-bold small">\${price}원</div>
                                         </div>
                                        <button class="btn btn-sm btn-outline-warning ml-2 rounded-circle" 
                                                 onclick="addToCart('\${prod.prodId}', 1)" title="장바구니">
                                            <i class="fas fa-plus"></i>
                                        </button>
                                     </div>
                                </div>
                            </div>
                        `;
                    });
                } else {
                    listHtml = '<div class="col-12 text-center text-muted py-3">연동된 재료 상품이 없습니다.</div>';
                }
                $('#modalIngredientList').html(listHtml);
            },
            error: function() {
                alert('레시피 정보를 불러오는데 실패했습니다.');
                $('#recipeModal').modal('hide');
            }
        });
    }

    $('#recipeModal').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget); 
        var recipeId = button.data('recipe-id'); 
        
        
        if (!recipeId) {

            alert("연결된 레시피가 없습니다.");
            return false; 
        }
        
        loadRecipeDetail(recipeId);
        
        $('#recipeModal').appendTo("body"); 
    });
    
    function addAllIngredients() {
        if (currentRecipeIngredients.length === 0) {
            alert("담을 재료가 없습니다.");
            return;
        }

        if (!confirm("모든 재료(" + currentRecipeIngredients.length + "개)를 장바구니에 담으시겠습니까?")) {
            return;
        }

        let itemsToSend = currentRecipeIngredients.map(function(prod) {
            return {
                prodId: prod.prodId,
                quantity: 1
            };
        });

        $.ajax({
            url: '${pageContext.request.contextPath}/cart/addMultiple',
            type: 'POST',
            contentType: 'application/json; charset=utf-8', 
            data: JSON.stringify(itemsToSend),              
            success: function(result) {
                if (result === 'success') {
                    if (confirm('장바구니에 모든 재료를 담았습니다.\n장바구니로 이동하시겠습니까?')) {
                        location.href = '${pageContext.request.contextPath}/cart/view';
                    } else {
                        location.reload(); 
                    }
                } else if (result === 'login_required') {
                    alert('로그인이 필요합니다.');
                    location.href = '${pageContext.request.contextPath}/member/login';
                } else {
                    alert('일부 상품을 담는데 실패했습니다.');
                }
            },
            error: function() {
                alert('시스템 오류가 발생했습니다.');
            }
        });
    }
</script>