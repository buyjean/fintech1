<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<meta charset="UTF-8">


<!-- ✅ 관리자 상단 헤더 -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top shadow-sm">
  <div class="container-fluid px-3">

    <a class="navbar-brand font-weight-bold" href="${pageContext.request.contextPath}/admin/dashboard">
      <i class="fas fa-user-shield mr-2"></i> 관리자
    </a>

    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#adminNav">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="adminNav">
      <!-- 왼쪽 메뉴 -->
      <ul class="navbar-nav mr-auto mb-2 mb-lg-0">
        <li class="nav-item">
			<span class="nav-link text-white-50 disabled" style="cursor: default;">
				<i class="far fa-clock mr-1"></i> <span id="adminClock">Loading...</span>
			</span>
        </li>
	 </ul>

      <!-- 오른쪽 -->
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <a class="nav-link" href="${pageContext.request.contextPath}">
            <i class="fas fa-home mr-1"></i> 메인 페이지
          </a>
        </li>

        <li class="nav-item">
  			<a href="javascript:void(0);" id="logoutBtn" 
  				data-logout-url="${pageContext.request.contextPath}/member/logout"
     			class="nav-link text-nowrap">
				<i class="fas fa-sign-out-alt mr-1"></i> 
				로그아웃
  			</a>
		</li>
      </ul>

    </div>
  </div>
</nav>

<script>
$(document).ready(function(){
	function updateClock(){
		var now = new Date();
		
		// 0삽입( 9 -> 09 )
		var year = now.getFullYear();
		var month = String(now.getMonth() + 1).padStart(2,'0');
		var day = String(now.getDate()).padStart(2,'0');
		var h = String(now.getHours()).padStart(2,'0');
		var m = String(now.getMinutes()).padStart(2,'0');
		var s = String(now.getSeconds()).padStart(2,'0');
		
		var timeString = year+"-"+month + "-" + day + " " + h + ":" + m + ":" + s;
		
		$("#adminClock").text(timeString);
	}
	
	updateClock();/* 실행 */
	setInterval(updateClock,1000); /* 갱신 */
});

	


</script>

