<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>

<%@ include file="../includes/header.jsp" %>

<style>

    .text-decoration-line-through { text-decoration: line-through; }
    

    .card-img-top { object-fit: cover; height: 200px; }
    

    .page-item.active .page-link { background-color: #28a745; border-color: #28a745; color: #fff; }
    .page-link { color: #28a745; }
    .page-link:hover { color: #218838; }
    

    .card:hover { transform: translateY(-3px); transition: 0.3s; box-shadow: 0 .5rem 1rem rgba(0,0,0,.15)!important; }
</style>

<div class="container-fluid px-4 mt-4" style="max-width: 1600px">
    <div class="row justify-content-between">
    
        <main class="col-lg-10 order-1 order-lg-1">
        
            <div class="d-flex justify-content-between align-items-end mb-4 border-bottom pb-2">
                <h4 class="font-weight-bold mb-0">
                    <c:choose>
                        <c:when test="${param.sort == 'outlet'}">
                            <i class="fas fa-fire-alt text-danger"></i> 임박/알뜰상품
                        </c:when>
                        <c:when test="${param.sort == 'sale'}">
                            <i class="fas fa-tag text-warning"></i> 할인상품
                        </c:when>
                        <c:when test="${param.sort == 'new'}">
                            <i class="fas fa-bullhorn text-success"></i> 신규상품
                        </c:when>
                        <c:when test="${not empty param.keyword}">
                            <i class="fas fa-search text-info"></i> "${param.keyword}" 검색결과
                        </c:when>
                        <c:when test="${not empty param.categoryId}">
                            <i class="fas fa-list text-success"></i> 카테고리
                        </c:when>
                        <c:otherwise>
                            <i class="fas fa-th-large text-success"></i> 상품목록
                        </c:otherwise>
                    </c:choose>
                </h4>
                <span class="text-muted small">총 <fmt:formatNumber value="${pageMaker.total}"/> 건</span>
            </div>
            
            <div class="row">
                <c:forEach items="${resultList}" var="product">
                    <div class="col-lg-4 col-md-4 col-6 mb-4">
                        <div class="card h-100 border-0 shadow-sm mx-auto" style="width: 100%;">
                            
                            <a href="${pageContext.request.contextPath}/product/detail?prodId=${product.prodId}" class="position-relative">
                                <img class="card-img-top" src="${pageContext.request.contextPath}/resources/img/${product.image}" 
                                     alt="${product.name}"
                                     onerror="this.src='https://dummyimage.com/300x200/dee2e6/6c757d.jpg&text=No+Image';">
                                
                                <c:if test="${product.isOutlet == '1' || product.isOutlet == '2'}">
                                    <span class="badge badge-danger position-absolute shadow-sm" style="top:10px; left:10px;">
                                        알뜰상품
                                    </span>
                                </c:if>
                                
                                <c:if test="${product.discountRate > 0}">
                                    <span class="badge badge-warning text-white position-absolute shadow-sm" style="top:10px; right:10px;">
                                        SALE ${product.discountRate}%
                                    </span>
                                </c:if>
                            </a>
                            
                            <div class="card-body p-3">
                                <small class="text-muted d-block mb-1">${product.categoryName}</small>
                                
                                <h6 class="card-title font-weight-bold text-truncate">
                                    <a href="${pageContext.request.contextPath}/product/detail?prodId=${product.prodId}" class="text-dark text-decoration-none">
                                        ${product.name}
                                    </a>
                                </h6>
                                
                                <div class="d-flex justify-content-between align-items-center mt-2">
                                    <span class="h5 mb-0 font-weight-bold">
                                        <c:choose>
                                            <c:when test="${product.discountRate > 0}">
                                                <div class="d-flex flex-column align-items-start">
                                                    <small class="text-muted text-decoration-line-through" style="font-size: 0.7em;">
                                                        <fmt:formatNumber value="${product.price}" />
                                                    </small>
                                                    <span class="text-danger">
                                                        <fmt:formatNumber value="${product.salePrice}" /> <small class="text-dark">원</small>
                                                    </span>
                                                </div>
                                            </c:when>
                                            <c:otherwise>
                                                <span class="text-dark">
                                                    <fmt:formatNumber value="${product.price}" /> <small class="text-dark">원</small>
                                                </span>
                                            </c:otherwise>
                                        </c:choose>
                                    </span>
                                    
                                    <button class="btn btn-sm btn-outline-warning rounded-circle shadow-sm"
                                            onclick="addToCart('${product.prodId}')" title="장바구니에 담기">
                                        <i class="fas fa-shopping-basket"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </c:forEach>
                
                <c:if test="${empty resultList}">
                    <div class="col-12 text-center py-5 border rounded bg-light">
                        <i class="fas fa-search fa-3x text-muted mb-3"></i>
                        <h5 class="text-muted">해당하는 상품을 찾을 수없습니다</h5>
                        <p class="text-secondary small">검색조건을 바꿔서 다시시도해주세요</p>
                        <a href="${pageContext.request.contextPath}/" class="btn btn-success mt-3">메인페이지로</a>
                    </div>
                </c:if>
            </div>
            
            <c:if test="${not empty resultList && pageMaker.total > 0}">
                <div class="d-flex justify-content-center mt-5 mb-5">
                    <nav aria-label="Page navigation">
                        <ul class="pagination">
                            
                            <li class="page-item ${pageMaker.prev ? '' : 'disabled'}">
                                <a class="page-link" 
                                   href="${pageContext.request.contextPath}/product/search?pageNum=${pageMaker.startPage - 1}&amount=${pageMaker.cri.amount}&keyword=${param.keyword}&sort=${param.sort}&categoryId=${param.categoryId}" 
                                   aria-label="Previous">
                                    <span aria-hidden="true">&laquo;</span>
                                </a>
                            </li>

                            <c:forEach var="num" begin="${pageMaker.startPage}" end="${pageMaker.endPage}">
                                <li class="page-item ${pageMaker.cri.pageNum == num ? 'active' : ''}">
                                    <a class="page-link" 
                                       href="${pageContext.request.contextPath}/product/search?pageNum=${num}&amount=${pageMaker.cri.amount}&keyword=${param.keyword}&sort=${param.sort}&categoryId=${param.categoryId}">
                                        ${num}
                                    </a>
                                </li>
                            </c:forEach>

                            <li class="page-item ${pageMaker.next ? '' : 'disabled'}">
                                <a class="page-link" 
                                   href="${pageContext.request.contextPath}/product/search?pageNum=${pageMaker.endPage + 1}&amount=${pageMaker.cri.amount}&keyword=${param.keyword}&sort=${param.sort}&categoryId=${param.categoryId}" 
                                   aria-label="Next">
                                    <span aria-hidden="true">&raquo;</span>
                                </a>
                            </li>
                            
                        </ul>
                    </nav>
                </div>
            </c:if>

        </main>

        <aside class="col-lg-2 ml-auto order-2 order-lg-2 d-none d-lg-block">
            <%@ include file="../includes/sidebar.jsp" %>     
        </aside>

    </div>
</div>