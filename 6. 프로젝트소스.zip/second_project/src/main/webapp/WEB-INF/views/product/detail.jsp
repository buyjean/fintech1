<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/functions" prefix="fn"%>

<%@ include file="../includes/header.jsp"%>

<link rel="stylesheet"
	href="${pageContext.request.contextPath}/resources/css/product_detail.css">

<div class="container mt-5 mb-5">
	<div class="row">

		<div class="col-lg-8">

			<div class="product-thumb mb-3">
				<h2>${product.name }</h2>
			</div>

			<img
				src="https://dummyimage.com/700x700/e9ecef/495057&text=PRODUCT+IMAGE"
				class="img-fluid product-thumb w-100 mb-3">

			<div class="product-rating mb-4">
				<div class="star-rating">
					<span class="star-bg">★★★★★</span> <span class="star-fill"
						style="width: ${reviewStats.rating * 20}%">★★★★★</span>
				</div>
				<span class="rating-text ml-2"> <strong> <fmt:formatNumber
							value="${reviewStats.rating }" pattern="#.0" />
				</strong>점 · <span>${reviewStats.revNum }건 리뷰</span>
				</span>
			</div>

			<ul class="nav nav-tabs" id="productTab">
				<li class="nav-item"><a class="nav-link active"
					data-toggle="tab" href="#tab-detail">상세정보</a></li>
				<li class="nav-item"><a class="nav-link" data-toggle="tab"
					href="#tab-nutrition">영양 정보</a></li>
				<li class="nav-item"><a class="nav-link" data-toggle="tab"
					href="#tab-review">상품평</a></li>
			</ul>

			<div class="tab-content border p-4 bg-white">

				<div class="tab-pane fade show active" id="tab-detail">
					<h4 class="font-weight-bold mb-3">상품 상세 설명</h4>
					<p class="text-muted">${product.description }</p>
					<img
						src="https://dummyimage.com/700x1200/f8f9fa/adb5bd&text=DETAIL+CONTENT"
						class="img-fluid">
				</div>

				<div class="tab-pane fade" id="tab-nutrition">
					<div class="border-top pt-4 mt-3">
						<h4 class="font-weight-bold mb-4">영양 정보</h4>
						<div class="row">
							<div class="col-md-6 mb-4">
								<h6 class="font-weight-bold mb-2">에너지 정보</h6>
								<div style="height: 180px;">
									<canvas id="energyChart"></canvas>
								</div>
							</div>
							<div class="col-md-6 mb-4">
								<h6 class="font-weight-bold mb-2">영양 밸런스</h6>
								<div style="height: 220px;">
									<canvas id="macroRadar"></canvas>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="tab-pane fade" id="tab-review">
					<div class="container mt-5 mb-5">
						<div class="border-top pt-4">
							<h4 class="font-weight-bold mb-4">상품평
								(${reviewStats.revNum})</h4>

							<c:if test="${empty reviewList}">
								<div class="text-center py-5 text-muted border rounded">
									<i class="far fa-comment-dots fa-3x mb-3"></i>
									<p>작성된 리뷰가 없습니다</p>
								</div>
							</c:if>



							<c:if test="${not empty reviewList}">

								<div id="reviewCarousel" class="carousel slide"
									data-ride="carousel" data-interval="false">

									<div class="carousel-inner">

										<c:forEach items="${reviewList}" var="r" varStatus="status"
											step="3">

											<div class="carousel-item ${status.first ? 'active' : ''}">
												<div class="row">
													<c:forEach begin="0" end="2" var="i">
														<c:if test="${status.index + i < fn:length(reviewList)}">



															<c:set var="review"
																value="${reviewList[status.index + i]}" />

															<div class="col-md-4 mb-3">
																<div class="card h-100 shadow-sm border-0">
																	<div class="card-body">
																		<div class="d-flex justify-content-between mb-2">
																			<small class="font-weight-bold text-truncate"
																				style="max-width: 80px;">${review.userId}</small> <small
																				class="text-muted"> <fmt:formatDate
																					value="${review.regDate}" pattern="yyyy.MM.dd" />
																			</small>
																		</div>

																		<div class="text-warning mb-2"
																			style="font-size: 0.9rem;">
																			<c:forEach begin="1" end="${review.rating}">★</c:forEach>
																			<c:forEach begin="1" end="${5 - review.rating}">☆</c:forEach>
																		</div>
																		<c:if test="${not empty review.reviewImage}">
																			<div class="mb-2"
																				style="height: 150px; overflow: hidden; border-radius: 5px;">
																				<img alt="Review Image"
																					src="${pageContext.request.contextPath }/review_images/${review.reviewImage}"
																					class="w-100 h-100"
																					style="object-fit: cover; cursor: pointer;"
																					onclick="window.open(this.src)">
																			</div>

																		</c:if>

																		<p class="card-text text-secondary"
																			style="font-size: 0.9rem; height: 60px; overflow-y: auto;">
																			${review.content}</p>
																	</div>
																</div>
															</div>
														</c:if>
													</c:forEach>
												</div>
											</div>
										</c:forEach>
									</div>
									<c:if test="${fn:length(reviewList) > 3}">
										<a class="carousel-control-prev" href="#reviewCarousel"
											role="button" data-slide="prev" style="width: 5%;"> <span
											class="carousel-control-prev-icon bg-dark rounded-circle p-3"
											aria-hidden="true"></span> <span class="sr-only">previous</span>
										</a>

										<a class="carousel-control-next" href="#reviewCarousel"
											role="button" data-slide="next" style="width: 5%;"> <span
											class="carousel-control-next-icon bg-dark rounded-circle p-3"
											aria-hidden="true"></span> <span class="sr-only">next</span>
										</a>
									</c:if>
								</div>
							</c:if>

						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-lg-4">
			<%@ include file="../includes/sidebar.jsp"%>
		</div>

	</div>
</div>
<div class="container mt-5 mb-5">
	<div class="border-top pt-4">
		<h4 class="font-weight-bold mb-4">함께 보면 좋은 상품</h4>
		<div class="row">
			<c:forEach items="${relatedList }" var="relatedProduct">
				<div class="col-md-2 mb-2">
					<a
						href="${pageContext.request.contextPath }/product/detail?prodId=${relatedProduct.prodId}"
						class="text-decoration-none text-dark">
						<div class="card border-0 shadow-sm h-60">
							<img src="/resources/img/${relatedProduct.image }"
								class="card-img-top"
								onerror="https://dummyimage.com/400x400/e9ecef/495057&text=RECOMMEND+1">
							<div class="card-body p-2">
								<h6 class="card-title mb-1 text-truncate">${relatedProduct.name }</h6>
								<div class="text-danger font-weight-bold">
									₩
									<fmt:formatNumber value="${relatedProduct.price }"
										pattern="#,###" />
								</div>
							</div>
						</div>
					</a>
				</div>
			</c:forEach>
		</div>
	</div>
</div>

<script>
document.addEventListener("DOMContentLoaded", function() {

  // Energy Chart
  const energyChart = new Chart(
    document.getElementById('energyChart'),
    {
      type: 'bar',
      data: {
        labels: ['KCAL', 'WEIGHT(g)'],
        datasets: [{
          data: [${product.kcal}, ${product.weight}],
          barThickness: 30,
          backgroundColor : [ 'rgba(220, 53, 69, 0.7)', 'rgba(23, 162, 184, 0.7)' ]
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } }
      }
    }
  );

  // Macro Radar Chart
  const macroRadar = new Chart(
    document.getElementById('macroRadar'),
    {
      type: 'radar',
      data: {
        labels: ['PROTEIN', 'CARB', 'FAT'],
        datasets: [{
          data: [${product.protein}, ${product.carb}, ${product.fat}],
          backgroundColor : 'rgba(40, 167, 69, 0.2)',
          borderColor : 'rgba(40, 167, 69, 1)',
          pointBackgroundColor : 'rgba(40, 167, 69, 1)'
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            r: {
              min: 0,
              suggestedMax: 100,
              max: 100, 
              ticks: { stepSize: 10, backdropColor: 'transparent' },
              pointLabels: { font: { size: 13, weight: 'bold' } }
            }
          },
        plugins: { legend: { display: false } }
      }
    }
  );

  $('a[data-toggle="tab"]').on('shown.bs.tab', function () {
    energyChart.resize();
    macroRadar.resize();
  });

});
</script>