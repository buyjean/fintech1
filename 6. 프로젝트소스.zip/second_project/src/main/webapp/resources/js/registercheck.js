
function checkPasswordMatch() {
  const pw = document.getElementById('password').value;
  const pw2 = document.getElementById('confirmUserPw').value;
  const msg = document.getElementById('pwdMatchMessage');

  if (!pw2) { msg.innerText = ""; return false; }

  if (pw.length < 6) {
    msg.style.color = "red";
    msg.innerText = "비밀번호는 6자 이상이어야 합니다.";
    return false;
  }

  if (pw === pw2) {
    msg.style.color = "green";
    msg.innerText = "비밀번호 일치";
    return true;
  } else {
    msg.style.color = "red";
    msg.innerText = "비밀번호 불일치";
    return false;
  }
}

function nowSamePassword() {
  const pw = document.getElementById('currentPassword').value;
  const msg = document.getElementById('nowpwdSameMessage');
  if (!msg) return;

  if (!pw) { msg.innerText = ""; return; }

  const xhr = new XMLHttpRequest();
  xhr.open("POST", CTX + "/member/currentPasswordCheck", true);
  xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");

  xhr.onreadystatechange = function () {
    if (xhr.readyState === 4) {
      if (xhr.status === 200) {
        const res = xhr.responseText.trim();

        if (res === "NO_LOGIN") {
          msg.style.color = "red";
          msg.innerText = "로그인이 필요합니다.";
        } else if (res === "OK") {
          msg.style.color = "green";
          msg.innerText = "현재 비밀번호가 맞습니다.";
        } else if (res === "FAIL") {
          msg.style.color = "red";
          msg.innerText = "현재 비밀번호가 올바르지 않습니다.";
        } else {
          msg.style.color = "red";
          msg.innerText = "서버 응답 오류";
        }
      } else {
        msg.style.color = "red";
        msg.innerText = "통신 오류(" + xhr.status + ")";
      }
    }
  };

  xhr.send("password=" + encodeURIComponent(pw));
}



	
function checkSamePassword() {
  const pw = document.getElementById('password').value;
  const msg = document.getElementById('pwdSameMessage');

  if (!pw) { msg.innerText = ""; return; }

  const xhr = new XMLHttpRequest();
  xhr.open("POST", CTX + "/member/passwordCheck", true);
  xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");

  xhr.onreadystatechange = function () {
    if (xhr.readyState === 4) {
      if (xhr.status === 200) {
        const res = xhr.responseText.trim();

        if (res === "NO_LOGIN") {
          msg.style.color = "red";
          msg.innerText = "로그인이 필요합니다.";
        } else if (res === "SAME") {
          msg.style.color = "red";
          msg.innerText = "기존 비밀번호와 동일합니다.";
        } else if (res === "DIFF") {
          msg.style.color = "green";
          msg.innerText = "사용 가능한 새 비밀번호입니다.";
        } else {
          msg.style.color = "red";
          msg.innerText = "서버 응답 오류";
        }
      } else {
        msg.style.color = "red";
        msg.innerText = "통신 오류(" + xhr.status + ")";
      }
    }
  };

  xhr.send("password=" + encodeURIComponent(pw));
}

	
	
    let idChecked = false;

    function resetIdCheck() {
      idChecked = false;
      document.getElementById("idMessage").innerText = "";
    }

    function checkIdDuplicate() {
      const userId = document.getElementById("userId").value.trim();
      const msg = document.getElementById("idMessage");

      if (!userId) {
        msg.style.color = "red";
        msg.innerText = "아이디 입력하세요.";
        idChecked = false;
        return;
      }
      if (userId.length < 4) {
        msg.style.color = "red";
        msg.innerText = "아이디는 4자 이상";
        idChecked = false;
        return;
      }

      const xhr = new XMLHttpRequest();
      xhr.open("POST", CTX + "/member/idCheck", true);
      xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");

      xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
          const res = xhr.responseText.trim(); // 0 가능, 1 중복
          if (res === "0") {
            msg.style.color = "green";
            msg.innerText = "사용 가능한 아이디";
            idChecked = true;
          } else {
            msg.style.color = "red";
            msg.innerText = "이미 사용 중인 아이디";
            idChecked = false;
          }
        }
      };

      xhr.send("userId=" + encodeURIComponent(userId));
    }

    function validateForm() {
      const pw = document.getElementById('password').value;
      const pw2 = document.getElementById('confirmUserPw').value;
      const idMsg = document.getElementById('idMessage');

      if (!idChecked) {
    	idMsg.style.color = "red";
   		idMsg.innerText = "아이디 중복확인을 해주세요.";
    	document.getElementById('userId').focus();
    	return false;
  	  }
      return true;
    }
    