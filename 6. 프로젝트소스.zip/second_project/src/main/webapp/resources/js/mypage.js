window.execDaumPostcode = function () {

    if (!window.daum || !daum.Postcode) {
      alert("주소 검색 스크립트가 아직 로딩되지 않았습니다.\n새로고침 후 다시 시도해주세요.");
      return;
    }

    new daum.Postcode({
      oncomplete: function(data) {

        const zipcode = document.getElementById("zipcode");
        const addrMain = document.getElementById("addrMain");
        const addrDetail = document.getElementById("addrDetail");

        // 비동기 탭이므로 null 체크 필수
        if (zipcode) zipcode.value = data.zonecode;
        if (addrMain) addrMain.value = data.roadAddress;
        if (addrDetail) addrDetail.focus();
      }
    }).open();
  };
  
const content = document.getElementById("mypageContent");
const links = document.querySelectorAll(".mypage-menu a[data-url]");

function setActive(link) {
  document.querySelectorAll(".mypage-menu li").forEach(li => li.classList.remove("active"));
  link.closest("li").classList.add("active");
}

function loadTab(url, tabName) {
  fetch(url, { headers: { "X-Requested-With": "XMLHttpRequest" } })
    .then(res => res.text())
    .then(html => { content.innerHTML = html; })
    .catch(() => { content.innerHTML = "<p>탭을 불러오지 못했습니다.</p>"; });

  // ✅ tabName 있을 때만 URL 갱신
  if (tabName) {
    const newUrl = `${window.CTX}/member/mypage?tab=${encodeURIComponent(tabName)}`;
    history.pushState({ tab: tabName }, "", newUrl);
  }
}

// 클릭 이벤트
links.forEach(a => {
  a.addEventListener("click", (e) => {
    e.preventDefault();
    setActive(a);
    loadTab(a.dataset.url, a.dataset.tab);
  });
});

// 최초 로딩: URL의 tab 파라미터 반영
const params = new URLSearchParams(location.search);
const tab = params.get("tab") || "point";

const first =
  document.querySelector(`.mypage-menu a[data-tab="${tab}"]`)
  || document.querySelector(".mypage-menu a[data-url]");

if (first) {
  setActive(first);
  loadTab(first.dataset.url, first.dataset.tab);
}

  


