/**
 * 
 */
 


$(document).ready(function() {
    

    
    $(".qty-btn").click(function(){
        let operation = $(this).hasClass('btn-plus') ? 'plus' : 'minus';
        let input = $(this).siblings('.qty-input');
        let currentVal = parseInt(input.val());
        let cartId = $(this).data("cart-id");
        let newVal = currentVal;
        
        if(operation === 'plus'){
            newVal++;
        } else {
            if(newVal > 1){
                newVal--;
            } else {
                return; 
            }
        }
        
        if(newVal != currentVal){
            input.val(newVal); 
            
            $.ajax({
                url: window.CTX + '/cart/update',
                type: 'POST',
                data: { cartId : cartId, quantity : newVal },
                success:function(result){
                    location.reload(); 
                },
                error: function(){
                    alert("수량 변경 실패");
                    input.val(currentVal);
                }
            });
        }
    });
    

    $(".btn-delete-corner").click(function(){
        let cartId = $(this).data("cart-id");
        if(!confirm("삭제하시겠습니까?")) return;
        
        $.ajax({
            url: window.CTX + '/cart/delete',
            type: 'POST',
            data: { cartId : cartId },
            success:function(){
                location.reload();
            },
            error:function(){
                alert("삭제 실패");
            }
        });
    });


    const minD = new Date();
    minD.setDate(minD.getDate()+2);
    const maxD = new Date();
    maxD.setMonth(maxD.getMonth()+1);
    
    const fp = flatpickr("#deliveryDate", {
        locale: "ko", dateFormat: "Y-m-d", minDate: minD, maxDate:maxD,
        onChange: function(selectedDates, dateStr) { 
            $("#sideDeliveryDate").text(dateStr);
        }
    });
    $("#calendar-picker-btn, #deliveryDate").click(() => fp.open());

    const fpTime = flatpickr("#deliveryTime", {
        locale: "ko", enableTime: true, noCalendar: true, dateFormat: "H:i", time_24hr: true,
        onChange: function(selectedTimes, TimeStr) {
            $("#sideDeliveryTime").text(TimeStr);
        }
    });
    $("#watch-picker-btn, #deliveryTime").click(() => fpTime.open());


    const originalPrice = parseInt($("#finalTotalPrice").text().replace(/[^0-9]/g, ''));
    let isApplied = false;

    $("#btn-point").click(function() {
        const pointInput = $("#Point");
        const maxPoint = parseInt(pointInput.data("max"));
        let usePoint = pointInput.val();

        if (isApplied) {
            isApplied = false;
            $(this).text("사용").removeClass("btn-danger").addClass("btn-dark");
            pointInput.prop("readonly", false).val("");
            updateUI(0); 
            return;
        }

  
        if (!usePoint || usePoint == 0) return alert("사용할 포인트를 입력하세요.");
        usePoint = parseInt(usePoint);

        if (usePoint > maxPoint) {
            alert("보유 포인트가 부족합니다.");
            pointInput.val(maxPoint);
            return;
        }

        isApplied = true;
        $(this).text("취소").removeClass("btn-dark").addClass("btn-danger");
        pointInput.prop("readonly", true);
        updateUI(usePoint);
    });

    function updateUI(point) {
        const finalPrice = originalPrice - point;
        $("#finalTotalPrice").text(finalPrice.toLocaleString() + "원");
        $("#pointDiscountArea").text("- " + point.toLocaleString() + "원");
        $("#usedPointHidden").val(point);
    }


    $('#pay-button').click(function(){
        const dDate = $("#deliveryDate").val();
        const dTime = $("#deliveryTime").val(); 
        
        if (!dDate) { alert("배송 희망일을 선택해주세요."); return; }
        if (!dTime) { alert("배송 시간을 선택해주세요."); return; }
        
        const selectedRadio = document.querySelector('input[name="pg_mode"]:checked');
        if (!selectedRadio) { alert("결제 수단을 선택해주세요."); return; }
        const userChoice = selectedRadio.value;

     
        const rawPrice = document.getElementById('finalTotalPrice').innerText; 
        const amount = parseInt(rawPrice.replace(/[^0-9]/g, '')); 
        const usedPoint = document.getElementById('usedPointHidden').value || 0;


        const orderTitle = $("#hiddenOrderTitle").val();
        const buyerEmail = $("#hiddenBuyerEmail").val();
        const buyerName = $("#hiddenBuyerName").val();
        const buyerTel = $("#hiddenBuyerTel").val();
        const buyerPostcode = $("#hiddenBuyerZip").val();
        const buyerAddr = $("#hiddenBuyerAddr").val();


        const IMP = window.IMP;
        IMP.init('imp42506678'); 
        

        const today = new Date();
        const dateStr = today.getFullYear() + "" + String(today.getMonth() + 1).padStart(2,'0') + "" + String(today.getDate()).padStart(2,'0');
        const timeStr = String(today.getHours()).padStart(2,'0') + "" + String(today.getMinutes()).padStart(2,'0') + "" + String(today.getSeconds()).padStart(2,'0');
        const randomStr = Math.random().toString(36).substring(2,7).toUpperCase();
        const makeMerchantUid = dateStr + timeStr + randomStr;

        const requestData = {
            pg: 'html5_inicis',
            pay_method: userChoice,
            merchant_uid: "ORD" + makeMerchantUid,
            name: orderTitle,
            amount: amount, 
            buyer_email: buyerEmail,
            buyer_name: buyerName,
            buyer_tel: buyerTel,
            buyer_addr: buyerAddr,
            buyer_postcode: buyerPostcode
        };

        IMP.request_pay(requestData, function(response) {
            if (response.success) {
                $.ajax({
                    url: window.CTX + "/order/payment/complete", 
                    type: "POST",
                    data: {
                        imp_uid: response.imp_uid,
                        merchant_uid: response.merchant_uid,
                        amount: response.paid_amount,
                        usedPoint: usedPoint,
                        addrName: $("#orderReceiverName").val(),
                        tel: $("#orderReceiverPhone").val(),
                        zipcode: $("#orderZipcode").val(),
                        addrMain: $("#orderAddrMain").value, // DOMから再取得 (変更されている可能性があるため)
                        addrDetail: $("#orderAddrDetail").value,
                        // addrMainなどがundefinedになるのを防ぐためjQuery取得推奨
                        addrMain: document.getElementById("orderAddrMain").value,
                        addrDetail: document.getElementById("orderAddrDetail").value,
                        
                        deliveryReqDate: dDate,
                        deliveryTime: dTime
                    },
                    success: function(res) {
                        location.href = window.CTX + "/order/complete?uid=" + response.merchant_uid;
                    },
                    error: function() {
                        alert("결제는 성공했으나 주문 저장에 실패했습니다. 관리자에게 문의하세요.");
                    }
                });
            } else {
                alert("결제 실패: " + response.error_msg);
            }
        });
    });
});


function execDaumPostcode(){
    new daum.Postcode({
        oncomplete: function(data) {
            var addr = (data.userSelectedType === 'R') ? data.roadAddress : data.jibunAddress;
            document.getElementById('newZipcode').value = data.zonecode;
            document.getElementById("newAddrMain").value = addr;
            document.getElementById("newAddrDetail").focus();
        }
    }).open();
}

function applyNewAddress(){
    const name = document.getElementById("newReceiverName").value;
    const phone = document.getElementById("newReceiverPhone").value;
    const zipcode = document.getElementById("newZipcode").value;
    const addrMain = document.getElementById("newAddrMain").value;
    const addrDetail = document.getElementById("newAddrDetail").value;
    
    if(!name || !phone || !zipcode || !addrMain){
        alert("입력하지 않은 정보가 있습니다");
        return;
    }
    

    document.getElementById("orderReceiverName").value = name;
    document.getElementById("orderReceiverPhone").value = phone;
    document.getElementById("orderZipcode").value = zipcode;
    document.getElementById("orderAddrMain").value = addrMain;
    document.getElementById("orderAddrDetail").value = addrDetail;
    

    document.getElementById("displayReceiverName").innerText = name;
    document.getElementById("displayReceiverPhone").innerText = phone;
    document.getElementById("displayAddr").innerText = "["+ zipcode + "] " + addrMain + " " + addrDetail;
    
    $('#addressModal').modal('hide');
}