document.addEventListener("submit", (e) => {
  const form = e.target.closest("#profileForm");
  if (!form) return;

  // 이미 확인 완료 후 재-submit이면 막지 않기
  if (form.dataset.confirmed === "true") return;

  e.preventDefault(); // 제출 막기

  const doSubmit = () => {
    form.dataset.confirmed = "true";
    form.submit();
  };

  // SweetAlert2 없으면 기본 confirm
  if (typeof Swal === "undefined") {
    if (confirm("수정 하시겠습니까?\n회원정보가 변경됩니다.")) doSubmit();
    return;
  }

  Swal.fire({
    icon: "question",
    title: "수정 하시겠습니까?",
    text: "회원정보가 변경됩니다.",
    showCancelButton: true,
    confirmButtonText: "확인",
    cancelButtonText: "취소"
  }).then((result) => {
    if (result.isConfirmed) doSubmit();
  });
});

/* 1. 現在のパスワード検証 (AJAXでサーバーと通信) */
function nowSamePassword() {
    var userId = $("input[name='userId']").val();
    var currentPassword = $("#currentPassword").val();
    var message = $("#nowpwdSameMessage");

    // 空欄ならメッセージを消して終了
    if (currentPassword == "") {
        message.text("");
        return;
    }

    $.ajax({
        // プロジェクト名(コンテキストパス)がある場合は "/grocery/member/checkPw" のように修正が必要
        url : window.CTX +"/member/checkPw", 
        type : "post",
        data : {
            userId : userId,
            password : currentPassword
        },
        success : function(result) {
            // Controllerが boolean (true/false) を返してくる想定
            if (result == true) {
                message.text("현재 비밀번호와 일치합니다").css("color", "green");
            } else {
                message.text("현재 비밀번호와 일치하지 않습니다").css("color", "red");
            }
        },
        error : function() {
            console.log("サーバー通信エラー: /member/checkPw が見つからないかエラーが発生しました");
        }
    });
}

/* 2. 新しいパスワードの一致確認 (画面内だけで完結) */
function checkSamePassword() {
    var p1 = $("#password").val();        // 新しいパスワード
    var p2 = $("#confirmUserPw").val();   // 確認用入力
    var message = $("#pwdMatchMessage");  // 結果表示エリア

    if (p1 != "" && p2 != "") {
        if (p1 == p2) {
            message.text("비밀번호가 일치합니다").css("color", "green");
        } else {
            message.text("비밀번호가 일치하지 않습니다").css("color", "red");
        }
    } else {
        message.text("");
    }
}
