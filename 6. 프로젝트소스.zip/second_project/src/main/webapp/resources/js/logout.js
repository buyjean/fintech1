document.addEventListener("click", function (e) {
  const logoutBtn = e.target.closest("#logoutBtn");
  if (!logoutBtn) return;

  // Swal이 없으면 confirm으로 fallback
  if (typeof Swal === "undefined") {
    if (confirm("로그아웃 하시겠습니까?")) {
      location.href = logoutBtn.dataset.logoutUrl;
    }
    return;
  }

  Swal.fire({
    title: "로그아웃 하시겠습니까?",
    text: "로그인 상태가 종료됩니다.",
    icon: "question",
    showCancelButton: true,
    confirmButtonText: "확인",
    cancelButtonText: "취소",
    confirmButtonColor: "#28a745",
    cancelButtonColor: "#aaa"
  }).then((result) => {
    if (result.isConfirmed) {
      location.href = logoutBtn.dataset.logoutUrl;
    }
  });
});
