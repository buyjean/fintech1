/**
 * @param {number|string} prodId
 * @param {number|string} quantity
 */
 
 const Toast = Swal.mixin({
    toast: true,
    position: 'bottom-end', 
    showConfirmButton: false,
    timer: 750,            
    timerProgressBar: true,
    didOpen: (toast) => {
        toast.addEventListener('mouseenter', Swal.stopTimer)
        toast.addEventListener('mouseleave', Swal.resumeTimer)
    }
});
 
function addToCart(prodId, quantity) {

    if (!quantity || quantity < 1) {
        quantity = 1;
    }

    $.ajax({
        url: ctx + '/cart/add',
        type: 'POST',
        data: {
            prodId: prodId,
            quantity: quantity
        },
        success: function(response) {

            if (response == "1") {
				Toast.fire({
                    icon: 'success',
                    title: '장바구니에 추가했습니다'
                }).then(() => {
                    location.reload(); 
                });
            } else if (response == "2") {
                Toast.fire({
                    icon: 'warning',
                    title: '이미 담겨있는 상품입니다'
                });
            }else{
            	location.href = ctx + "/member/login";
            }
        },
        error: function(xhr, status, error) {

            if (xhr.status == 401) {
				Swal.fire({
                    title: '로그인이 필요합니다',
                    text: "로그인화면으로 이동하겠습니까?",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: '예',
                    cancelButtonText: '취소'
                }).then((result) => {
                    if (result.isConfirmed) {
                        location.href = window.CTX + "/member/login";
                    }
                });
            } else {
                Swal.fire({
                    icon: 'error',
                    title: '에러발생',
                    text: '통신에러가 발생했습니다'
                });
                console.error(error);
            }
        }

    });
}

function updateQty(cartId, type, maxStock) {
    let input = $('#qty_sidebar_' + cartId);
    let currentVal = parseInt(input.val());
    let newVal = currentVal;
    
    if (type === 'plus') {
        if (currentVal < maxStock) {
            newVal++;
        } else {
            Swal.fire({
                icon: 'warning',
                title: '재고한계',
                text: `이 이상 담을 수 없습니다 (현재수량: ${maxStock}개)`,
                confirmButtonColor: '#3085d6'
            });
            return;
        }
    } else {
        if (currentVal > 1) {
            newVal--;
        } else {
            Swal.fire({
                icon: 'warning',
                title: '수량에러',
                text: '수량은 1개이상이여야 합니다',
                confirmButtonColor: '#3085d6'
            });
            return;
        }
    }
    
    if (newVal != currentVal) {
        input.val(newVal); 
        
        $.ajax({
            url: window.CTX + '/cart/update',
            type: 'POST',
            data: {
                cartId: cartId,
                quantity: newVal
            },
            success: function(result) {
                if (result && result.trim() === 'OK') {
                    location.reload(); 
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: '갱신실패',
                        text: '수량을 갱신할 수 없었습니다'
                    });
                    input.val(currentVal); 
                }
            },
            error: function() {
                Swal.fire({
                    icon: 'error',
                    title: '통신에러',
                    text: '서버 연결 중 문제가 발생하였습니다'
                });
                input.val(currentVal); 
            }
        });
    }
}
    
    
function deleteCartItem(cartId) {
    Swal.fire({
        title: '삭제하겠습니까',
        text: "이 상품을 장바구니에서 삭제합니다",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: '예',
        cancelButtonText: '취소'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: window.CTX + '/cart/delete',
                type: 'POST',
                data: { cartId: cartId },
                dataType: 'text',
                success: function(result) {
                    
                    console.log("Delete Result: ", result); 
                    
                   
                    var cleanResult = result ? result.trim() : "";

                    
                    if (cleanResult === 'OK' || cleanResult === 'success') {
                        Toast.fire({
                            icon: 'success',
                            title: '삭제하였습니다'
                        });
                        $('#cart-item-' + cartId).slideUp(300, function() {
                            $(this).remove();                                                         
                            if ($('.cart-list-container li').length === 0) {
                                location.reload(); 
                            }
                        });                           
                    } else {
                        
                        console.warn("Unexpected response:", result);
                        Swal.fire('에러', '삭제 실패 (Response: ' + cleanResult + ')', 'error');
                    }
                },
                error: function(xhr, status, error) {
                    console.error("AJAX Error:", status, error);
                    Swal.fire('에러', '통신 에러', 'error');
                }
            });
        }
    });
}