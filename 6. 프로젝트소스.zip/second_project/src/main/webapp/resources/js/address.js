function execDaumPostcode() {
  new daum.Postcode({
    oncomplete: function(data) {
      document.getElementById('zipcode').value = data.zonecode;
      document.getElementById('addrMain').value = data.roadAddress;
      document.getElementById('addrDetail').focus();
    }
  }).open();
}
