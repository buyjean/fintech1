// 영수증 버튼 클릭 (중복 바인딩 방지: off -> on)

$(document).off("click.receipt", ".btn-bill").on("click.receipt", ".btn-bill", function () {
  const orderId = $(this).attr("data-order-id"); //가장 확실
  console.log("영수증 클릭, orderId =", orderId);

  if (!orderId) {
    alert("주문번호(orderId)를 찾지 못했습니다. 버튼에 data-order-id가 있는지 확인하세요.");
    console.error("data-order-id missing:", this);
    return;
  }

  const $modal = $("#receiptModal");
  const $content = $("#receiptContent");

  if ($content.length === 0) {
    console.error("#receiptContent가 페이지에 없습니다. (모달 HTML을 mypage.jsp에 넣어야 함)");
    return;
  }

  // CTX 강제 사용
  const ctx = window.CTX || "";
  const url = ctx + "/member/tab/receipt?orderId=" + encodeURIComponent(orderId);
  console.log("receipt url =", url);

  $content.load(url, function (res, status, xhr) {
    console.log("load status =", status, "http =", xhr && xhr.status);

    if (status === "success") {
      if ($modal.length === 0) {
        console.error("#receiptModal이 페이지에 없습니다.");
        return;
      }
      $modal.addClass("show");
    } else {
      alert("영수증을 불러오지 못했습니다. (HTTP " + (xhr && xhr.status) + ")");
      console.error(res);
    }
  });
});

$(document).off("click.receiptClose", ".modal-close").on("click.receiptClose", ".modal-close", function () {
  $("#receiptModal").removeClass("show");
});

$(document).on("click", ".order-link", function (e) {
  e.preventDefault();

  const orderId = $(this).data("order-id");
  console.log("주문 클릭됨 orderId =", orderId);

  if (!orderId) return;

  const url = window.CTX + "/member/tab/orderdetail?orderId=" + encodeURIComponent(orderId);

  $("#mypageContent").load(url, function (response, status, xhr) {
    console.log("status:", status, "http:", xhr && xhr.status);
    if (status !== "success") console.error(response);
  });
});


$(document).on('click', '.btn-shipping-modal', function() {
    const status = $(this).data('status');
    console.log("配送状況クリック: " + status);


    const steps = ['PAYMENT_DONE', 'PREPARING', 'DELIVERY_READY', 'SHIPPING', 'DELIVERY'];
    const ctx = window.CTX || ""; 

    steps.forEach(key => {
        $('#img-' + key).attr('src', ctx + '/resources/img/' + key + '_off.png');

        // $('#step-' + key).removeClass('active'); 
    });


    let targetKey = '';
    if (status === '주문완료') targetKey = 'PAYMENT_DONE';
    else if (status === '상품준비중') targetKey = 'PREPARING';
    else if (status === '배송시작') targetKey = 'DELIVERY_READY';
    else if (status === '배송중') targetKey = 'SHIPPING';
    else if (status === '배송완료') targetKey = 'DELIVERY';


    if (targetKey) {
        $('#img-' + targetKey).attr('src', ctx + '/resources/img/' + targetKey + '_on.png');
        // $('#step-' + targetKey).addClass('active');
    }

 
    $('#shippingModal').addClass('show');
    $('body').append('<div class="modal-backdrop fade show" id="shippingBackdrop"></div>'); // 背景追加
});


$(document).on('click', '#shippingModal .modal-close', function() {
    $('#shippingModal').removeClass('show');
    $('#shippingBackdrop').remove(); 
});
