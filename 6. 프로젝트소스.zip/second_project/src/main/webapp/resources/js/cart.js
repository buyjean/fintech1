/**
 * 
 */
 
 /**
 * cart.js
 * カート画面の動作ロジック
 */

$(document).ready(function() {
    
    var swiper = new Swiper(".mySwiper", {
        slidesPerView: 2, 
        spaceBetween: 20, 
        loop: true,       
        autoplay: {
            delay: 2500,
            disableOnInteraction: false,
        },
        pagination: {
            el: ".swiper-pagination",
            clickable: true,
        },
        breakpoints: {
            768: { slidesPerView: 3, spaceBetween: 30 },
            1024: { slidesPerView: 4, spaceBetween: 20 }
        }
    });
    
    $("#checkAll").click(function(){ 
        $(".item-check").prop("checked", $(this).prop("checked")); 
    });
    
    // 個別選択時の全体選択連動
    $(".item-check").click(function(){
        if($(".item-check:checked").length == $(".item-check").length){
            $("#checkAll").prop("checked", true);
        } else {
            $("#checkAll").prop("checked", false);
        }
    });
    
    $(".qty-btn").click(function(){
        let operation = $(this).hasClass('btn-plus') ? 'plus' : 'minus';
        let input = $(this).siblings('.qty-input');
        let currentVal = parseInt(input.val());
        let cartId = $(this).data("cart-id");
        let newVal = currentVal;
        
        if(operation === 'plus'){
            newVal++;   
        } else {
            if(newVal > 1){
                newVal--;
            } else {
                return; // 1以下にはしない
            }
        }
        
        if(newVal != currentVal){
            input.val(newVal); // 見た目を先に更新
            
            $.ajax({
                url: window.CTX + '/cart/update', // window.CTXを使用
                type: 'POST',
                data: {
                    cartId : cartId,
                    quantity : newVal
                },
                success:function(result){
                    location.reload(); // 金額再計算のためリロード
                },
                error: function(result){
                    alert("수량 변경 실패");
                    input.val(currentVal); // 元に戻す
                }
            });
        }
    });
    
    $(".btn-delete-corner").click(function(){
        let cartId = $(this).data("cart-id");
        
        Swal.fire({
            title: '삭제하시겠습니까?',
            text: "장바구니에서 상품이 제거됩니다.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: '네, 삭제합니다'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: window.CTX + '/cart/delete',
                    type: 'POST',
                    data:{ cartId : cartId },
                    success:function(result){
                         Swal.fire('삭제됨!', '상품이 삭제되었습니다.', 'success').then(() =>{
                             location.reload();
                         });
                    },
                    error:function(result){
                        alert("삭제에 실패하였습니다");
                    }
                });
            }
        });
    });

    $(".btn-delete-checked").click(function(){
        let checkedItems = $(".item-check:checked");
        
        if(checkedItems.length === 0){
            Swal.fire('선택된 상품이 없습니다.', '', 'info');
            return;
        }
        
        let cartIds = [];
        checkedItems.each(function(){
            cartIds.push($(this).data("cart-id"));
        });
        
        Swal.fire({
            title: '삭제하시겠습니까?',
            text: checkedItems.length + "개의 상품이 제거됩니다.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: '네, 삭제합니다'
        }).then((result) =>{
            if(result.isConfirmed){
                $.ajax({
                    url: window.CTX + '/cart/delete/batch',
                    type: 'POST',
                    data: { cartIds : cartIds },
                    success: function(response){
                        if(response === 'success'){
                            Swal.fire('삭제됨!', '상품이 삭제되었습니다.', 'success').then(() =>{
                                location.reload();
                            });
                        }
                    },
                    error: function(response){
                        alert("통신 에러");
                    }
                });
            }
        });
    });


    window.requestPay = function(){        
        let cartCount = $(".btn-delete-corner").length;
        
        if(cartCount === 0){
            Swal.fire({
                icon: 'warning',
                title: '장바구니가 비어있습니다',
                text: '장바구니에 상품을 담고 주문을 진행해주세요'
            });
            return;
        }
        location.href = window.CTX + '/order/checkout';
    }
});