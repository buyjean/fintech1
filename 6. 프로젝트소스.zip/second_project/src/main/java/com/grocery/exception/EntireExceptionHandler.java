package com.grocery.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class EntireExceptionHandler {
	
	private static final Logger logger = LoggerFactory.getLogger(EntireExceptionHandler.class);
	
	@ExceptionHandler(Exception.class)
	public String handleException(Exception e, Model model) {
		logger.error("시스템에러발생",e);
		//개발자용 - 콘솔표시
		e.printStackTrace();
		
		//사용자용 - 메세지 표시
		model.addAttribute("errorMsg","예상하지 못한 에러 발생");
		model.addAttribute("errorDetail",e.getMessage());
		
		//에러 전용 페이지
		return "error/500";
	}

}
