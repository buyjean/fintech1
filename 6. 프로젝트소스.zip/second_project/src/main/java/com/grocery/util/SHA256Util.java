package com.grocery.util;

import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;

public class SHA256Util {
	
	// salt생성 메서드 -> 매번다른 문자열,보안강화
	
	public static String generateSalt() {
		SecureRandom random = new SecureRandom();
		byte[] salt = new byte[16];
		random.nextBytes(salt);
		return Base64.getEncoder().encodeToString(salt);
	}
	
	// pw + salt로 암호화(해쉬)하는 메서드
	
	public static String getEncrypt(String password,String salt) {
		String result = "";
		try {
			
			String input = password + salt;
			MessageDigest md = MessageDigest.getInstance("SHA-256");
			md.update(input.getBytes());
			byte[] byteData = md.digest();
			
			//16진수문자열로 변환
			StringBuffer sb = new StringBuffer();
			for(int i=0;i<byteData.length;i++) {
				sb.append(Integer.toString((byteData[i] & 0xff) + 0x100, 16).substring(1));
			}
			result = sb.toString();
		}catch(Exception e) {
			e.printStackTrace();
			throw new RuntimeException("암호화오류",e);
		}
		return result;
	}

}
