package com.grocery.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grocery.mapper.CartMapper;
import com.grocery.vo.CartVO;

@Service
public class CartServiceImpl implements CartService{
	
	@Autowired
	private CartMapper cartMapper;
	
	@Override
	public int addCart(CartVO cart) throws Exception{
		CartVO check = cartMapper.checkCart(cart);
		// 중복 확인
		if(check != null) {
			return 2;
		}
		
		try {
			return cartMapper.addCart(cart);
		}catch(Exception e) {
			return 0;
		}
	}
	
	@Override
	public List<CartVO> getCartList(String userId) throws Exception{
		return cartMapper.getCartList(userId);
	}
	
	@Override
	public int modifyQuantity(CartVO cart) throws Exception{
		
		return cartMapper.modifyQuantity(cart);
	}
	
	@Override
	public int deleteCart(int cartId) throws Exception{
		return cartMapper.deleteCart(cartId);
	}
	
	@Override
	public void deleteCartBatch(List<Integer> cartIds) throws Exception{
		cartMapper.deleteCartBatch(cartIds);
	}
	
	@Override
	public CartVO checkCart(CartVO cart) throws Exception{

		return cartMapper.checkCart(cart);
	}
	
	@Override
	public int deleteCartAll(String userId) throws Exception{
		return cartMapper.deleteCartAll(userId);
	}

}
