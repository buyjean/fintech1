package com.grocery.service;

import com.grocery.vo.RecipeVO;

public interface RecipeService {
	
	
    public RecipeVO getRecipeDetail(int recipeId)throws Exception;
    
  
    public RecipeVO getRecipeByProdId(int prodId) throws Exception;

}
