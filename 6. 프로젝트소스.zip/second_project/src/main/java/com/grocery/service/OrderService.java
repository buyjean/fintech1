package com.grocery.service;

import java.util.List;

import com.grocery.vo.MemberVO;
import com.grocery.vo.OrderVO;

public interface OrderService {
	
	public void order(OrderVO order) throws Exception;
	
	public List<OrderVO> getOrders(MemberVO member) throws Exception;
	
	public OrderVO getOrderWithDetails(String orderId) throws Exception;

}
