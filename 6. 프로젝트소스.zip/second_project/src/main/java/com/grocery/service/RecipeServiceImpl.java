package com.grocery.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grocery.mapper.RecipeMapper;
import com.grocery.vo.RecipeVO;

@Service
public class RecipeServiceImpl implements RecipeService {
	
	@Autowired
	private RecipeMapper recipeMapper;
	
	@Override
	public RecipeVO getRecipeDetail(int recipeId) throws Exception{
		return recipeMapper.getRecipeDetail(recipeId);
	}
	
	@Override
	public RecipeVO getRecipeByProdId(int prodId) throws Exception{
		return recipeMapper.getRecipeByProdId(prodId);
	}
}
