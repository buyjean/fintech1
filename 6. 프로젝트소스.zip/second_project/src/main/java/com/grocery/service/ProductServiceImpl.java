package com.grocery.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grocery.mapper.CategoryMapper;
import com.grocery.mapper.ProductMapper;
import com.grocery.vo.CategoryVO;
import com.grocery.vo.Criteria;
import com.grocery.vo.ProductVO;

@Service
public class ProductServiceImpl implements ProductService{
	
	@Autowired
	private ProductMapper productMapper;
	
	@Autowired
	private CategoryMapper categoryMapper;
	
	@Override
	public List<ProductVO> getList() throws Exception{
		return productMapper.getList();
	}
	
	@Override
	public List<ProductVO> getListAll() throws Exception{
		return productMapper.getListAll();
	}
	
	
	@Override
	public ProductVO getProduct(int prodId) throws Exception{
		return productMapper.getProduct(prodId);
	}
	
	@Override
	public List<ProductVO> getRecommendedProducts() throws Exception{
		return productMapper.getRecommendedProducts();
	}
	
	@Override
	public List<ProductVO> getListByCategory(int categoryId) throws Exception{
		return productMapper.getListByCategory(categoryId);
	}
	
	@Override
	public List<ProductVO> getMinListByRegDate() throws Exception{
		return productMapper.getMinListByRegDate();
	}
	
	@Override
	public List<ProductVO> getMinListByIsOutlet() throws Exception{
		return productMapper.getMinListByIsOutlet();
	}
	
	@Override
	public List<ProductVO> getByKeyword(String keyword) throws Exception{
		return productMapper.getByKeyword(keyword);
	}
	
	@Override
	public List<ProductVO> getRanListByCategory(ProductVO product) throws Exception{
		return productMapper.getRanListByCategory(product);
	}
	
	@Override
	public List<CategoryVO> getAllCategory() throws Exception{
		return categoryMapper.getCateList();
	}
	@Override
	public List<ProductVO> getSearchList(Criteria cri) throws Exception{
		return productMapper.getSearchList(cri);
	}
	
	public int getTotalCount(Criteria cri) throws Exception{
		return productMapper.getTotalCount(cri);
	}

}
