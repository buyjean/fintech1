package com.grocery.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.grocery.mapper.CartMapper;
import com.grocery.mapper.MemberMapper;
import com.grocery.mapper.OrderMapper;
import com.grocery.mapper.ProductMapper;
import com.grocery.vo.MemberVO;
import com.grocery.vo.OrderDetailVO;
import com.grocery.vo.OrderVO;
import com.grocery.vo.ProductVO;

@Service
public class OrderServiceImpl implements OrderService{
	
	@Autowired
	private OrderMapper orderMapper;
	
	@Autowired
	private MemberMapper memberMapper;
	
	@Autowired
	private ProductMapper productMapper;
	
	@Autowired
	private CartMapper cartMapper;
	
	@Transactional
	@Override
	public void order(OrderVO order) throws Exception{
		//주문 id 생성
		if(order.getOrderId() == null || order.getOrderId().isEmpty()) {
			SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
			String dateStr = format.format(new Date());
			//UUID로 중복확률을 극한으로 낮춤
			String uuid = UUID.randomUUID().toString().replace("-","").substring(0,8);
			
			String generatedId = "ORD" + dateStr + "_" + uuid;
			
			order.setOrderId(generatedId);
		}
		
		//orders테이블에 등록
		orderMapper.enrollOrder(order);
		
		//환경보호 기여도 계산
		int totalSavedWeight = 0;
		
		//상세등록,재고 반영, 중량계산
		for(OrderDetailVO detail : order.getDetails()) {
			detail.setOrderId(order.getOrderId());
			
			orderMapper.enrollOrderDetail(detail);
			
			ProductVO product = productMapper.getProduct(detail.getProdId());
			
			int result = orderMapper.deductStock(detail);
			if(result == 0) {
				throw new RuntimeException(product.getName()+"의 재고가 부족합니다");
			}
			
			//기한임박품 판정
			
			
			if("1".equals(product.getIsOutlet().trim())) {
				
				totalSavedWeight += product.getWeight() * detail.getQuantity();
			}
		}
		
		// 회원 정보갱신
		MemberVO updateMember = new MemberVO();
		updateMember.setUserId(order.getUserId());
		
		//포인트 반영
		int point = order.getEarnedPoint() - order.getUsedPoint();
		updateMember.setPoint(point);
		
		updateMember.setTotalPurchase(order.getTotalAmount());
		
		updateMember.setSavedWeight(totalSavedWeight);
		
		memberMapper.updateMemberStats(updateMember);
		
		//장바구니 초기화
		cartMapper.deleteCartAll(order.getUserId());
	}
	
	@Override
	public List<OrderVO> getOrders(MemberVO member) throws Exception{
		return orderMapper.getOrders(member);
	}
	
	@Override
	public OrderVO getOrderWithDetails(String orderId) throws Exception{
		OrderVO order = orderMapper.getOrder(orderId);
		
		if(order != null) {
			order.setDetails(orderMapper.getOrderDetails(orderId));
		}
		
		return order;
	}
	
	

}
