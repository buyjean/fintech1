package com.grocery.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grocery.mapper.MemberMapper;
import com.grocery.util.SHA256Util;
import com.grocery.vo.MemberRankVO;
import com.grocery.vo.MemberVO;

@Service
public class MemberServiceImpl implements MemberService{
	
	@Autowired
	private MemberMapper memberMapper;
	
	@Override
	public void memberRegister(MemberVO member) throws Exception{
		// salt 생성, 저장
		String salt = SHA256Util.generateSalt();
		member.setSalt(salt);
		
		//암호화(오리지널pw + salt)
		String password = member.getPassword();
		String encPassword = SHA256Util.getEncrypt(password, salt);
		member.setPassword(encPassword);
		
		memberMapper.register(member);
	}
	
	
	@Override
	public int idCheck(String userId) throws Exception{
		return memberMapper.idCheck(userId);
	}
	
	@Override
	public MemberVO getMember(MemberVO member) throws Exception{
		return memberMapper.login(member);
	}
	
	@Override
	public MemberVO memberLogin(MemberVO member) throws Exception{
		
		MemberVO getMember = memberMapper.login(member);
		// 비밀번호 체크
		if(getMember != null) {
			
			String salt = getMember.getSalt();
			
			String inputPw = member.getPassword();
			String encPw = SHA256Util.getEncrypt(inputPw, salt);
			
			if(encPw.equals(getMember.getPassword())) {
				
				getMember.setPassword(null);
				return getMember;
			}
		}
		return null;
	}
	
	@Override
	public void updateMemberStats(MemberVO member) throws Exception{
		memberMapper.updateMemberStats(member);
	}
	
	@Override
	public MemberRankVO selectRankByMember(MemberVO member) throws Exception{
		
		MemberRankVO rank = memberMapper.selectRankByMember(member);
		
		return rank;
	}
	
	@Override
	public boolean checkPassword(String userId, String inputPassword) throws Exception{
		MemberVO tempMember = new MemberVO();
		tempMember.setUserId(userId);
		MemberVO dbMember = memberMapper.login(tempMember);
		
		if(dbMember == null) {
			return false;
		}
		
		String encInputPw = SHA256Util.getEncrypt(inputPassword, dbMember.getSalt());
		
		return encInputPw.equals(dbMember.getPassword());
	}
	
	@Override
	public void editMember(MemberVO member) throws Exception{
		//비밀번호 입력이 있을 시, 새로운 salt 생성,암호화
		if(member.getPassword() != null && !member.getPassword().isEmpty()) {
			String newSalt = SHA256Util.generateSalt();
			member.setSalt(newSalt);
			
			String encPassword = SHA256Util.getEncrypt(member.getPassword(), newSalt);
			member.setPassword(encPassword);
		}
		// 비밀번호 입력이 없을 시엔 mapper의 if에서 걸러짐
		memberMapper.updateMember(member);
		
		
		
	}
	
}
