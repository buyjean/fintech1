package com.grocery.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grocery.mapper.ProductMapper;
import com.grocery.mapper.ReviewMapper;
import com.grocery.vo.ProductVO;
import com.grocery.vo.ReviewVO;

@Service
public class ReviewServiceImpl implements ReviewService{
	
	@Autowired
	private ReviewMapper reviewMapper;
	
	@Autowired
	private ProductMapper productMapper; 
	
	@Override
	public void register(ReviewVO review) throws Exception{
		reviewMapper.register(review);
	}
	
	@Override
	public List<ReviewVO> getListByProdId(int prodId) throws Exception{
		return reviewMapper.getListByProdId(prodId);
	}
	
	@Override
	public ReviewVO getReviewRating(int prodId) throws Exception{
		return reviewMapper.getReviewRating(prodId);
	}
	
	@Override
	public boolean canWriteReview(String userId, int currentProdId) throws Exception{
		ProductVO product = productMapper.getProduct(currentProdId);
		
		int masterId;
		
		if(product.getRefProdId() != 0) {
			masterId = product.getRefProdId();
		}else {
			masterId = currentProdId;
		}
		
		int count = reviewMapper.countReviewByFamily(userId, masterId);
		
		return count == 0;
	}

}
