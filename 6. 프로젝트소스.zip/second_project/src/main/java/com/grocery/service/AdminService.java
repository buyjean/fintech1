package com.grocery.service;

import java.util.List;
import java.util.Map;

import com.grocery.vo.EventVO;
import com.grocery.vo.ProductVO;

public interface AdminService {
	
	public Map<String, Object> getDashboardData(String startDate, String endDate)throws Exception;
	
	public Map<String, Object> getOrderList(String status, int page) throws Exception;
	
	public void updateOrderStatus(String orderId, String status) throws Exception;
	
	public void updateRecommendStatus(List<String> checkedIds) throws Exception;
	
	public int migrateToOutlet() throws Exception;
	
	public int updateExpired() throws Exception;
	
	public int updateProduct(ProductVO vo) throws Exception;
	
	public int migrateOneProduct(int prodId) throws Exception;
	
	public int toggleStatus(int prodId) throws Exception;
	
	public int deleteProduct(int prodId) throws Exception;
	
	public int insertProduct(ProductVO vo) throws Exception;
	
	public List<EventVO> getEventList() throws Exception;
	
	public int insertEvent(EventVO vo) throws Exception;
	
	public int updateEvent(EventVO vo) throws Exception;
	
	public int deleteEvent(int eventId) throws Exception;
}
