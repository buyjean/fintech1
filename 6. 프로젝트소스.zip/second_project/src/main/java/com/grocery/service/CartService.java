package com.grocery.service;

import java.util.List;

import com.grocery.vo.CartVO;

public interface CartService {
	
	public int addCart(CartVO cart) throws Exception;
	
	public List<CartVO> getCartList(String userId) throws Exception;
	
	public int modifyQuantity(CartVO cart) throws Exception;
	
	public int deleteCart(int cartId) throws Exception;
	
	public void deleteCartBatch(List<Integer> cartIds) throws Exception;
	
	public CartVO checkCart(CartVO cart) throws Exception;
	
	public int deleteCartAll(String userId) throws Exception;
	

}
