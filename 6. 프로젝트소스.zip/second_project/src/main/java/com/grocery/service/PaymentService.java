package com.grocery.service;

import java.io.IOException;

public interface PaymentService {
	
	// 포트원 API토큰 취득
	String getAccessToken() throws IOException;
	
	// 결제ID(imp_uid)를 통해 결제 내용 검증
	boolean verifyPayment(String impUid, String merchantUid, int amountToBePaid) throws IOException;

}
