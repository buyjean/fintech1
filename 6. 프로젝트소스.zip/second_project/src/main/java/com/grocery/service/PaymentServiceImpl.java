package com.grocery.service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

@Service
public class PaymentServiceImpl implements PaymentService{
	
	private final String API_KEY = "4318837707000062";
	private final String API_SECRET = "FUWeY4uGAcEVvQxx3Gr25WzkuDWf6sm27l9VkBESNZJkDb7sLoobQs2HlzGcoE8upAtb7raLb8ztNAgD";
	
	@Override
	public String getAccessToken() throws IOException{
		URL url = new URL("https://api.iamport.kr/users/getToken");
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		
		conn.setRequestMethod("POST");
		conn.setRequestProperty("Content-Type", "application/json");
		conn.setDoOutput(true);
		
		JsonObject json = new JsonObject();
		json.addProperty("imp_key", API_KEY);
		json.addProperty("imp_secret", API_SECRET);
		
		try(BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(conn.getOutputStream()))){
			bw.write(json.toString());
			bw.flush();
		}
		
		try(BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()))){
			Gson gson = new Gson();
			JsonObject response = gson.fromJson(br, JsonObject.class);
			return response.get("response").getAsJsonObject().get("access_token").getAsString();
		}
	}
	
	@Override
	public boolean verifyPayment(String impUid, String merchantUid, int amountToBePaid) throws IOException{
		String token = getAccessToken();
		
		URL url = new URL("https://api.iamport.kr/payments/" + impUid + "?include_sandbox=true");
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setRequestMethod("GET");
		conn.setRequestProperty("Authorization", token);
		
		try(BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()))){
			Gson gson = new Gson();
			JsonObject response = gson.fromJson(br, JsonObject.class);
			
			JsonObject paymentData = response.get("response").getAsJsonObject();
			
			int paidAmount = paymentData.get("amount").getAsInt();
			String status = paymentData.get("status").getAsString();
			
			// 금액의 일치여부, 지불 여부 확인
			return(amountToBePaid == paidAmount && "paid".equals(status));
		}
	}

}
