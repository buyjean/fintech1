package com.grocery.service;

import java.util.List;

import com.grocery.vo.ReviewVO;

public interface ReviewService {
	
	public void register(ReviewVO review) throws Exception;
	
	public List<ReviewVO> getListByProdId(int prodId) throws Exception;
	
	public ReviewVO getReviewRating(int prodId) throws Exception;
	
	public boolean canWriteReview(String userId, int currentProdId) throws Exception;

}
