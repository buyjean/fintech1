package com.grocery.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.grocery.mapper.AdminMapper;
import com.grocery.vo.EventVO;
import com.grocery.vo.ProductVO;

@Service
public class AdminServiceImpl implements AdminService {
	
	private static final Logger log = LoggerFactory.getLogger(AdminService.class);
	
	@Autowired
	private AdminMapper adminMapper;
	
	@Override
	public Map<String, Object> getDashboardData(String startDate, String endDate)throws Exception{
		
		Map<String, Object> response = new HashMap<>();
		
		List<Map<String,Object>> categoryList = adminMapper.getCategorySales(startDate, endDate);
		List<Map<String,Object>>rankingList = adminMapper.getProductRanking(startDate, endDate);
		Map<String,Object> todaySummary = adminMapper.getTodaySummary();
		
		//매출0이여도 표시하기위한 처리
		List<Map<String,Object>> dailyListRaw = adminMapper.getDailySales(startDate, endDate);
		
		List<String> dailyLabels = new ArrayList<>();
		List<Long> dailyValues = new ArrayList<>();
		
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Date start = (startDate == null || startDate.isEmpty()) ? 
				new Date(System.currentTimeMillis() -7L * 24 * 3600 * 1000) :sdf.parse(startDate);
			
			Date end = (endDate == null || endDate.isEmpty()) ? new Date() : sdf.parse(endDate);
			
			Calendar cal = Calendar.getInstance();
			cal.setTime(start);
			
			while(!cal.getTime().after(end)) {
				String currentDateStr = sdf.format(cal.getTime());
				dailyLabels.add(currentDateStr);
				
				long sales = 0;
				for(Map<String,Object> row : dailyListRaw) {
					if(String.valueOf(row.get("date")).equals(currentDateStr)){
						sales = Long.parseLong(String.valueOf(row.get("total")));
						break;
					}
				}
				dailyValues.add(sales);
				
				cal.add(Calendar.DATE, 1);//1일 경과처리
			}
		}catch(Exception e) {
			log.error("대시보드 일자계산중 에러발생");
			dailyLabels.clear();
			dailyValues.clear();
		}
		
		response.put("dailyLabels", dailyLabels);
		response.put("dailyValues", dailyValues);
		
		List<String> pieLabels = new ArrayList<>();
		List<Long> pieValues = new ArrayList<>();
		for(Map<String,Object> row:categoryList) {
			pieLabels.add((String)row.get("category"));
			pieValues.add(Long.parseLong(String.valueOf(row.get("total"))));
		}
		
		response.put("pieLabels", pieLabels);
		response.put("pieValues", pieValues);
		
		response.put("rankingList", rankingList);
		
		for(int i=0; i<rankingList.size(); i++) {
			rankingList.get(i).put("rank", i+1);
		}
		
		if(todaySummary != null) {
			response.put("todaySales", todaySummary.get("todaySales"));
			response.put("todayOrderCount", todaySummary.get("todayOrderCount"));
		}else {
			response.put("todaySales", 0);
			response.put("todayOrderCount", 0);
		}
		
		return response;
	}
	
	@Override
	public Map<String, Object> getOrderList(String status, int page)throws Exception{
		int limit = 10;
		int totalCount = adminMapper.getOrderCount(status);
		
		int totalPages = (int) Math.ceil((double)totalCount/limit);
		
		if(page < 1) page =1;
		if(page > totalPages && totalPages > 0)page = totalPages;
		//SQL에 넘겨줄 범위 계산
		int startRow = (page -1) * limit;
		int endRow = startRow + limit;
		
		List<Map<String, Object>> list = adminMapper.getOrderList(status, startRow, endRow);
		
		Map<String,Object> result = new HashMap<>();
		result.put("list", list);
		result.put("currentPage", page);
		result.put("totalPages", totalPages);
		result.put("status", status);
		
		int navSize= 3;
		int startPage = ((page-1)/navSize) * navSize + 1;
		int endPage = Math.min(startPage+ navSize -1, totalPages);
		
		result.put("startPage", startPage);
		result.put("endPage", endPage);
		result.put("hasPrev", startPage>1);
		result.put("hasNext", endPage < totalPages);
		
		return result;
				
	}
	
	@Override
	public void updateOrderStatus(String orderId,String status)throws Exception{
		adminMapper.updateOrderStatus(orderId, status);
	}
	
	@Override
	public void updateRecommendStatus(List<String> checkedIds)throws Exception{
		if (checkedIds == null || checkedIds.isEmpty()) return;

        
        for (String idStr : checkedIds) {
            int prodId = Integer.parseInt(idStr);
            
          
            adminMapper.updateRecommendStatus(prodId);
        }
	}
	
	@Override
	@Transactional
	public int migrateToOutlet() throws Exception{
		int migratedCount = adminMapper.migrateToOutlet();
		if(migratedCount > 0) {
			adminMapper.clearOriginalStock();
		}
		return migratedCount;
	}
	
	@Override
	public int updateExpired() throws Exception{
		return adminMapper.updateExpiredProducts();
	}
	
	@Override
	public int updateProduct(ProductVO vo) throws Exception {
		return adminMapper.updateProduct(vo);
	}
	
	@Override
	@Transactional
	public int migrateOneProduct(int prodId) throws Exception {
		int count = adminMapper.migrateOneToOutlet(prodId);
		
		if(count > 0) {
			adminMapper.clearOneOriginalStock(prodId);
		}return count;
	}
	
	@Override
	public int toggleStatus(int prodId) throws Exception {
		return adminMapper.toggleStatus(prodId);
	}
	
	@Override
	public int deleteProduct(int prodId) throws Exception {
		return adminMapper.deleteProduct(prodId);
	}
	
	@Override
	public int insertProduct(ProductVO vo) throws Exception {
		return adminMapper.insertProduct(vo);
	}
	
	@Override
	public List<EventVO> getEventList() throws Exception{
		return adminMapper.getEventList();
	}
	
	@Override
	public int insertEvent(EventVO vo) throws Exception{
		return adminMapper.insertEvent(vo);
	}
	
	@Override
	public int updateEvent(EventVO vo) throws Exception{
		return adminMapper.updateEvent(vo);
	}
	
	@Override
	public int deleteEvent(int eventId) throws Exception{
		return adminMapper.deleteEvent(eventId);
	}
	
	

}
