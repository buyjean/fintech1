package com.grocery.service;

import java.util.List;

import com.grocery.vo.CategoryVO;
import com.grocery.vo.Criteria;
import com.grocery.vo.ProductVO;

public interface ProductService {
	
	//상품목록
	public List<ProductVO> getList() throws Exception;
	
	public List<ProductVO> getListAll() throws Exception;
		
	//상품상세정보
	public ProductVO getProduct(int prodId) throws Exception;
	
	public List<ProductVO> getRecommendedProducts() throws Exception;
	
	//품류 별 목록
	public List<ProductVO> getListByCategory(int categoryId) throws Exception;
	
	public List<ProductVO> getMinListByRegDate() throws Exception;
	
	public List<ProductVO> getMinListByIsOutlet() throws Exception;
	
	public List<ProductVO> getByKeyword(String keyword) throws Exception;
	
	public List<ProductVO> getRanListByCategory(ProductVO product) throws Exception;
	
	public List<CategoryVO> getAllCategory() throws Exception;
	
	public List<ProductVO> getSearchList(Criteria cri) throws Exception;
	
	public int getTotalCount(Criteria cri) throws Exception;
}
