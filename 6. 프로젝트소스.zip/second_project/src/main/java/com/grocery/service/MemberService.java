package com.grocery.service;

import com.grocery.vo.MemberRankVO;
import com.grocery.vo.MemberVO;

public interface MemberService {
	
	//회원가입(암호화포함)
	public void memberRegister(MemberVO member) throws Exception;
	
	//id중복체크
	public int idCheck(String userId) throws Exception;
	
	public MemberVO getMember(MemberVO member) throws Exception;
	
	//로그인(암호화된 pw와 대조 포함)
	public MemberVO memberLogin(MemberVO member) throws Exception;
	
	public void updateMemberStats(MemberVO member) throws Exception;
	
	
	public MemberRankVO selectRankByMember(MemberVO member) throws Exception;
	
	public boolean checkPassword(String userId, String inputPassword) throws Exception;
	
	public void editMember(MemberVO member) throws Exception;
	
}
