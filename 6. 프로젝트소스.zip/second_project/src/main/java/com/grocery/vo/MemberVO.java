package com.grocery.vo;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;

@Data // Lombok
public class MemberVO {
	
	// DBカラムと一致
    private String userId;
    private String password;
    private String salt;          // セキュリティ用
    private String name;
    private String email;
    private String phone;
    private String zipcode;       // 郵便番号
    private String addrMain;      // 住所1(都道府県・市)
    private String addrDetail;    // 住所2(番地・建物)
    private int point;
    private int totalPurchase;
    private int savedWeight;      // エコ貢献度
    private String memberStatus;  // 1:有効, 0:退会, 9:停止
    private int role;             // 0:一般, 1:管理者
    private Date regDate;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date birthDate;
       
    
	
}
