package com.grocery.vo;

import java.util.Date;
import java.util.List;

import lombok.Data;

@Data
public class RecipeVO {
	// --- DB Columns ---
    private int recipeId;
    private String title;
    private String content;
    private String image;
    private Date regDate;

    // --- Relationship ---
    private List<ProductVO> linkedProducts; // Ingredients

  

}
