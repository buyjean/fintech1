package com.grocery.vo;

import lombok.Data;

@Data
public class CartVO {
	// --- DB Columns ---
    private int cartId;
    private String userId;
    private int prodId;
    private int quantity;

    // --- Join Fields (For Display) ---
    private String prodName;
    private int prodPrice;
    private String prodImage;
    private int stockQuantity;
    
    private int categoryId;
    private int salePrice;
    private int discountRate;
    private String eventTitle;


}
