package com.grocery.vo;

import lombok.Data;

@Data
public class OrderDetailVO {
	// --- DB Columns ---
    private int detailId;
    private String orderId;
    private int prodId;
    private String prodName;      // Snapshot Name
    private int price;            // Snapshot Price
    private int quantity;

    // --- Logic Fields ---
    private String prodImage;     // For history display

}
