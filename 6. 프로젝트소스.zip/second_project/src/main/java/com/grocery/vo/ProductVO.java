package com.grocery.vo;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;

@Data
public class ProductVO {
	// --- DB Columns ---
    private int prodId;
    private String name;
    private int categoryId;
    private int price;            // Current Selling Price
    private int originalPrice;    // MSRP (for discount calc)
    private int stockQuantity;
    private String image;
    private String description;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date expDate;
    private String isOutlet;      // '0' or '1'
    private String isRecommended; // '0' or '1'
    private String prodStatus;    // '1':On Sale, '0':Stop
    private int weight;           // Eco Weight (g)
    private double kcal;
    private double protein;
    private double fat;
    private double carb;
    private int version;          // Optimistic Lock
    private Date regDate;
    private int refProdId;

    // --- Logic Fields (Non-DB) ---
    private boolean isSale;       // Is currently on sale?
    private int salePrice;        // Calculated discounted price
    private int discountRate;     // Display (e.g., 20)
    private String categoryName;  // For Join Display
    
  
    

}
