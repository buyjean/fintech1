package com.grocery.vo;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;

@Data
public class EventVO {
	// --- DB Columns ---
    private int eventId;
    private String title;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date startDate;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date endDate;
    private int targetCat;
    private int discountRate;
    private String isRecurring;   // '1': Weekly, '0': One-time

    // --- Logic Fields ---
    private String targetCatName; // For display


}
