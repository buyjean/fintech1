package com.grocery.vo;

import java.util.List;

import lombok.Data;

@Data
public class CategoryVO {
	
	// --- DB Columns ---
    private int categoryId;
    private String categoryName;
    private Integer parentId;     // Nullable -> Integer
    private int sortOrder;

    // --- Relationship ---
    private List<CategoryVO> children; // Sub-categories



}
