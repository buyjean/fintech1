package com.grocery.vo;

import java.util.Date;

import org.springframework.web.multipart.MultipartFile;

import lombok.Data;

@Data
public class ReviewVO {
	// --- DB Columns ---
    private int reviewId;
    private int prodId;
    private String userId;
    private String orderId;       // Verified Purchase
    private double rating;
    private String content;
    private String reviewImage;
    private Date regDate;
    
    //총 건수 저장
    private int revNum;
    
    //　파일 수신용
    private MultipartFile uploadFile;

}
