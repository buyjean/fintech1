package com.grocery.vo;

import java.util.Date;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;

@Data
public class OrderVO {
	// --- DB Columns ---
    private String orderId;       // "ORD_2026..."
    private String userId;
    private int totalAmount;
    private int usedPoint;
    private int earnedPoint;
    private int finalSavedWeight; // Snapshot
    private String orderStatus;   // 'ORDERED', 'PAID'...
    private String impUid;        // Payment Gateway ID
    
    // Delivery Info
    private String addrName;
    private String zipcode;       // Added in v11.7
    private String addrMain;
    private String addrDetail;
    private String tel;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date deliveryReqDate;
    private String deliveryTime;  // Added in v11.7
    private Date orderDate;

    // --- Relationship ---
    private List<OrderDetailVO> details; // To hold order items
    
    private String repImage;


}
