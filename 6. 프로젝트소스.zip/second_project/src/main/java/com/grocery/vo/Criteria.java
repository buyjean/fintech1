package com.grocery.vo;

import lombok.Data;

@Data
public class Criteria {
    private int pageNum;
    private int amount;
    
    // 検索フィルタ用
    private String type;
    private String keyword;
    private String sort;      // new, sale, outlet, best など
    private Integer categoryId; // null許容のためInteger

    public Criteria() {
        this(1, 9); // デフォルト 1ページ目、9件表示
    }

    public Criteria(int pageNum, int amount) {
        this.pageNum = pageNum;
        this.amount = amount;
    }
}