package com.grocery.vo;

import lombok.Data;

@Data
public class MemberRankVO {
	// --- DB Columns ---
    private int rankId;
    private String rankName;
    private int threshold;
    private double pointRate;
    


}
