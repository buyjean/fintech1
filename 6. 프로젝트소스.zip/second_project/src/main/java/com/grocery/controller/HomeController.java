package com.grocery.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.grocery.service.CartService;
import com.grocery.service.ProductService;
import com.grocery.vo.CartVO;
import com.grocery.vo.CategoryVO;
import com.grocery.vo.MemberVO;
import com.grocery.vo.ProductVO;

@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	@Autowired
	private ProductService productService;
	
	@Autowired
	private CartService cartService;
	
	
	
	@GetMapping("/")
	public String home(Model model,HttpServletRequest request) throws Exception{
		
		logger.info("메인페이지로 이동");
		
		List<ProductVO> list1 = productService.getMinListByRegDate();
		
		List<ProductVO> list2 = productService.getMinListByIsOutlet();
		
		model.addAttribute("productList_new",list1);
		
		model.addAttribute("productList_dis",list2);
		
		List<CategoryVO> categoryList = productService.getAllCategory();
		
		model.addAttribute("categoryList",categoryList);
		
		HttpSession session = request.getSession();
		MemberVO member = (MemberVO)session.getAttribute("member");
		
		
		
		if(member!= null) {
			String userId = member.getUserId();
			List<CartVO> cartList = cartService.getCartList(userId);
			model.addAttribute("cartList",cartList);
		}
		
		return "main";
	}

}
