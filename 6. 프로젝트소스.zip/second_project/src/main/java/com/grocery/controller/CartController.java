package com.grocery.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.grocery.service.CartService;
import com.grocery.service.ProductService;
import com.grocery.vo.CartVO;
import com.grocery.vo.CategoryVO;
import com.grocery.vo.MemberVO;

@Controller
@RequestMapping("/cart")
public class CartController {
	
	private static final Logger logger = LoggerFactory.getLogger(CartController.class);
	
	@Autowired
	private CartService cartService;
	
	@Autowired
	private ProductService productService;
	
	//장바구니 추가
	@PostMapping("/add")
	@ResponseBody//비동기처리
	public ResponseEntity<String> addCartPOST(CartVO cart,HttpServletRequest request) throws Exception{
		
		//로그인상태 확인
		HttpSession session = request.getSession();
		MemberVO member = (MemberVO) session.getAttribute("member");
		
		if(member == null) {
			return new ResponseEntity<String>("5",HttpStatus.UNAUTHORIZED); // 로그인 안되어있는 상테(로그인화면으로 전송시키는 용도)
		}
		
		//장바구니에 담을시에는 유저id 설정후에 -> 다른유저의 장바구니와의 충돌 방지
			cart.setUserId(member.getUserId());
			int result = cartService.addCart(cart);
			// 성공시에는 200 OK
			return new ResponseEntity<String>(result + "", HttpStatus.OK);	
			
	}
	
	@PostMapping("/addMultiple")
    @ResponseBody
    public String addMultipleToCart(@RequestBody List<Map<String, Object>> items, HttpSession session) {
        MemberVO member = (MemberVO) session.getAttribute("member");
        if (member == null) {
            return "login_required";
        }

        try {
            for (Map<String, Object> item : items) {
                int prodId = Integer.parseInt(String.valueOf(item.get("prodId")));
                int quantity = Integer.parseInt(String.valueOf(item.get("quantity")));

                CartVO cart = new CartVO();
                cart.setUserId(member.getUserId());
                cart.setProdId(prodId);
                cart.setQuantity(quantity);

                
                cartService.addCart(cart); 
            }
            return "success";
        } catch (Exception e) {
            e.printStackTrace();
            return "fail";
        }
    }
	
	// 장바구니 내역
	
	@GetMapping("/view")
	public String cartPageGET(Model model,HttpServletRequest request) throws Exception{
		
		// URL의 ID와 로그인중인ID가 일치하는지 확인
		HttpSession session = request.getSession();
		MemberVO member = (MemberVO) session.getAttribute("member");
		
		//미로그인 혹은 다른유저의 장바구니를 보려고 할 경우
		if(member==null) {
			return "redirect:/member/login";
		}
		
		String userId = member.getUserId();
		logger.info("장바구니 목록"+ userId);
		
		List<CategoryVO> categoryList = productService.getAllCategory();
		
		model.addAttribute("categoryList",categoryList);
		
		model.addAttribute("recommendList",productService.getRecommendedProducts());
		
		model.addAttribute("cartList",cartService.getCartList(userId));
		
		
		return "/cart/cart";
	}
	
	@GetMapping("/list")
	@ResponseBody
	public List<CartVO> getCartList(HttpServletRequest request) throws Exception{
		
		HttpSession session = request.getSession();
		MemberVO member = (MemberVO) session.getAttribute("member");
		
		if(member != null) {
			return cartService.getCartList(member.getUserId());
		}
		
		return new ArrayList<CartVO>();
	}
	
	// 수량조정
	
	@PostMapping("/update")
	@ResponseBody
	public String updateCartPOST(CartVO cart) throws Exception{
		
		logger.info("수량조정: "+ cart.getCartId()+ ", 수량: " + cart.getQuantity());
		

		
		return cartService.modifyQuantity(cart) > 0 ? "OK" : "FAIL";
	}
	
	//삭제
	@PostMapping("/delete")
	@ResponseBody
	public String deleteCartPOST(int cartId) throws Exception{
		
		cartService.deleteCart(cartId);
		

		
		return "success";
	}
	
	@PostMapping("/delete/batch")
	@ResponseBody
	public String deleteCartBatchPOST(@RequestParam(value = "cartIds[]") List<Integer> cartIds) throws Exception{
		
		if(cartIds != null && !cartIds.isEmpty()) {
			cartService.deleteCartBatch(cartIds);
		}
		
		return "success";
	}
	
	

}
