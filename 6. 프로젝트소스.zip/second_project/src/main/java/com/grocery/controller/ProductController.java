package com.grocery.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.grocery.service.CartService;
import com.grocery.service.ProductService;
import com.grocery.service.RecipeService;
import com.grocery.service.ReviewService;
import com.grocery.vo.CartVO;
import com.grocery.vo.CategoryVO;
import com.grocery.vo.Criteria;
import com.grocery.vo.MemberVO;
import com.grocery.vo.PageDTO;
import com.grocery.vo.ProductVO;
import com.grocery.vo.RecipeVO;
import com.grocery.vo.ReviewVO;

@Controller
@RequestMapping("/product")
public class ProductController {
	
	private static final Logger logger = LoggerFactory.getLogger(ProductController.class);
	
	@Autowired
	private ProductService productService;
	
	@Autowired
	private CartService cartService;
	
	@Autowired
	private ReviewService reviewService;
	
	@Autowired
	private RecipeService recipeService;
	
	//상품상세
	@GetMapping("/detail")
	public String getDetail(@RequestParam("prodId") int prodId,Model model,HttpServletRequest request) throws Exception{
		logger.info("상품상세표시 ID="+ prodId);
		
		HttpSession session = request.getSession();
		MemberVO member = (MemberVO) session.getAttribute("member");
		
		if(member != null) {
			List<CartVO> cartList = cartService.getCartList(member.getUserId());
			model.addAttribute("cartList",cartList);
		}
		
		// DB에서 상품정보 
		ProductVO product = productService.getProduct(prodId);
		
		
		model.addAttribute("product",product);
		
		List<ReviewVO> reviews = reviewService.getListByProdId(prodId);
		model.addAttribute("reviewList", reviews);
		
		RecipeVO relatedRecipe = recipeService.getRecipeByProdId(prodId);
		
		if(relatedRecipe != null) {
			model.addAttribute("relateRecipe",relatedRecipe);
		}
		
		ReviewVO reviewStats = reviewService.getReviewRating(prodId);
		if(reviewStats == null) {
			reviewStats = new ReviewVO();
			reviewStats.setRating(0);
			reviewStats.setRevNum(0);
		}
		model.addAttribute("reviewStats",reviewStats);
		
		List<CategoryVO> categoryList = productService.getAllCategory();
		
		model.addAttribute("categoryList",categoryList);

		List<ProductVO> relatedList = productService.getRanListByCategory(product);
		model.addAttribute("relatedList",relatedList);
		
		//jsp로 전달
		return "/product/detail";
			
	}
		

    @GetMapping("/search")
    public String searchProducts(Criteria cri, Model model,HttpServletRequest request) throws Exception{
        logger.info("統合検索処理: " + cri);
        
        List<ProductVO> list = productService.getSearchList(cri); 
        
        int total = productService.getTotalCount(cri); 
		List<CategoryVO> categoryList = productService.getAllCategory();
		
		HttpSession session = request.getSession();
		MemberVO member = (MemberVO) session.getAttribute("member");
		
		List<CartVO>cartList = cartService.getCartList(member.getUserId());
		model.addAttribute("cartList",cartList);
		
		model.addAttribute("categoryList",categoryList);
        
        model.addAttribute("resultList", list);
        model.addAttribute("pageMaker", new PageDTO(cri, total));
        
        return "product/search"; // JSPへ
    }
	


}
