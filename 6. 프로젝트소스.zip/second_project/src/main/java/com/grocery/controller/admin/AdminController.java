package com.grocery.controller.admin;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.grocery.service.AdminService;
import com.grocery.service.OrderService;
import com.grocery.service.ProductService;
import com.grocery.vo.CategoryVO;
import com.grocery.vo.EventVO;
import com.grocery.vo.ProductVO;

@Controller
@RequestMapping("/admin")
public class AdminController {

	private static final Logger logger = LoggerFactory.getLogger(AdminController.class);

	@Autowired
	private ProductService productService;

	@Autowired
	private OrderService orderService;	

	@Autowired
	private AdminService adminService;

	// 관리자 대시보드
	@GetMapping("/dashboard")
	public String adminMain(HttpSession session) {
		logger.info("admin페이지 이동");
		return "admin/dashboard";
	}

	@GetMapping("/tab/chart")
	public String tabChart() {
		return "admin/tab/chart";
	}

	// 탭: 차트
	@GetMapping("tab/chart/data")
	@ResponseBody
	public Map<String, Object> getChartData(@RequestParam(required = false) String startDate,
			@RequestParam(required = false) String endDate) throws Exception {
		if (startDate == null || startDate.isEmpty()) {

		}

		return adminService.getDashboardData(startDate, endDate);

	}

	@GetMapping("/download/csv")
	public ResponseEntity<byte[]> downloadCSV(@RequestParam(required = false) String startDate,
			@RequestParam(required = false) String endDate) throws Exception {

		Map<String, Object> data = adminService.getDashboardData(startDate, endDate);
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> ranking = (List<Map<String, Object>>) data.get("rankingList");
		// CSV생성
		StringBuilder csv = new StringBuilder();
		csv.append("순위,상품명,매출액\n");

		if (ranking != null) {
			for (Map<String, Object> item : ranking) {
				csv.append(item.get("rank")).append(",");
				csv.append("\"").append(item.get("name")).append("\",");
				csv.append(item.get("total")).append("\n");
			}
		}
		byte[] csvBytes = csv.toString().getBytes(StandardCharsets.UTF_8);
		byte[] resultBytes = new byte[3 + csvBytes.length];

		// BOM(글자깨짐 방지)
		resultBytes[0] = (byte) 0xEF;
		resultBytes[1] = (byte) 0xBB;
		resultBytes[2] = (byte) 0xBF;
		System.arraycopy(csvBytes, 0, resultBytes = resultBytes, 3, csvBytes.length);

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(new MediaType("text", "csv", StandardCharsets.UTF_8));
		headers.setContentDispositionFormData("attachment", "sales_report.csv");

		return new ResponseEntity<>(resultBytes, headers, HttpStatus.OK);

	}
	
	@GetMapping("/tab/product")
	public String tabProduct(Model model) throws Exception{
		List<ProductVO> productList = productService.getListAll();
		model.addAttribute("productList",productList);
		
		return "admin/tab/product";
	}
	
	@PostMapping("/product/update")
	@ResponseBody
	public String updateProduct(ProductVO vo)throws Exception {
		try {
			return adminService.updateProduct(vo) > 0 ? "OK" : "FAIL";
		}catch(Exception e) {
			return "FAIL";
		}
	}
	
	@PostMapping("/product/migrateOne")
	@ResponseBody
	public String migrateOneProduct(@RequestParam("prodId") int prodId)throws Exception {
		try {
			return adminService.migrateOneProduct(prodId) > 0 ? "OK" : "FAIL";
		}catch(Exception e) {
			return "FAIL";
		}
	}
	
	@PostMapping("/product/toggle")
	@ResponseBody
	public String toggleStatus(@RequestParam("prodId")int prodId)throws Exception{
		try {
			return adminService.toggleStatus(prodId) > 0 ? "OK" : "FAIL";
		}catch(Exception e) {
			return "FAIL";
		}
	}
	
	@PostMapping("/product/delete")
	@ResponseBody
	public String deleteProduct(@RequestParam("productId")int prodId) throws Exception{
		try {
			return adminService.deleteProduct(prodId) > 0 ? "OK" : "FAIL";	
		}catch(Exception e) {
			return "FAIL";
		}
	}
	
	@GetMapping("/tab/product/register")
	public String registerProduct(Model model) throws Exception{
		List<CategoryVO>cateList = productService.getAllCategory();
		
		model.addAttribute("categoryList",cateList);
		return "admin/tab/register";
	}
	
	@PostMapping(value = "/product/insert", produces = "text/plain;charset=UTF-8")
    @ResponseBody
    public String insertProduct(ProductVO vo, 
                                @RequestParam(value="uploadFile", required=false) MultipartFile uploadFile) {
        try {
           
            vo.setPrice(vo.getOriginalPrice());
            
            
            if (uploadFile != null && !uploadFile.isEmpty()) {
                String uploadFolder = "C:\\grocery_upload\\products"; // servlet-context.xmlの設定と一致させる
                
                
                File uploadPath = new File(uploadFolder);
                if (!uploadPath.exists()) {
                    uploadPath.mkdirs();
                }

                
                String uploadFileName = uploadFile.getOriginalFilename();
                String uuid = UUID.randomUUID().toString();
                uploadFileName = uuid + "_" + uploadFileName;

                
                File saveFile = new File(uploadPath, uploadFileName);
                uploadFile.transferTo(saveFile);

               
                vo.setImage(uploadFileName);
            } 

            return adminService.insertProduct(vo) > 0 ? "OK" : "FAIL";
            
        } catch (Exception e) {
            return "Error: " + e.getMessage();
        }
    }
	

	@GetMapping("/tab/order")
	public String tabOrderlist(@RequestParam(name = "status", required = false, defaultValue = "") String status,
			@RequestParam(name = "page", required = false, defaultValue = "1") int page, Model model) throws Exception {

		try {
			Map<String, Object> result = adminService.getOrderList(status, page);

			model.addAttribute("orderList", result.get("list"));
			model.addAttribute("pageInfo", result);
			model.addAttribute("currentStatus", status);
		} catch (Exception e) {
			logger.error("주문상태 갱신중 에러발생");
			throw e;
		}

		return "admin/tab/orderlist";
	}

	@PostMapping("/tab/order/updateStatus")
	@ResponseBody
	public String updateOrderStatus(@RequestParam("orderId") String orderId, @RequestParam("status") String status) {

		try {
			adminService.updateOrderStatus(orderId, status);
			return "OK";
		} catch (Exception e) {
			return "FAIL";
		}
	}
	
	@GetMapping("/modal/shipping")
    public String getShippingModal() {

        return "member/tab/shipping";
    }

	// 추천상품 목록 표시

	@GetMapping("/tab/recommend")
	public String tabRecommend(HttpSession session, Model model) throws Exception {

		List<ProductVO> productList = productService.getList();
		model.addAttribute("productListAll", productList);
		return "admin/tab/recommend";
	}

	// 추천상품 변경
	@PostMapping("/recommend/save")
	@ResponseBody
	public String recommendSave(@RequestBody Map<String, List<String>> req)
			throws Exception {
		try {
			List<String> checkedIds = req.get("checkedIds");
			adminService.updateRecommendStatus(checkedIds);
			return "OK";
		}catch(Exception e) {
			return "FAIL";
		}	

	}
	
	@GetMapping("/tab/expire")
	public String tabExpire(HttpSession session, Model model) throws Exception {

		List<ProductVO> productList = productService.getList();
		model.addAttribute("productList", productList);
		return "admin/tab/expire";
	}
	  
	  //db에 할인율 적용 + 유통기한 확인
	  
	  @PostMapping("/tab/expire/migrate")
	  @ResponseBody 
	  public String migrateOuletAjax()
	  throws Exception {
		  try {
			  int count = adminService.migrateToOutlet();
			  return "OK:" + count;
		  } catch(Exception e) {
			  return "FAIL";
		  }
	  }
	  
	  @PostMapping("/tab/expire/stop")
	  @ResponseBody
	  public String updateExpiredAjax() {
		  try {
			  int count = adminService.updateExpired();
			  return "OK" + count;
		  }catch(Exception e) {
			  return "FAIL";
		  }
	  }
	  
	  @GetMapping("/tab/event")
	  public String tabEvent(Model model) throws Exception{
		  
		  List<EventVO>eventList = adminService.getEventList();
		  model.addAttribute("eventList",eventList);
		  
		  List<CategoryVO> categoryList = productService.getAllCategory();
		  model.addAttribute("categoryList",categoryList);
		  return "admin/tab/event";
	  }
	  
	  @PostMapping("/event/insert")
	  @ResponseBody
	  public String insertEvent(EventVO vo) {
		  try {
			  return adminService.insertEvent(vo) > 0 ? "OK" : "FAIL";
		  }catch(Exception e) {
			  return "Error";
		  }
	  }
	  
	  @PostMapping("/event/update")
	  @ResponseBody
	  public String updateEvent(EventVO vo) {
		  try {
			  return adminService.updateEvent(vo)> 0 ? "OK" : "FAIL";
		  }catch(Exception e) {
			  return "Error";
		  }
	  }
	  
	  @PostMapping("/event/delete")
	  @ResponseBody
	  public String deleteEvent(@RequestParam("eventId")int eventId) {
		  try {
			  return adminService.deleteEvent(eventId) > 0 ? "OK" : "FAIL";
		  }catch(Exception e) {
			  return "FAIL";
		  }
	  }
	

}
