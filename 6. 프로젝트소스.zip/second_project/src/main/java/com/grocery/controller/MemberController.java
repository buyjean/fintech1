package com.grocery.controller;

import java.io.File;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.grocery.service.MemberService;
import com.grocery.service.OrderService;
import com.grocery.service.ProductService;
import com.grocery.service.ReviewService;
import com.grocery.vo.MemberRankVO;
import com.grocery.vo.MemberVO;
import com.grocery.vo.OrderVO;
import com.grocery.vo.ReviewVO;

@Controller
@RequestMapping("/member")
public class MemberController {
	
	private static final Logger logger = LoggerFactory.getLogger(MemberController.class);
	
	@Autowired
	private MemberService memberService;
	
	@Autowired
	private OrderService orderService;
	
	@Autowired
	private ReviewService reviewService;
	
	@Autowired
	private ProductService productService;
	
	@GetMapping("/register")
	public void registerGET() {
		logger.info("회원가입화면으로 이동");
	}
	
	@PostMapping("/register")
	public String registerPOST(MemberVO member, RedirectAttributes rttr) throws Exception{
		logger.info("회원가입: "+ member.getUserId());
		
		memberService.memberRegister(member);
		
		//완료 메세지 설정
		rttr.addFlashAttribute("msg", "회원가입이 완료되었습니다");
		
		//로그인 화면으로 전송
		return "redirect:/member/login";
		
	}
	
	@GetMapping("/login")
	public String loginGET() {
		logger.info("로그인화면으로 이동");
		
		return "/member/login";
	}
	
	@PostMapping("/login")
	public String loginPOST(MemberVO member, HttpServletRequest request, RedirectAttributes rttr) throws Exception{
		// 세션 취득 - 로그인정보 유지
		HttpSession session = request.getSession();
		
		// service에서 id,pw 대조
		MemberVO loginMember = memberService.memberLogin(member);
		
		//실패판정
		if(loginMember == null) {
			session.setAttribute("member", null);
			rttr.addFlashAttribute("msg","입력하진 정보가 일치하지 않습니다");
			return "redirect:/member/login";
		}
		
		//성공시
		session.setAttribute("member",loginMember);
		
		MemberRankVO rank = memberService.selectRankByMember(loginMember);
		session.setAttribute("memberRank", rank);
		logger.info("로그인성공 " + loginMember.getName());
		
		return "redirect:/";
	}

	
	@GetMapping("/logout")
	public String logoutGET(HttpServletRequest request) {
		logger.info("로그아웃하겠습니다");
		
		HttpSession session = request.getSession();
		
		session.invalidate();// 세션파기
		
		return "redirect:/";
	}

	
	@PostMapping("/idCheck")
	@ResponseBody // 화면이동없이 데이터만 반환
	public int idCheckPOST(String userId) throws Exception{
		logger.info("ID중복체크" + userId);
		
		int result = memberService.idCheck(userId);
		
		return result; // 0 - ok, 1 - X
	}
	
	//마이페이지로 이동
		@GetMapping("/mypage")
		public String mypage(@RequestParam(defaultValue="point") String tab, HttpServletRequest request, Model model) throws Exception{

		    // 1) 세션 가져오기 (없으면 null)
		    HttpSession session = request.getSession(false);

		    // 2) 세션에서 로그인 회원 꺼내기
		    MemberVO sessionMember = null;
		    if (session != null) {
		        sessionMember = (MemberVO) session.getAttribute("member");
		        		        
		    }
		    
		    if(sessionMember != null && sessionMember.getRole() == 1) {
		    	return "redirect:/admin/dashboard";
		    }
		    
		    MemberVO member = memberService.getMember(sessionMember);
		    
		    // 3) 로그인 안 되어 있으면 로그인 페이지로 보내기
		    if(member==null) {
		    	return "redirect:/member/login";
		    }
		    
		    // 4) JSP에서 쓰도록 model에 담기
		    
		    model.addAttribute("member", member);
		    model.addAttribute("tab",tab);

		    // 5) mypage.jsp로 이동
		    return "member/mypage";
		}
		
	    @GetMapping("/tab/point")
	    public String pointTab() throws Exception{


	    	
	        return "member/tab/point";
	    }
	    
	   @GetMapping("/tab/orders")
	   public String orderHistoryTab(HttpServletRequest request, Model model) throws Exception{
		   HttpSession session = request.getSession();
		   MemberVO member = (MemberVO)session.getAttribute("member");
		   
		   List<OrderVO> orderList = orderService.getOrders(member);
		   
		   model.addAttribute("orderList",orderList);
		   
		   return "member/tab/orderHistory";
	   }
	   
	   @GetMapping("/tab/receipt")
	   public String receiptTab(@RequestParam("orderId")String orderId, Model model,HttpServletRequest request) throws Exception{
		   HttpSession session = request.getSession();
		   
		   MemberVO member = (MemberVO)session.getAttribute("member");
		   
		   OrderVO order = orderService.getOrderWithDetails(orderId);
		   
		   
		   model.addAttribute("order", order);
		   model.addAttribute("detailList",order.getDetails());
		   model.addAttribute("member",member);
		   
		   return "member/tab/receipt";
	   }
	   
	   @GetMapping("/tab/orderdetail")
	   public String detailsTab(@RequestParam("orderId")String orderId,Model model, HttpServletRequest request) throws Exception{
		   HttpSession session = request.getSession();
		   
		   MemberVO member = (MemberVO)session.getAttribute("member");
		   
		   OrderVO order = orderService.getOrderWithDetails(orderId);
		   
		   if(member == null || !member.getUserId().equals(order.getUserId())) {
			   return "redirect:/member/mypage?tab=orders";
		   }
		   
		   model.addAttribute("member",member);
		   model.addAttribute("order",order);
		   model.addAttribute("detailList",order.getDetails());
		   
		   return "member/tab/orderdetail";
		    
	   }
	   
	   @GetMapping("/review_write")
	   public String writeReview(
			   @RequestParam("prodId") int prodId,
			   @RequestParam("orderId") String orderId, Model model,HttpServletRequest request,
			   RedirectAttributes rttr) throws Exception{
		   
		   HttpSession session = request.getSession();
		   MemberVO member = (MemberVO)session.getAttribute("member");
		   

		   
		   if(!reviewService.canWriteReview(member.getUserId(),prodId)) {
			   rttr.addFlashAttribute("msg","이미 리뷰를 작성한 상품입니다.");
			   
			   if(orderId != null && !orderId.isEmpty()) {
				   return "redirect:/member/mypage?tab=orderdetail&orderId="+orderId;
			   }else {
				   return "redirect:/member/mypage?tab=orders";
			   }   
		   }
		   
		   logger.info("리뷰 작성 페이지 진입");
		   
		   model.addAttribute("product",productService.getProduct(prodId));
		   model.addAttribute("orderId",orderId);
		   
		   return "member/tab/review_write";
	   }
	   
	   @PostMapping("/review_register")
	   public String registerReviewPOST(
			   ReviewVO review,
			   @RequestParam(value = "uploadFile", required = false) MultipartFile file,
			   HttpServletRequest request,
			   RedirectAttributes rttr
			   ) throws Exception{
		   
		   HttpSession session = request.getSession();
		   MemberVO member = (MemberVO) session.getAttribute("member");
		   
		   
		   review.setUserId(member.getUserId());
		   
		   String uploadDirectory = "C:\\grocery_upload\\review";
		   
		   if(file != null && !file.isEmpty()) {
			   
			   String uuid = UUID.randomUUID().toString();
			   String originalFileName = file.getOriginalFilename();
			   String uploadFileName = uuid + "_" + originalFileName;
			   
			   File savePath = new File(uploadDirectory);
			   if(!savePath.exists()) {
				   savePath.mkdirs();
			   }
			   
			   File saveFile = new File(uploadDirectory, uploadFileName);
			   
			   try {
				   file.transferTo(saveFile);
				   // DB에파일명 저장
				   review.setReviewImage(uploadFileName);
			   }catch(Exception e) {
				   logger.error("파일 저장 실패");
			   }
		   }else {
			   review.setReviewImage("");
		   }
		   
		   reviewService.register(review);
		   rttr.addFlashAttribute("msg","리뷰를 등록하였습니다");
		   
		   if(review.getOrderId() != null && !review.getOrderId().isEmpty()) {
			   return "redirect:/member/mypage?tab=orderdetail&orderId=" + review.getOrderId();
		   }
		   return "redirect:/member/mypage?tab=orders";
		   
	   }
	   
	   @GetMapping("/tab/profile")
	   public String viewProfile(HttpServletRequest request,Model model) throws Exception {
		   HttpSession session = request.getSession();
		   MemberVO member = (MemberVO)session.getAttribute("member");
		   
		   model.addAttribute("member", member);
		   
		   return "member/tab/profile";
	   }
	   
	   @PostMapping("/checkPw")
	   @ResponseBody
	   public boolean checkPw(@RequestParam("userId") String userId, @RequestParam("password")String password) throws Exception{
		   
		   return memberService.checkPassword(userId, password);
	   }
	   
	   @PostMapping("/edit")
	   public String editProfile(MemberVO member, HttpSession session, RedirectAttributes rttr) throws Exception{
		   logger.info("회원정보 수정" + member.getUserId());
		   
		   memberService.editMember(member);
		   
		   MemberVO updatedMember = memberService.getMember(member);
		   updatedMember.setPassword(null); // 세션에 비밀번호정보를 남기지 않기 위해
		   session.setAttribute("member", updatedMember);
		   
		   rttr.addFlashAttribute("msg","회원정보를 수정하였습니다.");
		   
		   return "redirect:/member/mypage?tab=profile";
	   }
	
}
