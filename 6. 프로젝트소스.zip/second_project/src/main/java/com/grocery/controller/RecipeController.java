package com.grocery.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.grocery.service.RecipeService;
import com.grocery.vo.RecipeVO;

@Controller
@RequestMapping("/recipe")
public class RecipeController {
	
	@Autowired
	private RecipeService recipeService;
	
	@GetMapping("/api/{recipeId}")
	@ResponseBody
	public RecipeVO getRecipeApi(@PathVariable("recipeId")int recipeId)  throws Exception{
		return recipeService.getRecipeDetail(recipeId);
	}
	
}
