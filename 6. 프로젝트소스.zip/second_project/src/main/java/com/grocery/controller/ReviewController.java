package com.grocery.controller;

import java.io.File;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;

import com.grocery.service.ReviewService;
import com.grocery.vo.ReviewVO;

@Controller
@RequestMapping("/review")
public class ReviewController {
	
	private static final Logger logger = LoggerFactory.getLogger(ReviewController.class);
	
	@Autowired
	private ReviewService reviewService;
	
	@PostMapping("/register")
	public String register(ReviewVO review, HttpServletRequest request) throws Exception{
		
		MultipartFile file = review.getUploadFile();
		
		if(file != null && !file.isEmpty()) {
			
			String uploadFolder = request.getSession().getServletContext().getRealPath("/resources/img/review");
			File savePath = new File(uploadFolder);
			if(!savePath.exists()) {
				savePath.mkdirs();
			}
			
			//파일명 중복회피
			String uuid = UUID.randomUUID().toString();
			String uploadFileName = uuid + "_" + file.getOriginalFilename();
			
			// 서버에 저장
			File saveFile = new File(savePath, uploadFileName);
			file.transferTo(saveFile);
			
			review.setReviewImage(uploadFileName);
		}else {
			review.setReviewImage(null);
		}
		
		
		reviewService.register(review);
		
		return "redirect:/product/detail?prodId=" + review.getProdId();
	}

}
