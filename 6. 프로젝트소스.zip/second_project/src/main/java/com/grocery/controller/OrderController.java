package com.grocery.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.grocery.service.CartService;
import com.grocery.service.MemberService;
import com.grocery.service.OrderService;
import com.grocery.service.PaymentService;
import com.grocery.vo.CartVO;
import com.grocery.vo.MemberRankVO;
import com.grocery.vo.MemberVO;
import com.grocery.vo.OrderDetailVO;
import com.grocery.vo.OrderVO;

@Controller
@RequestMapping("/order")
public class OrderController {
	
	private static final Logger logger = LoggerFactory.getLogger(OrderController.class);
	
	@Autowired
	private OrderService orderService;
	
	@Autowired
	private MemberService memberService;
	
	@Autowired
	private CartService cartService;
	
	@Autowired
	private PaymentService paymentService;
	
	
	@GetMapping("/checkout")
	public String orderPageGET(Model model, HttpServletRequest request) throws Exception{
		HttpSession session = request.getSession();
		MemberVO sessionMember = (MemberVO) session.getAttribute("member");
		MemberRankVO rank = (MemberRankVO) session.getAttribute("memberRank");
		
		MemberVO member = memberService.getMember(sessionMember);
		
		String userId = member.getUserId();
		
		logger.info("주문화면표시" +userId);
		
		//주소등의 정보 표사를 위한 사용자 정보 취득
		// 서비스에서 데이터를 받아와도 됨, 세션의 정보를 그대로 사용하는것도 가능
		model.addAttribute("memberInfo",member);
		model.addAttribute("memberRank",rank);
		
		model.addAttribute("cartList",cartService.getCartList(userId));
		
		return "/order/order";
	}
	
	//주문실행
	
	@ResponseBody
	@PostMapping(value="/payment/complete", produces= "text/plain;charset=UTF-8")
	public String paymentComplete(
			@RequestParam("imp_uid") String imp_uid,
			@RequestParam("merchant_uid") String merchant_uid,
			@RequestParam("amount") int paid_amount,
			@RequestParam("usedPoint") int usedPoint,
			// JSP의 배송정보등을 받아줄 객체
			OrderVO order,
			HttpServletRequest request){
		
		HttpSession session = request.getSession();
		MemberVO member = (MemberVO) session.getAttribute("member");
		MemberRankVO rank = (MemberRankVO) session.getAttribute("memberRank");
		if(member != null) {
			order.setUserId(member.getUserId());
		}
		
		try {
			
			boolean isValid = paymentService.verifyPayment(imp_uid, merchant_uid, paid_amount);
			
			if(isValid) {
				//검증 성공시 DB저장
				
				order.setOrderId(merchant_uid);
				
				order.setUsedPoint(usedPoint);
				int totalAmount = paid_amount + usedPoint;
				order.setTotalAmount(totalAmount);
				double rate = 1.0;
				int shippingFee = 0;
				if(paid_amount >= 50000) {
					shippingFee = 3000;
				}
				
				if(rank != null) {
					rate = rank.getPointRate();
				}
				
				int earnedPoint = (int)((totalAmount - shippingFee) * (rate / 100.0));
				
				order.setEarnedPoint(earnedPoint);
				
				order.setImpUid(imp_uid);
				
				List<CartVO> cartList = cartService.getCartList(member.getUserId());
				List<OrderDetailVO> details = new ArrayList<>();
				
				for(CartVO cart : cartList) {
					OrderDetailVO detail = new OrderDetailVO();
					detail.setOrderId(merchant_uid);
					detail.setProdId(cart.getProdId());
					detail.setQuantity(cart.getQuantity());
					detail.setProdName(cart.getProdName());
					detail.setPrice(cart.getProdPrice());
					detail.setProdImage(cart.getProdImage());
					details.add(detail);
				}
				order.setDetails(details);
				
				orderService.order(order);
				
				return "success";
			}else {
				return "fail";
			}
		}catch(Exception e) {
			e.printStackTrace();
			return "error";
		}
	}
	
	@GetMapping("/complete")
	public String orderCompletePage(@RequestParam("uid") String uid,Model model) throws Exception{
		
		
		model.addAttribute("orderId",uid);
		
		return "order/complete";
		
	}
	


}
