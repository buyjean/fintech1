package com.grocery.mapper;

import java.util.List;

import com.grocery.vo.Criteria;
import com.grocery.vo.ProductVO;

public interface ProductMapper {
	
	// 판매중인 상품 조회
	public List<ProductVO> getList();
	
	public List<ProductVO> getListAll();
	
	//상품 상세정보 조회
	public ProductVO getProduct(int prodId);
	
	public List<ProductVO> getRecommendedProducts();
	
	// 품류별상품 일람
	public List<ProductVO> getListByCategory(int categoryId);
	
	public List<ProductVO> getMinListByRegDate();
	
	public List<ProductVO> getMinListByIsOutlet();
	
	public List<ProductVO> getByKeyword(String keyword);
	
	public List<ProductVO> getRanListByCategory(ProductVO product);
	
	public List<ProductVO> getSearchList(Criteria cri);
	
	public int getTotalCount(Criteria cri);
}
