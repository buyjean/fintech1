package com.grocery.mapper;

import java.util.List;

import com.grocery.vo.CategoryVO;

public interface CategoryMapper {
	
	//상품 분류 전체 조회
	public List<CategoryVO> getCateList();
	

}
