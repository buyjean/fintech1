package com.grocery.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.grocery.vo.ReviewVO;

public interface ReviewMapper {
	
	public void register(ReviewVO review);
	
	public List<ReviewVO> getListByProdId(int prodId);
	
	public ReviewVO getReviewRating(int prodId);
	
	//중복 체크
	public int countReviewByFamily(@Param("userId") String userId, @Param("masterId") int masterId);

}
