package com.grocery.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.grocery.vo.EventVO;
import com.grocery.vo.ProductVO;

public interface AdminMapper {
	// 차트 관련
	List<Map<String, Object>> getDailySales(@Param("startDate") String startDate, @Param("endDate") String endDate);
	
	List<Map<String,Object>> getCategorySales(@Param("startDate")String startDate, @Param("endDate")String endDate);
	
	Map<String, Object> getTodaySummary();
	
	List<Map<String,Object>> getProductRanking(@Param("startDate")String startDate, @Param("endDate")String endDate);
	
	//주문관리
	int getOrderCount(@Param("status")String status);
	
	List<Map<String,Object>> getOrderList(
			@Param("status")String status,
			@Param("startRow")int startRow,
			@Param("endRow")int endRow);
	
	void updateOrderStatus(@Param("orderId") String orderId, @Param("status") String status);
	
	void updateRecommendStatus(@Param("prodId")int prodId);
	
	int migrateToOutlet();
	
	int clearOriginalStock();
	
	int updateExpiredProducts();
	
	int updateProduct(ProductVO vo);
	
	int migrateOneToOutlet(int prodId);
	
	int clearOneOriginalStock(int prodId);
	
	int toggleStatus(int prodId);
	
	int deleteProduct(int prodId);
	
	int insertProduct(ProductVO vo);
	
	List<EventVO> getEventList();
	
	int insertEvent(EventVO vo);
	
	int updateEvent(EventVO vo);
	
	int deleteEvent(int eventId);
	
	
}
