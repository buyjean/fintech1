package com.grocery.mapper;

import java.util.List;

import com.grocery.vo.MemberVO;
import com.grocery.vo.OrderDetailVO;
import com.grocery.vo.OrderVO;

public interface OrderMapper {
	
	//주문 테이블 등록
	public int enrollOrder(OrderVO orer);
	
	//주문 상세 테이블 등록
	public int enrollOrderDetail(OrderDetailVO orderDetail);
	
	//재고 반영
	public int deductStock(OrderDetailVO orderDetail);
	
	public List<OrderVO> getOrders(MemberVO member);
	
	public OrderVO getOrder(String orderId);
	
	public List<OrderDetailVO> getOrderDetails(String orderId);
	

}
