package com.grocery.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.grocery.vo.CartVO;

public interface CartMapper {
	
	//장바구니에 추가
	public int addCart(CartVO cart);
	
	//장바구니 삭제
	public int deleteCart(int cartId);
	
	public void deleteCartBatch(@Param("cartIds")List<Integer> cartIds);
	
	//수량 변경
	public int modifyQuantity(CartVO cart);
	
	//장바구니내역조회
	public List<CartVO> getCartList(String userId);
	
	//중복체크
	public CartVO checkCart(CartVO cart);
	
	//구매완료후 장바구니 초기화
	public int deleteCartAll(String userId);

}
