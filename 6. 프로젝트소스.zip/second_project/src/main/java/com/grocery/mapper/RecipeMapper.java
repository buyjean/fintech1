package com.grocery.mapper;

import com.grocery.vo.RecipeVO;

public interface RecipeMapper {
	
	
    public RecipeVO getRecipeDetail(int recipeId);

   
    public RecipeVO getRecipeByProdId(int prodId);

}
