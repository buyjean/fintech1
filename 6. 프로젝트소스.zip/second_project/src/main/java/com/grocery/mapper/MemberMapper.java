package com.grocery.mapper;

import com.grocery.vo.MemberRankVO;
import com.grocery.vo.MemberVO;

public interface MemberMapper {
	
	public int register(MemberVO member);
	
	public int idCheck(String memberID);

	public MemberVO login(MemberVO member);
	
	public int updateMemberStats(MemberVO member);
	
	public MemberRankVO selectRankByMember(MemberVO member);
	
	public int updateMember(MemberVO member);
}
