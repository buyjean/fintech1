package com.grocery.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.grocery.vo.MemberVO;

public class LoginInterceptor extends HandlerInterceptorAdapter{
	
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception{
		
		System.out.println("Interceptor작동 - 로그인 체크");
		
		HttpSession session = request.getSession();
		
		MemberVO member = (MemberVO) session.getAttribute("member");
		
		if(member == null) {
			String contextPath = request.getContextPath();
			response.sendRedirect(contextPath + "/member/login");
			
			return false;
		}
		
		return true;
	}
}
