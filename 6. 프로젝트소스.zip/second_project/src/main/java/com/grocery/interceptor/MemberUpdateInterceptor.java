package com.grocery.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.grocery.service.MemberService;
import com.grocery.vo.MemberRankVO;
import com.grocery.vo.MemberVO;

public class MemberUpdateInterceptor extends HandlerInterceptorAdapter {
	
	@Autowired
	private MemberService memberService;
	
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
		HttpSession session = request.getSession();
		MemberVO member = (MemberVO) session.getAttribute("member");
		
		if(member != null) {
			//세션 갱신
			try {
				//유저 정보 갱신
				MemberVO freshMember = memberService.getMember(member);
				session.setAttribute("member", freshMember);
				// 갱신된 유저정보를 바탕으로 등급 갱신
				MemberRankVO freshRank = memberService.selectRankByMember(freshMember);
				session.setAttribute("memberRank", freshRank);
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		
		return true;
	}
	
	

}
